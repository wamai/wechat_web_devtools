/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 11);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const log4js = __webpack_require__(18);
// @todo 运营规范日志格式为 /home/qspace/log/应用名/error/yyyyMMddhh.log
// log4js不支持只有pattern的文件名，这里投机取巧一把，文件名为20, 后加年份后两位，在2100前没有问题。@qybdshen
const isProd = "production" == 'production';
const logLevel = process.env.LOG_LEVEL ? process.env.LOG_LEVEL : ( false ? undefined : 'info');
class LoggerClass {
    constructor() {
        this.logPath = process.cwd() + '/logs/';
        if (isProd) {
            this.logger = log4js.getLogger('production');
        }
        else {
            this.logger = log4js.getLogger('debug');
        }
    }
    initLogger(logPath, appid) {
        this.logPath = logPath;
        log4js.configure({
            appenders: {
                console: {
                    type: 'console',
                    layout: {
                        type: 'pattern',
                        pattern: `[%d{yyyy-MM-dd hh:mm:ss}] %[[%c] [%p] %m%]`,
                    }
                },
                file: {
                    type: 'file',
                    filename: `${this.logPath}/${appid}.log`,
                    maxLogSize: 524288000,
                    alwaysIncludePattern: true,
                    backups: 20,
                    layout: {
                        type: 'pattern',
                        pattern: `[%d{yyyy-MM-dd hh:mm:ss}] [%c] [%p] %m%`,
                    }
                },
            },
            categories: {
                production: { appenders: ['console', 'file'], level: logLevel },
                debug: { appenders: ['console', 'file'], level: logLevel },
                default: { appenders: ['console'], level: logLevel },
            }
        });
        if (isProd) {
            this.logger = log4js.getLogger('production');
        }
        else {
            this.logger = log4js.getLogger('debug');
        }
    }
    trace(firstArg, ...args) {
        this.logger.trace(firstArg, ...args);
    }
    debug(firstArg, ...args) {
        this.logger.debug(firstArg, ...args);
    }
    info(firstArg, ...args) {
        this.logger.info(firstArg, ...args);
    }
    warn(firstArg, ...args) {
        this.logger.warn(firstArg, ...args);
    }
    error(firstArg, ...args) {
        this.logger.error(firstArg, ...args);
    }
    fatal(firstArg, ...args) {
        this.logger.fatal(firstArg, ...args);
    }
    log(firstArg, ...args) {
        this.logger.log(firstArg, ...args);
    }
}
const Logger = new LoggerClass();
exports.default = Logger;


/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("events");

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = __webpack_require__(10);
const log_1 = __webpack_require__(0);
const requireFunc =  true ? require : undefined;
const isProd = "production" === 'production';
let lib;
if (isProd) {
    const ffi = requireFunc('ffi');
    lib = ffi.Library(config_1.IDK_LIB, {
        'OssAttrInc': ['int', ['int', 'int', 'int']],
    });
}
function report(id, key, val) {
    if (isProd) {
        try {
            lib.OssAttrInc(id, key, val);
        }
        catch (err) {
            log_1.default.error('reportIdKey fail', err);
        }
    }
    else {
        log_1.default.debug('reportIdKey report', id, key, val);
    }
}
/**
 * 上报监控数据
 * @param key
 * @param {number} val
 */
function reportIdKey(key, val = 1) {
    const temp = (key + '').split('_');
    if (temp.length === 2) {
        report(parseInt(temp[0], 10), parseInt(temp[1], 10), val);
    }
    else if (config_1.MainIdKey && temp.length === 1) {
        report(config_1.MainIdKey, key, val);
    }
}
exports.reportIdKey = reportIdKey;
var config_2 = __webpack_require__(10);
exports.IdKey = config_2.IdKey;


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const jimp_1 = __webpack_require__(17);
const await_to_js_1 = __webpack_require__(4);
// import {ElementHandle} from "puppeteer";
const qs = __webpack_require__(8);
const urlUtil = __webpack_require__(7);
// import {IdKey} from "../config";
const log_1 = __webpack_require__(0);
// import {reportIdKey} from "../reportIdKey";
const devices = __webpack_require__(9);
function sleep(time) {
    return new Promise((resolve) => {
        setTimeout(resolve, time);
    });
}
exports.sleep = sleep;
function frameEvaluate(frame, func, ...args) {
    if (!frame.isDetached()) {
        return frame.evaluate(func, ...args);
    }
    else {
        // reportIdKey(IdKey.FRAME_DETACHED);
        log_1.default.error(`frameEvaluate failed frame[${frame.name()}] detached!`);
        throw new Error(`frame detached! name:${frame.name()}`);
    }
}
exports.frameEvaluate = frameEvaluate;
function timeoutEvaluateFrame(frame, timeout = 3000, func, ...args) {
    return new Promise(async (resolve, reject) => {
        if (!frame.isDetached()) {
            let isFinished = false;
            log_1.default.info('timeoutEvaluateFrameeeeeeeeeeeeeeeeeee');
            const timer = setTimeout(() => {
                isFinished = true;
                log_1.default.error('timeoutEvaluateFrame timeout!!!');
                reject(new Error('frame evaluate timeout error'));
            }, timeout);
            const [evalError, evalResult] = await await_to_js_1.default(frame.evaluate(func, ...args));
            if (!isFinished) {
                clearTimeout(timer);
                isFinished = true;
                evalError ? reject(evalError) : resolve(evalResult);
            }
        }
        else {
            // reportIdKey(IdKey.FRAME_DETACHED);
            log_1.default.error(`frameEvaluate failed frame[${frame.name()}] detached!`);
            reject(new Error(`frame detached! name:${frame.name()}`));
        }
    });
}
exports.timeoutEvaluateFrame = timeoutEvaluateFrame;
function timeoutEvaluatePage(page, timeout = 5000, func, ...args) {
    return new Promise(async (resolve, reject) => {
        if (!page.isClosed()) {
            let isFinished = false;
            const timer = setTimeout(() => {
                isFinished = true;
                reject(new Error('page evaluate timeout error'));
            }, timeout);
            const [evalError, evalResult] = await await_to_js_1.default(page.evaluate(func, ...args));
            if (!isFinished) {
                clearTimeout(timer);
                isFinished = true;
                evalError ? reject(evalError) : resolve(evalResult);
            }
        }
        else {
            return reject(new Error('page is closed'));
        }
    });
}
exports.timeoutEvaluatePage = timeoutEvaluatePage;
function timeoutWrap(asyncFunc, timeout = 5000) {
    return new Promise(async (resolve, reject) => {
        let isFinished = false;
        const timer = setTimeout(() => {
            isFinished = true;
            reject(new Error('asyncFunc exec timeout error'));
        }, timeout);
        const [asyncError, asyncResult] = await await_to_js_1.default(asyncFunc());
        if (!isFinished) {
            clearTimeout(timer);
            isFinished = true;
            asyncError ? reject(asyncError) : resolve(asyncResult);
        }
    });
}
exports.timeoutWrap = timeoutWrap;
function frame$$(frame, selector) {
    if (!frame.isDetached()) {
        return frame.$$(selector);
    }
    else {
        // reportIdKey(IdKey.FRAME_DETACHED);
        log_1.default.error(`frame.$$ failed frame detached!`);
        throw new Error(`frame detached! name: ${frame.name()}`);
    }
}
exports.frame$$ = frame$$;
function frame$$eval(frame, selector, func, ...args) {
    if (!frame.isDetached()) {
        return frame.$$eval(selector, func, ...args);
    }
    else {
        // reportIdKey(IdKey.FRAME_DETACHED);
        log_1.default.error(`frame.$$ failed frame detached!`);
        throw new Error(`frame detached! name: ${frame.name()}`);
    }
}
exports.frame$$eval = frame$$eval;
function frame$(frame, selector) {
    if (!frame.isDetached()) {
        return frame.$(selector);
    }
    else {
        // reportIdKey(IdKey.FRAME_DETACHED);
        log_1.default.error(`frame.$ failed frame detached!`);
        throw new Error(`frame detached! name: ${frame.name()}`);
    }
}
exports.frame$ = frame$;
function getDataReportDefault(params) {
    const { TaskUrl, ResultStatus, IsWebView = 0, ParentUrl = '', PkgUnexisted = 0 } = params;
    return {
        TaskPage: TaskUrl.split('?')[0],
        TaskUrl: TaskUrl.substr(0, 1000),
        ResultPage: '',
        ResultUrl: '',
        HasAutoClick: 0,
        IsNetworkIdleTimeOut: 0,
        IsWebviewWaitTimeOut: 0,
        TimeCost: 0,
        IsWebView,
        WaitForWebviewError: 0,
        ResultStatus: ResultStatus || 0,
        UrlCrawlBeginTime: Date.now(),
        PkgUnexisted,
        ParentUrl: ParentUrl.substr(0, 1000)
    };
}
exports.getDataReportDefault = getDataReportDefault;
function getDeviceInfo() {
    const iPhone = devices['iPhone 6'];
    iPhone.viewport.deviceScaleFactor = 1;
    return iPhone;
}
exports.getDeviceInfo = getDeviceInfo;
function getCookieInfo(appuin, url) {
    const domain = url.match(/^https?:\/\/([^:\/]+)[:\/]/i);
    const wxuin = appuin ? appuin : Date.now() * 1000 + parseInt(Math.random() * 1000 + '', 10);
    return {
        name: 'wxuin',
        value: wxuin + '',
        expires: new Date('2038-01-19T03:14:07.00').getTime(),
        domain: domain ? domain[1] : 'wxacrawler.com',
        path: '/',
        httpOnly: false,
    };
}
exports.getCookieInfo = getCookieInfo;
function getFileNameByUrl(url) {
    let name = url.replace(/\.|\/|\\|\*|\?|=|&|%/g, '_');
    if (name.length > 168) {
        name = name.substr(0, 168) + '_' + Math.round(Date.now() / 1000);
    }
    else {
        name += '_' + Math.round(Date.now() / 1000);
    }
    return name;
}
exports.getFileNameByUrl = getFileNameByUrl;
function checkImageValid(imageUrl) {
    return Promise.resolve(0);
    /*
    const rand = Math.floor(Math.random()*(100));
    if (rand > 0) {
        return Promise.resolve(0);
    }
    return new Promise((resolve) => {
        try {
            request({
                url: imageUrl,
                method: "GET",
                timeout: 3000,
            }, (error, response) => {
                if (!error && /2\d\d|304/.test(response.statusCode.toString())) {
                    const contentType: string = response.headers['content-type'] || '';
                    Logger.info(`${contentType}`);
                    if (/image/i.test(contentType)) {
                        return resolve(0);
                    }
                    else {
                        reportIdKey(IdKey.INVALID_SHARE_IMAGE);
                        return resolve(-1);
                    }
                } else {
                    reportIdKey(IdKey.CHECK_SHARE_IMAGE_ERR);
                    Logger.error(`checkShareDataImageUrl ${imageUrl} failed! ${error}`);
                    return resolve(-1);
                }
            });
        } catch (e) {
            reportIdKey(IdKey.CHECK_SHARE_IMAGE_CATCH_ERR);
            Logger.error(`checkShareDataImageUrl request error ${imageUrl}! ${e.message}`);
            return resolve(-1);
        }
    });
    */
}
exports.checkImageValid = checkImageValid;
const prefix = String(Date.now()).substr(0, 5);
const timeReg = new RegExp(`=${prefix}\\d{8,}($|&)`);
function replaceTimeStamp(url) {
    if (!url)
        return url;
    if (!timeReg.test(url))
        return url;
    // 需要替换
    const [path, params] = url.split('?');
    if (params) {
        const query = qs.parse(params);
        const newQuery = Object.keys(query).reduce((obj, key) => {
            if (/^\d{13,}$/.test(query[key])) {
                return obj;
            }
            obj[key] = query[key];
            return obj;
        }, {});
        const newUrl = `${path}?${qs.stringify(newQuery)}`;
        log_1.default.info(`replace timestamp: ${url} => ${newUrl}`);
        return newUrl;
    }
    return url;
}
exports.replaceTimeStamp = replaceTimeStamp;
function removeUselessParam(url) {
    if (!url)
        return url;
    const urlObj = new urlUtil.URL(url, 'http://mpcrawler');
    urlObj.searchParams.delete('ptp');
    urlObj.searchParams.delete('ref_page_name');
    urlObj.searchParams.delete('ref_page_id');
    urlObj.searchParams.delete('acm');
    urlObj.searchParams.delete('openid');
    urlObj.searchParams.delete('comefrom');
    const newUrl = urlObj.href.replace('http://mpcrawler/', '');
    log_1.default.info(`newUrl is ${newUrl}`);
    return newUrl;
}
exports.removeUselessParam = removeUselessParam;
function isBlackRequest(url, blackUrlList) {
    if (!url)
        return false;
    const urlObj = new urlUtil.URL(url, 'http://mpcrawler');
    const requestUrl = urlObj.searchParams.get('url');
    if (requestUrl) {
        const reMatch = requestUrl.split('?')[0].match(/https:\/\/(.+?)\//i);
        const host = reMatch ? reMatch[1].replace(/^\s+|\s+$/g, "") : "";
        // Logger.info(`black host is ${host}`)
        if (blackUrlList.indexOf(host) !== -1) {
            log_1.default.info(`black url is ${host}`);
            return true;
        }
    }
    // const host = requestUrl ? requestUrl.split('?')[0].replace(/^\s+|\s+$/g,"") : "";
    // Logger.info(`urlhost is ${host} black url is ${JSON.stringify(blackUrlList)}`);
    // if (requestUrl && requestUrl.split('?')[0] in blackUrlList) {
    return false;
}
exports.isBlackRequest = isBlackRequest;
function isBlankPicture(pic) {
    const result = jimp_1.default.read(pic).then(image => {
        image = image.greyscale(); // .write('lajigou.jpg');
        // const threshold = 80; // 阈值
        const pixelColorInfo = {}; // : Map<number, number> = new Map();
        // 像素检测
        log_1.default.info(`width=${image.bitmap.width} height=${image.bitmap.height}`);
        image.scan(0, 67, image.bitmap.width - 1, image.bitmap.height - 67, function (x, y, idx) {
            if (x !== image.bitmap.width - 1 && y !== image.bitmap.height - 1) {
                const bit = this.bitmap.data[idx + 0];
                if (!pixelColorInfo[bit]) {
                    pixelColorInfo[bit] = 0;
                }
                pixelColorInfo[bit] += 1;
                if (bit === undefined) {
                    log_1.default.info(`undefine bit x=${x} y=${y} idx=${idx} bit=${bit}`);
                }
            }
        });
        // 降序
        const pixelColorList = Object.keys(pixelColorInfo).sort((a, b) => {
            return pixelColorInfo[a] < pixelColorInfo[b] ? 1 : -1;
        });
        let maxPixelPercent = pixelColorInfo[pixelColorList[0]] / (image.bitmap.width * image.bitmap.height);
        const secondPixelPercent = pixelColorInfo[pixelColorList[1]] / (image.bitmap.width * image.bitmap.height);
        log_1.default.info(`maxPixelPercent = ${maxPixelPercent} secondPixelPercent = ${secondPixelPercent}`);
        if (maxPixelPercent > 0.5 && secondPixelPercent > 0.2) {
            maxPixelPercent += 0.1;
        }
        return maxPixelPercent * 100;
        // for (const key of pixelColorList) {
        //     Logger.info(`${key} count is ${pixelColorInfo[key]}`);
        // }
        // if (maxPixelPercent*100 > threshold) {
        //     return true;
        // } else {
        //     return false;
        // }
    })
        .catch((err) => {
        log_1.default.error(`isBlankPicture failed! ${err}`);
        return 0;
    });
    return result;
}
exports.isBlankPicture = isBlankPicture;


/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("await-to-js");

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("fs-extra");

/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports = require("url");

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("qs");

/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("puppeteer/DeviceDescriptors");

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.IDK_LIB = '/home/qspace/mmbizwxacrawlerworker/lib64/libossattrapi';
exports.MainIdKey = 118722;
var IdKey;
(function (IdKey) {
    IdKey[IdKey["TASK_START"] = 1] = "TASK_START";
    IdKey[IdKey["PROCESS_CRASH"] = 2] = "PROCESS_CRASH";
    IdKey[IdKey["PAGE_CRASH"] = 3] = "PAGE_CRASH";
    IdKey[IdKey["TASK_SUCC"] = 4] = "TASK_SUCC";
    IdKey[IdKey["CRAWLER_ERROR"] = 5] = "CRAWLER_ERROR";
    IdKey[IdKey["FIRST_PAGE_REDIRECT"] = 6] = "FIRST_PAGE_REDIRECT";
    IdKey[IdKey["IS_All_WEBVIEW"] = 7] = "IS_All_WEBVIEW";
    IdKey[IdKey["AUDITS_FRAME_DETACHED"] = 8] = "AUDITS_FRAME_DETACHED";
    IdKey[IdKey["GEN_RESULT_ERROR"] = 9] = "GEN_RESULT_ERROR";
    IdKey[IdKey["GEN_RESULT_OUT_OF_TIME"] = 10] = "GEN_RESULT_OUT_OF_TIME";
    IdKey[IdKey["PAGE_IS_WEBVIEW"] = 11] = "PAGE_IS_WEBVIEW";
    IdKey[IdKey["PAGE_NO_FRAME"] = 12] = "PAGE_NO_FRAME";
    IdKey[IdKey["GET_CLICKABLE_ELEMENT_ERROR"] = 13] = "GET_CLICKABLE_ELEMENT_ERROR";
    IdKey[IdKey["FOUND_NO_CLICKABLE_ELEMENTS"] = 14] = "FOUND_NO_CLICKABLE_ELEMENTS";
    IdKey[IdKey["CLICK_ELEMENT_ERROR"] = 15] = "CLICK_ELEMENT_ERROR";
    IdKey[IdKey["PAGE_EXCEPTION"] = 16] = "PAGE_EXCEPTION";
    IdKey[IdKey["CODESVR_REQUEST_FAILED"] = 17] = "CODESVR_REQUEST_FAILED";
    IdKey[IdKey["CODESVR_REQUEST_SUCC"] = 18] = "CODESVR_REQUEST_SUCC";
    IdKey[IdKey["REQUEST_SW_FAILED"] = 19] = "REQUEST_SW_FAILED";
    IdKey[IdKey["REQUEST_SW_SUCC"] = 20] = "REQUEST_SW_SUCC";
    IdKey[IdKey["REQUEST_FAILED"] = 21] = "REQUEST_FAILED";
    IdKey[IdKey["REQUEST_SUCC"] = 22] = "REQUEST_SUCC";
    IdKey[IdKey["SQUID_REQUEST_FAILED"] = 23] = "SQUID_REQUEST_FAILED";
    IdKey[IdKey["SQUID_REQUEST_SUCC"] = 24] = "SQUID_REQUEST_SUCC";
    IdKey[IdKey["NETWORK_IDLE_TIMEOUT"] = 25] = "NETWORK_IDLE_TIMEOUT";
    IdKey[IdKey["TASK_NO_RESULT"] = 26] = "TASK_NO_RESULT";
    IdKey[IdKey["DIALOG_EVENT"] = 27] = "DIALOG_EVENT";
    IdKey[IdKey["APP_DEAD"] = 28] = "APP_DEAD";
})(IdKey = exports.IdKey || (exports.IdKey = {}));


/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const path = __webpack_require__(5);
const fs = __webpack_require__(6);
const puppeteer = __webpack_require__(12);
const AuditsAuto_1 = __webpack_require__(13);
const log_1 = __webpack_require__(0);
const reportIdKey_1 = __webpack_require__(2);
const isProd = "production" === 'production';
const getTaskEnv = function () {
    const appid = process.env.appid;
    const taskid = process.env.taskid;
    const appuin = parseInt(process.env.appuin, 10) || 0;
    const indexPageUrl = process.env.indexPageUrl;
    const testTicket = process.env.ticket;
    let RESULT_PATH = path.resolve(process.cwd(), `./task/${appid}_${taskid}/result`);
    if (process.env.taskPath) {
        RESULT_PATH = path.resolve(process.env.taskPath, `./${appid}_${taskid}/result`);
    }
    const auditBusiness = [2, 4, 7, 10, 13, 14, 15];
    const reMatch = indexPageUrl.match(/wxacrawler\/\d{1,2}_(\d{1,2})\//i);
    const businessId = reMatch ? parseInt(reMatch[1], 10) : 0;
    let isMpcrawler = false;
    if (auditBusiness.indexOf(businessId) === -1) {
        isMpcrawler = true;
    }
    let paramList = [];
    try {
        const paramJson = JSON.parse(process.env.taskParam);
        if (paramJson.hasOwnProperty('param_list')) {
            paramList = paramJson.param_list;
        }
    }
    catch (e) {
        log_1.default.error(`json parse error! ${process.env.taskParam}`);
    }
    let extInfo = {};
    if (process.env.extInfo && process.env.extInfo.length) {
        try {
            extInfo = JSON.parse(process.env.extInfo);
            log_1.default.info(`extInfo ${JSON.stringify(extInfo)}`);
        }
        catch (e) {
            log_1.default.error(`json parse error! ${process.env.extInfo}`);
        }
    }
    return {
        appid,
        taskid,
        appuin,
        indexPageUrl,
        testTicket,
        RESULT_PATH,
        isMpcrawler,
        businessId,
        paramList,
        extInfo,
    };
};
(async () => {
    reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.TASK_START);
    const taskStartTime = Date.now();
    const taskEnv = getTaskEnv();
    const { paramList } = taskEnv;
    if (paramList.length === 0) {
        log_1.default.error(`paramList error! ${process.env.taskParam}`);
        return -4000;
    }
    const config = {
        url: taskEnv.indexPageUrl,
        appid: taskEnv.appid,
        taskid: taskEnv.taskid,
        appuin: taskEnv.appuin,
        businessId: taskEnv.businessId,
        resultPath: taskEnv.RESULT_PATH,
        taskStartTime,
        crawl_type: paramList[0].crawl_type,
        longitude: paramList[0].longitude,
        latitude: paramList[0].latitude,
        redirectto_url: paramList[0].redirectto_url,
        extInfo: taskEnv.extInfo
    };
    const logPath = `${taskEnv.RESULT_PATH}`;
    fs.ensureDirSync(logPath);
    fs.ensureDirSync(`${taskEnv.RESULT_PATH}/screenshot`);
    fs.ensureDirSync(`${taskEnv.RESULT_PATH}/html`);
    log_1.default.initLogger(logPath, config.appid);
    let browserArgs = [];
    if (isProd) {
        browserArgs = [
            '--proxy-server=http://mmbizwxaauditnatproxy.wx.com:11177',
            '--proxy-bypass-list=10.206.30.80:12361;9.2.87.222:12361;*:18569'
        ];
        // '--proxy-bypass-list=10.206.30.80:12361;9.2.87.222:12361'];
    }
    else {
        browserArgs = [
        // '--proxy-server=http://127.0.0.1:12639'
        ];
    }
    const isHeadless = process.env.chromeMode === 'headless';
    const puppeteerConfig = {
        headless: isHeadless,
        devtools: false,
        ignoreHTTPSErrors: true,
        args: ['--no-sandbox', ...browserArgs],
    };
    log_1.default.info('puppeteerConfig', puppeteerConfig);
    const browser = await puppeteer.launch(puppeteerConfig);
    process.on('uncaughtException', async (error) => {
        log_1.default.error(`catch process error ${error.message}\n ${error.stack}`);
        reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.PROCESS_CRASH);
        await browser.close();
        process.exit();
    });
    process.on('warning', (error) => {
        log_1.default.warn('process on warning');
        log_1.default.warn(error.message);
        log_1.default.warn(error.stack);
    });
    const page = await browser.newPage();
    const auditsAuto = new AuditsAuto_1.default(page, config);
    log_1.default.info('new AuditsAuto Crawler succ');
    auditsAuto.on('pageError', async (error) => {
        log_1.default.error(`catch page crash ${error.message}\n ${error.stack}`);
        await browser.close();
        process.exit();
    });
    try {
        const taskResult = await auditsAuto.start();
        log_1.default.info(`Time cost ${Math.round((Date.now() - taskStartTime) / 1000)} s`);
        log_1.default.info('Audits result: ', JSON.stringify(taskResult));
        if (taskResult) {
            reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.TASK_SUCC);
        }
        else {
            reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.TASK_NO_RESULT);
        }
        await browser.close();
        process.exit();
    }
    catch (e) {
        log_1.default.error(`catch main error ${e.message}\n ${e.stack}`);
        reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.CRAWLER_ERROR);
        await browser.close();
        process.exit();
    }
})();


/***/ }),
/* 12 */
/***/ (function(module, exports) {

module.exports = require("puppeteer");

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const fs = __webpack_require__(6);
const path = __webpack_require__(5);
const await_to_js_1 = __webpack_require__(4);
const NetworkListener_1 = __webpack_require__(14);
const MinaHeartbeat_1 = __webpack_require__(16);
const Hijack_1 = __webpack_require__(19);
const PageBase_1 = __webpack_require__(20);
const utils = __webpack_require__(3);
const devices = __webpack_require__(9);
const reportIdKey_1 = __webpack_require__(2);
function sleep(time) {
    return new Promise((resolve) => setTimeout(resolve, time));
}
const TIME_LIMIT = 18 * 60 * 1000;
const iPhoneX = devices['iPhone X'];
iPhoneX.viewport.deviceScaleFactor = 1;
class AuditsAuto extends PageBase_1.default {
    constructor(page, options) {
        super(page);
        this.clickCnt = 0;
        this.wxConfig = {};
        this.urlPathMap = {};
        this.elementClickCountMap = new Map();
        this.elementTextMap = new Map();
        this.driverStartTime = 0;
        this.taskFinishedTime = 0;
        this.jsCoverage = '';
        this.isTimeout = false;
        this.isAppDead = false;
        this.appid = options.appid || '';
        this.appuin = options.appuin;
        this.taskid = options.taskid;
        this.page = page;
        this.indexPageUrl = options.url || '';
        this.resultPath = options.resultPath;
        this.taskStartTime = options.taskStartTime;
        this.longitude = options.longitude || 113.2645;
        this.latitude = options.latitude || 23.1288;
        this.redirectToUrlList = options.redirectto_url || [];
        this.extInfo = options.extInfo || {};
        this.hijack = new Hijack_1.default(page);
        this.networkListener = new NetworkListener_1.default(this.page);
        if (this.extInfo.singlePageMode && this.redirectToUrlList.length) {
            this.indexPageUrl = this.indexPageUrl.replace(/#.*$/, '');
            this.indexPageUrl += '#!' + this.redirectToUrlList[0].replace(/^\//, '');
        }
        this.log.info(`eeeeextInfo ${JSON.stringify(this.extInfo)}`);
        this.taskResult = { pages: [], mmdata: [] };
        this.init();
    }
    init() {
        this.initPageEvent();
        this.initNetworkEvent();
        this.initHeartbeatListen();
        this.timeoutPromise = new Promise((resolve, reject) => {
            this.log.info('start count down');
            setTimeout(() => {
                reject(new Error('timeout'));
            }, TIME_LIMIT);
        });
    }
    initNetworkEvent() {
        this.networkListener.on('ON_REQUEST_EVENT', (message) => {
            this.sendNetworkEvent2Frame({
                command: 'ON_REQUEST_EVENT',
                data: message
            });
        });
    }
    initHeartbeatListen() {
        this.heartbeatPromise = new Promise((resolve, reject) => {
            const heartbeatListener = new MinaHeartbeat_1.default({
                page: this.page
            });
            heartbeatListener.on('NO_HEART_BEAT', () => {
                reject(new Error('NO_HEART_BEAT'));
            });
        });
    }
    async sendNetworkEvent2Frame(message) {
        const [sendMessageError] = await await_to_js_1.default(this.page.evaluate((auditsFrame, message) => {
            if (auditsFrame) {
                const msg = JSON.parse(message);
                msg.protocol = 'AUDITS_FRAME';
                auditsFrame.contentWindow.postMessage(msg);
            }
        }, await this.page.$('#auditsFrame'), JSON.stringify(message)));
        if (sendMessageError) {
            this.log.error('send network event error', sendMessageError);
        }
    }
    async goIndexPageUrl(isReload = false) {
        this.log.info(`indexPageUrl: ${this.indexPageUrl}`);
        let gotoError, pageResponse;
        if (isReload) {
            this.log.info('reload page');
            [gotoError, pageResponse] = await await_to_js_1.default(this.page.reload({ waitUntil: 'domcontentloaded' }));
        }
        else {
            [gotoError, pageResponse] = await await_to_js_1.default(this.page.goto(this.indexPageUrl, { waitUntil: 'domcontentloaded' }));
        }
        if (gotoError) {
            this.log.error(`gotoError ${gotoError.message}\n${gotoError.stack}, retry`);
            return false;
        }
        if (pageResponse) {
            const chain = pageResponse.request().redirectChain();
            this.log.info(`page response status ${pageResponse.status()}`);
            this.log.info(`pageResponse is ok[${pageResponse.ok()}] chain length [${chain.length}] ${chain.map((req) => req.url())}`);
            if (!pageResponse.ok()) {
                this.log.error(`page response error, statusCode[${pageResponse.status()}], failure[${pageResponse.request().failure()}]`);
                return false;
            }
        }
        return true;
    }
    async start(retryCnt = 0) {
        if (retryCnt > 2) {
            this.log.error('start crawl failed, retry 3 times');
            return this.genTaskResult({});
        }
        if (!retryCnt) {
            await this.initPage();
        }
        if (!await this.goIndexPageUrl(retryCnt > 0)) {
            return this.start(retryCnt + 1);
        }
        const [waitForAppserviceError] = await await_to_js_1.default(this.page.waitFor(() => !!document.getElementById('appservice')));
        if (waitForAppserviceError) {
            this.log.error(`waitFor appservice error ${waitForAppserviceError.message}\n${waitForAppserviceError.stack}, retry`);
            return this.start(retryCnt + 1);
        }
        this.log.debug('appservice ready');
        await this.hijack.hijackDefault({
            longitude: this.longitude,
            latitude: this.latitude
        });
        await this.hijack.hijackPageEvent();
        // 貌似不一定监听得到，超时也允许继续跑
        const [domReadyTimeout] = await await_to_js_1.default(this.hijack.waitForPageEvent("__DOMReady", { timeout: 12000 }));
        if (domReadyTimeout) {
            this.log.error(`page event [__DOMReady] timeout. Try to continue.`);
        }
        this.log.info('after wait for __DOMReady');
        const [webviewManagerTimeout] = await await_to_js_1.default(this.page.waitFor(() => window.native && window.native.webviewManager && window.native.webviewManager.getCurrent() != null));
        if (webviewManagerTimeout) {
            this.log.error('wait for webviewManager ready timeout');
            return this.start(retryCnt + 1);
        }
        this.wxConfig = await this.page.evaluate(() => window.__wxConfig);
        this.log.info('wxConfig ready');
        this.log.info('checking is redirect');
        const isPageRedirected = await this.isPageRedirected(this.indexPageUrl);
        if (isPageRedirected) {
            // redirect means package is not exist
            this.log.error('page redirected, package is not exist');
            reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.FIRST_PAGE_REDIRECT);
            return this.genTaskResult({});
        }
        // 这里先sleep 1s，waitForCurrentFrameIdle检查的时候
        // 可能页面的请求都没开始发起，造成idle的假象
        await sleep(1000);
        // this.log.debug('waiting for frame idle')
        // const waitFrameInfo = await this.waitForCurrentFrameIdle();
        // if (waitFrameInfo.hasWebview) {
        //   // has webview means no other components shown
        //   this.log.error('has webview at the beginning, nothing to do')
        //   reportIdKey(IdKey.IS_All_WEBVIEW)
        //   return this.genTaskResult({})
        // }
        this.log.debug('frame idle time', this.getTime());
        if (this.extInfo.singlePageMode) {
            await this.hijack.hijackNavigation();
            this.log.debug('hijack page navigation done');
        }
        return Promise.all([
            this.timeoutPromise,
            this.heartbeatPromise,
            new Promise(async (resolve, reject) => {
                await this.startOperate();
                // await sleep(6000000)
                reject(new Error('finished'));
            })
        ]).then(() => {
            return Promise.reject(new Error('finished'));
        }).catch(async (error) => {
            if (error.message == 'finished') {
                this.log.info('crawl finished in time');
            }
            else if (error.message == 'NO_HEART_BEAT') {
                this.isAppDead = true;
                reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.APP_DEAD);
                this.log.error('app is dead, crawl failed');
                return this.genTaskResult({ isAppDead: true });
            }
            else {
                this.isTimeout = true;
                this.log.info('crawl timeout, stop audits to get result');
            }
            const [stopCoverageError, jsCoverage] = await await_to_js_1.default(utils.timeoutWrap(async () => await this.page.coverage.stopJSCoverage()));
            let serviceCoverage = null;
            if (stopCoverageError) {
                this.log.error('stopJSCoverage error', stopCoverageError);
            }
            else {
                this.log.info('stopJSCoverage succ');
                serviceCoverage = jsCoverage.filter((item) => /app\-service\.js/.test(item.url))[0];
                this.log.info('filter jsCoverage succ');
            }
            if (serviceCoverage && serviceCoverage.ranges) {
                this.jsCoverage = (100 * serviceCoverage.ranges.reduce((total, item) => total + item.end - item.start, 0) / serviceCoverage.text.length).toFixed(2) + '%';
            }
            else {
                this.jsCoverage = '0%';
            }
            const auditsFrame = this.page.frames().find((frame) => frame.name() == 'auditsFrame');
            this.log.info('audited pages', Object.keys(this.urlPathMap));
            this.log.info(`page coverage: ${Object.keys(this.urlPathMap).length}/${this.wxConfig.pages.length}`);
            this.log.info(`js coverage: ${this.jsCoverage}`);
            if (auditsFrame) {
                this.log.info('has auditsFrame');
                await sleep(2000);
                this.log.info('stopping audits');
                const [stopAuditError] = await await_to_js_1.default(utils.timeoutEvaluateFrame(auditsFrame, 5000, () => {
                    window.onStopClicked();
                }));
                if (stopAuditError) {
                    this.log.error('stop audit error', stopAuditError);
                }
                const [waitForError] = await await_to_js_1.default(this.page.waitForFunction(() => !!window.auditsResult, { timeout: 10000 }));
                if (waitForError) {
                    reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.GEN_RESULT_OUT_OF_TIME);
                    this.log.error('waiting audits result error: ', waitForError);
                    return this.genTaskResult({});
                }
                const [auditsError, auditsResult] = await await_to_js_1.default(this.page.evaluate(() => window.auditsResult));
                if (auditsError) {
                    reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.GEN_RESULT_ERROR);
                    this.log.error('getting audits result error: ', auditsError);
                    return this.genTaskResult({});
                }
                return await this.genTaskResult(auditsResult);
            }
            else {
                this.log.error('auditsFrame detached, no audits result');
                reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.AUDITS_FRAME_DETACHED);
                return this.genTaskResult({});
            }
        });
    }
    async initPage() {
        this.driverStartTime = Date.now();
        await this.page.setCookie(utils.getCookieInfo(this.appuin, this.indexPageUrl)); // 跳转前种入wxuin cookie，确保所有请求都到一台机器
        await this.page.emulate(iPhoneX);
        await this.page.coverage.startJSCoverage();
    }
    async startOperate() {
        if (!this.extInfo.singlePageMode
            && this.wxConfig.tabBar
            && this.wxConfig.tabBar.list
            && this.wxConfig.tabBar.list.length) {
            const list = this.wxConfig.tabBar.list;
            this.log.info('tabbar list', list.map((item) => `[title] ${item.text} [path] ${item.pagePath}`).join('\n'));
            for (let i = 0, len = list.length; i < len; i++) {
                this.log.info(`crawling page ${list[i].pagePath}`);
                const [switchTabError] = await await_to_js_1.default(utils.timeoutEvaluatePage(this.page, 5000, (url) => {
                    window.native.navigator.switchTab(url);
                }, list[i].pagePath));
                if (!switchTabError) {
                    this.log.info('switch tab succ');
                    await this.crawlCurrentWebview();
                }
                else {
                    this.log.error(`switch tab error: ${switchTabError.message}\n${switchTabError.stack}`);
                }
            }
        }
        else {
            await this.crawlCurrentWebview();
        }
    }
    async crawlCurrentWebview() {
        const page = this.page;
        const webviewNativeHandle = await this.page.evaluateHandle(() => window.native.webviewManager.getCurrent());
        const url = await page.evaluate(webview => webview.url, webviewNativeHandle);
        const urlPath = url.split('?')[0];
        this.urlPathMap[urlPath] = this.urlPathMap[urlPath] || {
            isWebview: false,
            cnt: 0
        };
        if (this.urlPathMap[urlPath].cnt > 2) {
            this.log.info(`${urlPath} has crawled 3 times`);
            return;
        }
        // 测fmp需要10s
        if (this.urlPathMap[urlPath].cnt == 0) {
            this.log.info('sleep 10s for fmp testing');
            await sleep(10000);
        }
        this.urlPathMap[urlPath].cnt++;
        const { hasWebview, frame } = await this.isCurrentFrameReady4Crawl();
        if (!frame) {
            this.log.error('current frame can not be crawling');
            return;
        }
        const [getTitleError, title] = await await_to_js_1.default(frame.evaluate(() => document.title));
        if (getTitleError) {
            this.log.error(`getTitleError`, getTitleError);
            if (frame.isDetached()) {
                return;
            }
        }
        this.log.info('page title: ', title);
        let filename = utils.getFileNameByUrl(url);
        this.log.info('page save filename: ', filename);
        const [getPageStackError, pageStack] = await await_to_js_1.default(this.page.evaluate(() => window.native.webviewManager.getPageStack().map((webview) => webview.path)));
        if (getPageStackError) {
            this.log.error(`getPageStackError`, getPageStackError);
        }
        this.log.info('pageStack', pageStack);
        const [saveError] = await await_to_js_1.default(Promise.all([
            this.saveScreenShot(filename),
            this.saveFrameHtml(frame, filename)
        ]));
        if (saveError) {
            this.log.error(`save error ${saveError.message}\n${saveError.stack}`);
            filename = undefined;
        }
        if (!hasWebview) {
            await this.clickElements(frame, webviewNativeHandle, urlPath);
        }
        else {
            this.urlPathMap[urlPath].isWebview = true;
            this.log.error('hasWebview!!!!!!!!!');
        }
        this.taskResult.pages.push({
            task_url: this.indexPageUrl.split('#!')[1] || '',
            path: urlPath,
            full_path: url,
            pagestack: pageStack,
            pic: filename ? `${filename}.jpg` : '',
            html: filename ? `${filename}.html` : '',
            title: title !== undefined ? title : 'undefined',
            level: pageStack.length - 1,
            reachType: 0,
            is_webview: hasWebview ? 1 : 0
        });
        this.log.info(`crawl url ${url} done`);
    }
    async isCurrentFrameReady4Crawl() {
        const { hasWebview, frame, id } = await this.waitForCurrentFrameIdle();
        if (!frame) {
            return { hasWebview };
        }
        if (hasWebview) {
            return { hasWebview, frame };
        }
        // 这里先sleep 1s，waitForCurrentFrameIdle检查的时候
        // 可能页面的很多请求都没开始发起，造成idle的假象
        await sleep(1000);
        this.log.info(`waiting for frame[${frame.name()}] webview ready`);
        const startToWait = Date.now();
        await await_to_js_1.default(frame.waitForFunction(() => !!window.webview, {
            timeout: 10000
        }, id));
        this.log.info('webview object ready');
        if (frame.isDetached()) {
            this.log.info(`oh frame[${frame.name()}] detached`);
            return {};
        }
        this.log.info(`frame[${frame.name()}] webview ready, time: ${Date.now() - startToWait}ms`);
        return { hasWebview, frame };
    }
    async clickElements(frame, webviewNativeHandle, pagePath) {
        const matchResult = /webview-(\d+)/.exec(frame.name());
        if (!matchResult) {
            this.log.error(`frame[${frame.name()}] is not webveiw`);
            return;
        }
        const id = +matchResult[1];
        const [getWebviewError, webviewBrowserHandle] = await await_to_js_1.default(frame.evaluateHandle(() => window.webview));
        if (getWebviewError || !webviewBrowserHandle) {
            this.log.error('getWebviewError', getWebviewError);
            return;
        }
        let [getClickableElementsError, elementsHandle] = await await_to_js_1.default(this.getClickableElements(frame, webviewBrowserHandle));
        if (getClickableElementsError) {
            reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.GET_CLICKABLE_ELEMENT_ERROR);
            this.log.error('getClickableElementsError', getClickableElementsError);
            return;
        }
        if (!elementsHandle || elementsHandle.length == 0) {
            reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.FOUND_NO_CLICKABLE_ELEMENTS);
            this.log.error(`frame[${frame.name()}] no elementsHandle found`);
            return;
        }
        for (let i = 0, len = elementsHandle.length; i < len; i++) {
            const { handle, key } = elementsHandle[i];
            try {
                // 过滤重复点击
                if (this.elementTextMap.get(key.textKey)) {
                    this.log.info(`textKey[${key.textKey}] has been click`);
                    continue;
                }
                // 过滤列表项太多时的点击
                let keyClickCnt = this.elementClickCountMap.get(key.tagClassKey) || 0;
                if (keyClickCnt > 3) {
                    this.log.info(`click key[${key.tagClassKey}][${keyClickCnt} times] out of click limit`);
                    continue;
                }
                const isClickable = await this.elementClickable(frame, handle);
                this.log.info(`is element[${key.tagClassKey}] clickable ${isClickable}`);
                if (!isClickable)
                    continue;
                keyClickCnt++;
                this.elementTextMap.set(key.textKey, true);
                this.elementClickCountMap.set(key.tagClassKey, keyClickCnt);
                this.clickCnt++;
                // const fucosBorderHandle = await this.addRedBorder4Handle(frame, handle)
                // await this.saveScreenShot()
                // await frame.evaluate((redBorderHandle) => {
                //   redBorderHandle.remove()
                // }, fucosBorderHandle)
                // await this.screenshotBeforeClick(frame, handle)
                await handle.tap();
                await sleep(1000);
                this.log.info(`clicked key[${key.tagClassKey}][${keyClickCnt} times][${key.textKey.substr(0, 30)}] ${key.tagClassKey} at page ${pagePath}`);
            }
            catch (e) {
                reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.CLICK_ELEMENT_ERROR);
                this.log.error(pagePath, '|', e.message);
                continue;
            }
            await await_to_js_1.default(this.waitForFrameChange(id, { timeout: 1000 }));
            let isFrameDetached = frame.isDetached();
            let isWebviewChanged = false;
            let detectChangeError;
            if (isFrameDetached) {
                this.log.info(`frame[${frame.name()}] is detached`);
                isWebviewChanged = true;
            }
            else {
                [detectChangeError, isWebviewChanged] = await await_to_js_1.default(this.isCurrentWebviewChanged(webviewNativeHandle));
                if (detectChangeError) {
                    isWebviewChanged = true;
                }
            }
            if (isWebviewChanged) {
                this.log.info(`frame[${frame.name()}] webview changed`);
                if (isFrameDetached || detectChangeError) {
                    this.log.info(`frame[${frame.name()}] is detached[${isFrameDetached}] or destroy[${detectChangeError}]`);
                    await this.crawlCurrentWebview();
                    break;
                }
                await this.crawlCurrentWebview();
                this.log.info('navigating back');
                await this.page.evaluate(() => {
                    window.native.navigator.navigateBack();
                });
                this.log.info('navigating back succ');
            }
            else {
                this.log.info(`frame[${frame.name()}] not change`);
            }
            await sleep(1000);
            if (frame.isDetached()) {
                this.log.info(`frame[${frame.name()}] is detachedddd`);
                await this.crawlCurrentWebview();
                break;
            }
            this.log.info(`waiting for frame[${frame.name()}] idle`);
            await this.waitForCurrentFrameIdle();
            this.log.info(`frame[${frame.name()}] is idle`);
            const newElementsHandle = await this.getClickableElements(frame, webviewBrowserHandle);
            this.log.info(pagePath, 'get new elements', elementsHandle.length);
            elementsHandle = newElementsHandle;
            len = elementsHandle.length;
            i = 0;
        }
    }
    async getClickableElements(frame, webviewBrowserHandle) {
        this.log.debug('finding clickable elements');
        const [evaluateError, clickableCount] = await await_to_js_1.default(frame.evaluate((webview, isSinglePageMode) => {
            const elements = webview.getElements({ clickable: true });
            const navigators = isSinglePageMode ? [] : document.querySelectorAll('wx-navigator');
            const elementKeyMap = {};
            elements.forEach(element => {
                // 过滤广告
                if (!element.closest('wx-ad')) {
                    const elementKey = [element.tagName, element.className.split(/\s+/).join('_')].join('__');
                    if (elementKeyMap[elementKey] && elementKeyMap[elementKey] > 2)
                        return;
                    elementKeyMap[elementKey] = elementKeyMap[elementKey] || 0;
                    elementKeyMap[elementKey]++;
                    element.setAttribute('crawler-click-el', 'true');
                }
            });
            Array.prototype.forEach.call(navigators, (element) => {
                element.setAttribute('crawler-click-el', 'true');
            });
            return document.querySelectorAll('[crawler-click-el]').length;
        }, webviewBrowserHandle), this.extInfo.singlePageMode);
        if (evaluateError) {
            this.log.error('getClickableElements error', evaluateError);
            return [];
        }
        this.log.debug('get clickable elements, length', clickableCount);
        const elementsHandle = (await frame.$$('[crawler-click-el="true"]')).slice(0, 200);
        let elements = [];
        for (let i = 0, len = elementsHandle.length; i < len; i++) {
            const elementHandle = elementsHandle[i];
            const boundingBox = (await elementHandle.boundingBox()) || {
                x: 0,
                y: 0,
                width: 0,
                height: 0,
            };
            elements[i] = {
                handle: elementHandle,
                key: await this.getElementKey(elementHandle, frame),
                left: boundingBox.x,
                top: boundingBox.y,
                width: boundingBox.width,
                height: boundingBox.height,
            };
        }
        elements = elements.filter((item) => item.width * item.height).slice(0, 100);
        elements.sort((a, b) => {
            if (a.top != b.top)
                return a.top - b.top;
            if (a.left != b.left)
                return a.left - b.left;
            if (a.width * a.height != b.width * b.height)
                return b.width * b.height - a.width * a.height;
            if (a.key.textKey > b.key.textKey)
                return -1;
            if (a.key.textKey < b.key.textKey)
                return 1;
            return 0;
        });
        this.log.debug('get clickable elements sort finished');
        if (elements.length == 0) {
            reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.FOUND_NO_CLICKABLE_ELEMENTS);
        }
        return elements;
    }
    async elementClickable(frame, elementHandler) {
        const [checkElementClickAbleError, isClickable] = await await_to_js_1.default(frame.evaluate((el) => {
            const { top, height } = el.getBoundingClientRect();
            const deltaY = top - (window.innerHeight >> 1) + (height >> 1);
            window.scrollTo(0, window.scrollY + deltaY);
            const newRect = el.getBoundingClientRect();
            const [x, y] = [newRect.left + (newRect.width >> 1), newRect.top + (newRect.height >> 1)];
            const elementAtPoint = document.elementFromPoint(x, y);
            const isParent = function (a, b) {
                while (a != document.body) {
                    if (a == b) {
                        return true;
                    }
                    else if (a && a.parentElement) {
                        a = a.parentElement;
                    }
                    else {
                        break;
                    }
                }
                return false;
            };
            return isParent(elementAtPoint, el) || isParent(el, elementAtPoint);
        }, elementHandler));
        if (checkElementClickAbleError) {
            this.log.error(`checkElementClickAbleError`, checkElementClickAbleError);
            return false;
        }
        return !!isClickable;
    }
    async isCurrentWebviewChanged(webviewNativeHandle) {
        const [checkWebviewChangedError, isWebviewChange] = await await_to_js_1.default(this.page.evaluate(webview => {
            return webview !== window.native.webviewManager.getCurrent();
        }, webviewNativeHandle));
        if (checkWebviewChangedError) {
            this.log.error(`checkWebviewChangedError`, checkWebviewChangedError);
        }
        return isWebviewChange;
    }
    async getElementKey(element, frame) {
        const [getElementKeyError, elementKey] = await await_to_js_1.default(frame.evaluate(el => {
            const clientRect = el.getBoundingClientRect();
            return {
                textKey: `${Math.round(clientRect.width)}-${Math.round(clientRect.height)}-${el.textContent}`.replace(/\n/g, '\\n').replace(/\s+/g, ' ').substr(0, 100),
                tagClassKey: [el.tagName, el.className.split(/\s+/).join('_')].join('__')
            };
        }, element));
        if (getElementKeyError) {
            this.log.error(`getElementKeyError`, getElementKeyError);
        }
        return elementKey;
    }
    async saveScreenShot(filename) {
        const screenShotPath = path.resolve(this.resultPath, `./screenshot/${filename}.jpg`);
        await this.page.screenshot({ path: screenShotPath, type: 'jpeg', quality: 90 });
    }
    async saveFrameHtml(frame, filename) {
        const pageHtml = await frame.content();
        const htmlPath = path.resolve(this.resultPath, `./html/${filename}.html`);
        await fs.writeFile(htmlPath, pageHtml);
    }
    async addRedBorder4Handle(frame, handle, color = 'red') {
        return await frame.evaluateHandle((el) => {
            const focusBorder = document.createElement('div');
            const rect = el.getBoundingClientRect();
            focusBorder.style.position = 'absolute';
            focusBorder.style.zIndex = '10000';
            focusBorder.style.boxSizing = 'border-box';
            focusBorder.style.left = rect.left - 5 + 'px';
            focusBorder.style.top = rect.top + window.scrollY - 5 + 'px';
            focusBorder.style.width = rect.width + 10 + 'px';
            focusBorder.style.height = rect.height + 10 + 'px';
            focusBorder.style.border = '5px solid ' + color;
            document.body.appendChild(focusBorder);
            return focusBorder;
        }, handle);
    }
    // private async screenshotBeforeClick(frame: puppeteer.Frame, handle: puppeteer.ElementHandle) {
    //   const fucosBorderHandle = await this.addRedBorder4Handle(frame, handle)
    //   await this.saveScreenShot()
    //   await frame.evaluate((redBorderHandle) => {
    //     redBorderHandle.remove()
    //   }, fucosBorderHandle)
    // }
    async genTaskResult(auditsResult) {
        const deviceInfo = iPhoneX;
        const resultDeviceInfo = {
            os: "ios",
            screenWidth: deviceInfo.viewport.width,
            screenHeight: deviceInfo.viewport.height,
            model: deviceInfo.name,
            dpr: deviceInfo.viewport.deviceScaleFactor,
        };
        const nonWebviewPage = Object.keys(this.urlPathMap).filter((key) => !this.urlPathMap[key].isWebview).length;
        const crawlPageTotal = Object.keys(this.urlPathMap).length;
        const noResult = auditsResult.score_num === undefined;
        const hasDonePages = this.taskResult.pages.length !== 0;
        let isAllWebview = hasDonePages;
        this.taskResult.pages.forEach((item) => isAllWebview = isAllWebview ? item.is_webview == 1 : isAllWebview);
        this.log.info(`noResult ${noResult}, hasDonePages ${hasDonePages}, isAllWebview ${isAllWebview}`);
        this.taskFinishedTime = Date.now();
        this.log.info(`time used ${this.taskFinishedTime - this.taskStartTime}ms`);
        Object.assign(this.taskResult, {
            action_history: [],
            // cover_path_ratio: Object.keys(this.urlPathMap).length / this.wxConfig.pages.length,
            device_info: resultDeviceInfo,
            // driverTimeCost: this.taskFinishedTime - this.taskStartTime,
            // ideStartTime: this.driverStartTime,
            normalSearchPageCount: nonWebviewPage,
            recoverSuccess: nonWebviewPage,
            recoverTotal: crawlPageTotal,
            // redirectToPageCount:
            // sessionCreateTime:
            // result_status: ,
            tabbars: this.wxConfig.tabBar && this.wxConfig.tabBar.list && this.wxConfig.tabBar.list.length ? this.wxConfig.tabBar.list.map((item) => item.pagePath) : [],
            timeCost: this.taskFinishedTime - this.driverStartTime,
            totalPageCount: this.wxConfig && this.wxConfig.pages ? this.wxConfig.pages.length : 0,
        });
        if (noResult) {
            this.taskResult.ide_ext_info = JSON.stringify({
                audits: {
                    isAppDead: this.isAppDead,
                    isAllWebview: false,
                    totalClickCount: this.clickCnt,
                    isTimeout: this.isTimeout,
                    jsCoverage: this.jsCoverage,
                    result: [],
                    score_num: 0
                }
            });
        }
        else if (isAllWebview) {
            reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.IS_All_WEBVIEW);
            this.taskResult.ide_ext_info = JSON.stringify({
                audits: {
                    isAllWebview: true,
                    totalClickCount: this.clickCnt,
                    isTimeout: this.isTimeout,
                    jsCoverage: this.jsCoverage,
                    result: [],
                    score_num: 0
                }
            });
        }
        else if (auditsResult.score_num !== undefined) {
            this.taskResult.ide_ext_info = JSON.stringify({
                audits: {
                    totalClickCount: this.clickCnt,
                    isTimeout: this.isTimeout,
                    jsCoverage: this.jsCoverage,
                    result: JSON.stringify(auditsResult),
                    score_num: auditsResult.score_num
                }
            });
        }
        await fs.writeFile(path.join(this.resultPath, `${this.appid}.json`), JSON.stringify(this.taskResult));
        return this.taskResult;
    }
}
exports.default = AuditsAuto;


/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const utils = __webpack_require__(15);
const url_1 = __webpack_require__(7);
const events_1 = __webpack_require__(1);
class NetworkListener extends events_1.EventEmitter {
    constructor(page) {
        super();
        this.requestCount = 0;
        this.handler = {};
        this.requestIdMap = new WeakMap();
        this.requestEventMap = {
            request: new WeakMap(),
            requestfailed: new WeakMap(),
            requestfinished: new WeakMap(),
            response: new WeakMap()
        };
        this.requestIdInfo = {};
        this.page = page;
        this.initHandlerSet();
        this.initNetworkListening(page);
    }
    initHandlerSet() {
        this.handler['request'] = new Set();
        this.handler['requestfailed'] = new Set();
        this.handler['requestfinished'] = new Set();
        this.handler['response'] = new Set();
    }
    mapRequest2Detail(request, response) {
        const url = this.getRealUrl(request.url());
        const isProxy = url != request.url();
        const requestId = this.requestIdMap.get(request) || ++this.requestCount;
        const currentTime = Date.now();
        const fromCache = response ? response.fromCache() : undefined;
        const failure = request.failure();
        const error = failure ? failure.errorText : '';
        const statusCode = response ? response.status().toString() : undefined;
        let headers = [];
        let requestInfo = this.requestIdInfo[requestId];
        if (!requestInfo) {
            this.requestIdMap.set(request, requestId);
            requestInfo = this.requestIdInfo[requestId] = { request, timeStamp: currentTime };
        }
        if (response) {
            const headerObject = response.headers();
            headers = Object.keys(headerObject).map((headerKey) => {
                return {
                    name: headerKey,
                    value: headerObject[headerKey]
                };
            });
        }
        return {
            requestId,
            type: request.resourceType(),
            url,
            timeStamp: currentTime,
            responseHeaders: headers,
            fromCache,
            statusCode,
            costTime: currentTime - requestInfo.timeStamp,
            isProxy,
            error
        };
    }
    getRealUrl(url) {
        if (url.indexOf('wxacrawlerrequest/proxy') > -1) {
            let tmpUrlObj = url_1.parse(url, true);
            url = typeof tmpUrlObj.query.url == 'string' ? tmpUrlObj.query.url : tmpUrlObj.query.url[0];
        }
        return url;
    }
    getNetworkEventSource(request, details) {
        var frame = request.frame();
        if (!frame)
            return 'unknow';
        // console.log(`${frame.name()} ${request.url()}`)
        // 由于appservice的请求可能会被native层加代理，所以请求来源的frame可能是native而不是appservice
        if (frame.name() === 'appservice' || details.isProxy) {
            // this.log.debug('networkListener request from service', details.requestId)
            return 'appservice';
        }
        else if (/^webview\-/.test(frame.name())) {
            // this.log.debug('networkListener request from webview', frameId, details.requestId)
            return 'webview';
        }
        return 'unknow';
    }
    initNetworkListening(page) {
        page.on('request', async (request) => {
            let url = this.getRealUrl(request.url());
            if (!utils.isRequestNotForAudit(url)) {
                // this.log.debug('request url:',  url)
                if (this.requestEventMap.request.get(request))
                    return;
                this.requestEventMap.request.set(request, true);
                const frame = request.frame();
                if (frame) {
                    const details = this.mapRequest2Detail(request);
                    const eventInfo = {
                        eventName: 'onBeforeRequest',
                        type: this.getNetworkEventSource(request, details),
                        details
                    };
                    if (eventInfo.type != 'unknow') {
                        this.emit('ON_REQUEST_EVENT', eventInfo);
                    }
                }
            }
        });
        page.on('requestfailed', (request) => {
            let url = this.getRealUrl(request.url());
            if (!utils.isRequestNotForAudit(url)) {
                const requestId = this.requestEventMap.request.get(request);
                const frame = request.frame();
                if (requestId && frame) {
                    const details = this.mapRequest2Detail(request);
                    const eventInfo = {
                        eventName: 'onErrorOccurred',
                        type: this.getNetworkEventSource(request, details),
                        details
                    };
                    if (eventInfo.type != 'unknow') {
                        this.emit('ON_REQUEST_EVENT', eventInfo);
                    }
                }
            }
        });
        page.on('requestfinished', (request) => {
            let url = this.getRealUrl(request.url());
            if (!utils.isRequestNotForAudit(url)) {
                const requestId = this.requestEventMap.request.get(request);
                const frame = request.frame();
                if (requestId && frame) {
                    const details = this.mapRequest2Detail(request, request.response());
                    const eventInfo = {
                        eventName: 'onCompleted',
                        type: this.getNetworkEventSource(request, details),
                        details
                    };
                    if (eventInfo.type != 'unknow') {
                        this.emit('ON_REQUEST_EVENT', eventInfo);
                    }
                }
            }
        });
        page.on('response', async (response) => {
            const request = response.request();
            let url = this.getRealUrl(request.url());
            if (!utils.isRequestNotForAudit(url)) {
                // this.log.debug(`response url: ${url} isRequestNotForAudits ${utils.isRequestNotForAudit(url)}`)
                const requestId = this.requestEventMap.request.get(request);
                const frame = request.frame();
                if (requestId && frame) {
                    const details = this.mapRequest2Detail(request, response);
                    const eventInfo = {
                        eventName: 'onHeadersReceived',
                        type: this.getNetworkEventSource(request, details),
                        details
                    };
                    if (eventInfo.type != 'unknow') {
                        details.timeStamp = Date.now();
                        this.emit('ON_REQUEST_EVENT', eventInfo);
                        eventInfo.eventName = 'onResponseStarted';
                        this.emit('ON_REQUEST_EVENT', eventInfo);
                    }
                }
            }
        });
    }
}
exports.default = NetworkListener;


/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

module.exports.$ = function (selector, el) {
  if (typeof el === 'string') {
    el = document.querySelector(el);
  }

  return (el || document).querySelector(selector);
};

module.exports.$$ = function (selector) {
  return document.querySelectorAll(selector);
};

module.exports.show = function (el) {
  if (typeof el === 'string') {
    el = document.querySelector(el);
  }

  el.style.display = '';
};

module.exports.hide = function (el) {
  if (typeof el === 'string') {
    el = document.querySelector(el);
  }

  el.style.display = 'none';
};

module.exports.sprintf = function (str, args) {
  for (let i = 0; i < args.length; i++) {
    str = str.replace(/%s/, args[i]);
  }
  return str;
};

module.exports.reportBehavior = function (data) {
  // data: score_num, score_level, failed_detail, ignored_detail, use_time
  this.log('reportBehavior', data);
  pluginMessager.invoke('REPORT', JSON.stringify(data));
};

module.exports.log = function () {
  if (false) {}
};

module.exports.formatSize = function (size) {
  const units = ['B', 'K', 'M', 'G'];
  let unit;
  while ((unit = units.shift()) && size > 1024) {
    size /= 1024;
  }
  return (unit === 'B' ? size : size.toFixed(2)) + unit;
};

module.exports.hash = function (text) {
  let hash = 5381;
  let index = text.length;

  while (index) {
    hash = hash * 33 ^ text.charCodeAt(--index);
  }

  return hash >>> 0;
};

//  计算字符串字符数
module.exports.byteCount = function (s) {
  return encodeURI(s).split(/%..|./).length - 1;
};

//  数组去重
module.exports.unique = function (arr) {
  // return Array.from(new Set(array));
  const newArr = [];
  for (let i = 0; i < arr.length; i++) {
    if (newArr.indexOf(arr[i]) === -1) {
      newArr.push(arr[i]);
    }
  }
  return newArr;
};

module.exports.getType = function (val) {
  return Object.prototype.toString.call(val).slice(8, -1).toLowerCase();
};

module.exports.compareVersion = function (v1, v2) {
  v1 = v1.split('.');
  v2 = v2.split('.');
  const len = Math.max(v1.length, v2.length);

  while (v1.length < len) {
    v1.push('0');
  }
  while (v2.length < len) {
    v2.push('0');
  }

  for (let i = 0; i < len; i++) {
    const num1 = parseInt(v1[i]);
    const num2 = parseInt(v2[i]);

    if (num1 > num2) {
      return 1;
    } else if (num1 < num2) {
      return -1;
    }
  }

  return 0;
};

module.exports.isRequestNotForAudit = function (url) {
  const invalidDomainReg = [/^data\:/,
  // 云函数长轮询请求
  /^https:\/\/servicewechat.com\/wxa-qbase\/qbasecheckresult/, /^https?:\/\/[^/]*\.tcb\.qcloud\.la\//,
  // 广告组件的资源
  /^https?:\/\/wxsnsdythumb\.wxs\.qq\.com\//, /^https?:\/\/mmbiz\.qpic\.cn\//,
  // /^https?:\/\/wx\.qlogo\.cn\//,
  /^https?:\/\/[^/]*\.qlogo\.cn\//,
  // 地图组件的资源
  /^https?:\/\/[^/]*\.qq\.com\//, /^https?:\/\/[^/]*\.gtimg\.com\//, /^https?:\/\/[^/]*\.myapp\.com\//,
  // 工具内部请求
  /^http:\/\/127.0.0.1:/,
  // 扩展
  /^chrome-extension:\/\//,
  // runtime环境
  /^https?:\/\/servicewechat\.com\//, /\/audits\/assert\//, /\/wxacrawler\//, /^https?:\/\/[^/]*\.weixinbridge\.com\//];

  for (let i = 0; i < invalidDomainReg.length; i++) {
    if (url.match(invalidDomainReg[i])) {
      return true;
    }
  }

  return false;
};

const filterLibStack = function (stacks) {
  return stacks.filter(stack => {
    return !/^(__dev__|__asdebug__|__pageframe__|appservice\?)|audits\/assert\/inject|WAService.js|WAWebview.js|wxacrawler\/public/.test(stack.file);
  });
};

module.exports.parseStackStrings = function (stackStr, filterLib = true) {
  let stacks = stackStr.split('\n');
  let REG_EXP = /at\s+([\S]+)\s+\((\S+)\)/;
  let result = stacks.map(stack => {
    let result = stack.match(REG_EXP);
    if (result && result[1] && result[2]) {
      let fileString = result[2].replace(/^\s*/, '').replace(/http:\/\/127\.0\.0\.1:\d+\/(:?(:?appservice|wxacrawler\/\d+\/program\/\w+)?\/)?/, '');
      let [file, line, column] = fileString.split(':');
      if (fileString.split(':').length == 3) {
        return {
          func: result[1].replace(/^Audit_(setTimeout|setInterval)_?.*$/, '$1'),
          file,
          line: +line,
          column: +column
        };
      }
    }
    return null;
  }).filter(stack => !!stack);

  if (filterLib) {
    result = filterLibStack(result);
  }

  return result;
};

module.exports.getCallStack = function (filterLib = true) {
  let result = exports.parseStackStrings(new Error().stack);

  if (filterLib) {
    result = filterLibStack(result);
  }

  return result;
};

module.exports.onGenerateFuncReady = function (func) {
  if (window.__generateFunc__) {
    setTimeout(func);
  } else {
    document.addEventListener('generateFuncReady', func);
  }
};

module.exports.status = 'running';

module.exports.trim = function (str) {
  return str.replace(/^\s*|\s*$/g, '');
};

module.exports.nodeIDClassText = function (node) {
  const idStr = node.id ? `#${node.id}` : '';
  const className = module.exports.trim(node.className);
  const classStr = className ? '.' + className.replace(/\s+/, '.') : '';

  return node.tagName.toLowerCase().replace(/^wx-/, '') + idStr + classStr;
};

/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = __webpack_require__(1);
const utils = __webpack_require__(3);
const log_1 = __webpack_require__(0);
class MinaHeartbeat extends events_1.EventEmitter {
    constructor(options) {
        super();
        this.timeoutCnt = 0;
        this.page = options.page;
        this.startHeartbeat();
        this.timeoutCnt = 0;
    }
    startHeartbeat() {
        utils.timeoutEvaluatePage(this.page, 10000, () => {
            return console.log('audits crawler heart beat');
        }).then(() => {
            log_1.default.debug('heart beat ok');
            setTimeout(() => this.startHeartbeat(), 10000);
        }).catch(() => {
            log_1.default.debug('heart beat error');
            this.timeoutCnt++;
            if (this.timeoutCnt >= 3) {
                this.emit('NO_HEART_BEAT');
            }
            setTimeout(() => this.startHeartbeat(), 10000);
        });
    }
}
exports.default = MinaHeartbeat;


/***/ }),
/* 17 */
/***/ (function(module, exports) {

module.exports = require("jimp");

/***/ }),
/* 18 */
/***/ (function(module, exports) {

module.exports = require("log4js");

/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = __webpack_require__(1);
const qs = __webpack_require__(8);
const log_1 = __webpack_require__(0);
const utils_1 = __webpack_require__(3);
const reportIdKey_1 = __webpack_require__(2);
class Hijack extends events_1.EventEmitter {
    frameEvaluate(frame, func, ...args) {
        if (!frame.isDetached()) {
            return frame.evaluate(func, ...args);
        }
        else {
            // reportIdKey(IdKey.FRAME_DETACHED);
            throw new Error(`frame detached! name:${frame.name}`);
        }
    }
    constructor(page) {
        super();
        this.page = page;
        this.initEvent();
    }
    initEvent() {
        this.page.on('dialog', async (dialog) => {
            reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.DIALOG_EVENT);
            log_1.default.info('dialog event invoked, dismiss dialog');
            await dialog.dismiss();
        });
        this.page.on('console', (msg) => {
            if (msg.type() === 'info') {
                const source = msg.text();
                if (source.indexOf('://') === -1)
                    return;
                const match = source.split('://');
                const type = match[0];
                switch (type) {
                    case 'redirectTo':
                    case 'navigateTo':
                    case 'switchTab':
                    case 'reLaunch':
                    case 'navigateBack':
                        const url = match[1] || '';
                        this.emit('URL_CHANGE', { url, type });
                        break;
                    case 'publishPageEvent':
                        const [name, query] = match[1].split('?');
                        const params = qs.parse(query);
                        params.name = name;
                        this.emit('PAGE_EVENT', params);
                        // Logger.logInfo(`PAGE_EVENT:${name},webviewId:${params.webviewId}`);
                        break;
                    default:
                        return;
                }
            }
        });
    }
    hijackDefault({ longitude, latitude }) {
        return this.page.evaluate((isDebug, longitude, latitude) => {
            if (isDebug) {
                localStorage.setItem('RUNTIME_ENV', 'development');
            }
            try {
                Object.defineProperty(navigator, 'language', {
                    get() {
                        return 'zh-CN';
                    }
                });
            }
            catch (e) { }
            window.native.sdk.getLocation = async function () {
                return { errMsg: 'getLocation:ok', longitude: longitude, latitude: latitude };
            };
            window.shareData = null;
            window.native.sdk.shareAppMessageDirectly
                = window.native.sdk.shareAppMessage = async function (data) {
                    window.shareData = data.args;
                };
            window.native.setOption('autoPermission', true);
            window.native.setOption('autoAuthorization', true);
            // hack 一些弹窗操作
            window.native.sdk.chooseVideo
                = window.native.sdk.openLocation
                    = window.native.sdk.openAddress
                        = window.native.sdk.openWeRunSetting
                            = window.native.sdk.openSetting
                                = window.native.sdk.chooseImage
                                    = window.native.sdk.chooseInvoiceTitle
                                        = window.native.sdk.showModal
                                            = window.native.sdk.enterContack
                                                = window.native.sdk.previewImage = function (data = {}) {
                                                    return {
                                                        errMsg: `${data.api}:ok`,
                                                    };
                                                };
            window.alert = window.console.log; // 全局替换掉alert,禁掉同步执行
        }, !!process.env.DEBUG, longitude, latitude);
    }
    hijackPageEvent() {
        return this.page.evaluate(() => {
            // webviewPublishPageEvent
            if (!window.__handleWebviewPublish) {
                window.__handleWebviewPublish = window.native.handleWebviewPublish;
                window.native.handleWebviewPublish = function (msg) {
                    const name = msg.data.eventName;
                    if (name === 'PAGE_EVENT') {
                        const pageEventName = msg.data.data.data.eventName;
                        const webviewId = msg.webviewId;
                        console.info(`publishPageEvent://${pageEventName}?webviewId=${webviewId}`);
                    }
                    window.__handleWebviewPublish.apply(window.native, [msg]);
                };
                window.__handleAppServicePublish = window.native.handleAppServicePublish;
                window.native.handleAppServicePublish = function (msg) {
                    const name = msg.data.eventName;
                    if (name === 'onAppRoute') {
                        const params = msg.data.data.data;
                        // const {openType, webviewId, path, query} = msg!.data!.data!.data;
                        const query = Object.keys(params).map((key) => {
                            return `${key}=${encodeURIComponent(params[key])}`;
                        }).join('&');
                        console.info(`publishPageEvent://onAppRoute?${query}`);
                    }
                    window.__handleAppServicePublish.apply(window.native, [msg]);
                };
            }
        });
    }
    hijackNavigation() {
        return this.page.evaluate(() => {
            window.native.navigator.redirectTo = function (url) {
                console.info(`redirectTo://${url}`);
                return;
            };
            window.native.navigator.navigateTo = function (url) {
                console.info(`navigateTo://${url}`);
                return;
            };
            window.native.navigator.switchTab = function (url) {
                console.info(`switchTab://${url}`);
                return;
            };
            window.native.navigator.reLaunch = function (url) {
                console.info(`reLaunch://${url}`);
                return;
            };
            window.native.navigator.navigateBack = function (url) {
                console.info(`navigateBack://${url}`);
                return;
            };
            // 右上角的回到首页也需要劫持，主动发现进，某些情况会触发
            window.native.navigator.launch = function (url) {
                console.info(`launch://${url}`);
                return;
            };
            window.native.webviewManager.removeAll = function () {
                return;
            };
        });
    }
    waitFor(event, key, timeout = 1000) {
        return new Promise((resolve, reject) => {
            const cb = (args) => {
                resolve(args[key]);
            };
            this.once(event, cb);
            setTimeout(() => {
                reject('timeout');
                this.removeListener(event, cb);
            }, timeout);
        });
    }
    waitForUrl(timeout = 1000) {
        return this.waitFor('URL_CHANGE', 'url', timeout);
    }
    waitForPageEvent(eventName, opt = { timeout: 1000 }) {
        return new Promise((resolve, reject) => {
            const cb = ({ webviewId, name }) => {
                if (eventName === name) {
                    if (opt.webviewId === undefined || opt.webviewId === webviewId) {
                        resolve('ok');
                        this.removeListener('PAGE_EVENT', cb);
                    }
                }
            };
            this.on('PAGE_EVENT', cb);
            setTimeout(() => {
                reject('timeout');
                this.removeListener('PAGE_EVENT', cb);
            }, opt.timeout);
        });
    }
    /**
     * 点击前先劫持一些webview侧的弹窗操作
     * @param {Frame} frame
     */
    hijackWebivewAlert(frame) {
        return utils_1.frameEvaluate(frame, (...args) => {
            window.alert = window.console.log;
        });
    }
}
exports.default = Hijack;


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = __webpack_require__(1);
const log_1 = __webpack_require__(0);
const domUtils_1 = __webpack_require__(21);
const FrameData_1 = __webpack_require__(22);
const reportIdKey_1 = __webpack_require__(2);
class PageBase extends events_1.EventEmitter {
    constructor(page, opt = {}) {
        super();
        this.log = log_1.default;
        this.page = page;
        this.isMpcrawler = opt.isMpcrawler || false;
        this.frameMap = new Map();
        const mainFrame = page.mainFrame();
        this.mainFrameData = new FrameData_1.default(mainFrame, { isMainFrame: true, isMpcrawler: this.isMpcrawler });
        this.frameMap.set(mainFrame, this.mainFrameData);
        this.disableImg = opt.disableImg || false;
        this.disableMedia = opt.disableMedia || false;
        this.initTs = Date.now();
    }
    initPageEvent() {
        const page = this.page;
        page.on('frameattached', (frame) => {
            const frameData = new FrameData_1.default(frame, {
                disableImg: this.disableImg,
                disableMedia: this.disableMedia,
                isMpcrawler: this.isMpcrawler
            });
            this.frameMap.set(frame, frameData);
        });
        page.on('framedetached', (frame) => {
            log_1.default.debug('frame detach: ', frame.name());
            const frameData = this.frameMap.get(frame);
            if (frameData) {
                frameData.emit('detach', frame.name());
                this.frameMap.delete(frame);
            }
        });
        page.on('request', async (request) => {
            const frame = request.frame();
            if (!frame)
                return;
            const frameData = this.frameMap.get(frame);
            if (!frameData)
                return;
            frameData.onRequestStart(request);
        });
        page.on('requestfailed', async (request) => {
            const sourceType = request.resourceType();
            if (sourceType !== 'image' && sourceType !== 'media') {
                // debug(`failed request ${request.resourceType()}: ${request.url()}`);
            }
            const frame = await request.frame();
            if (!frame)
                return;
            const frameData = this.frameMap.get(frame);
            if (!frameData)
                return;
            frameData.onRequestEnd(request, 'failed');
        });
        page.on('requestfinished', async (request) => {
            const frame = await request.frame();
            if (!frame)
                return;
            const frameData = this.frameMap.get(frame);
            if (!frameData)
                return;
            const response = request.response();
            if (response && !/^(2|3)\d\d$/.test(response.status().toString())) {
                log_1.default.error(`failed request! status = ${response.status()}.`);
                frameData.onRequestEnd(request, 'failed');
            }
            else {
                frameData.onRequestEnd(request, 'finished');
            }
        });
        page.on('pageerror', (error) => {
            log_1.default.error(`pageerror occur! ${error.message} ${error.stack}`);
            reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.PAGE_EXCEPTION);
        });
        page.on('error', (err) => {
            log_1.default.error(`page error occur:`, err);
            try {
                log_1.default.debug('page error occur and going to crash:', page.url());
            }
            catch (err) {
            }
            reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.PAGE_CRASH);
            this.emit('pageError', err);
        });
    }
    async waitForCurrentFrameIdle(timeoutCnt = 0) {
        const { frame, id } = await domUtils_1.getCurrentFrame(this.page);
        const frameData = this.getFrameData(frame);
        if (!frame || !frameData) {
            // really not likely
            reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.PAGE_NO_FRAME);
            this.log.debug(`no frame or frameData !!!`);
            return { frame: undefined, hasWebview: false, frameData, timeout: 0, id };
        }
        this.log.debug(`get current frame[${frame.name()}] done`);
        const isWebview = await domUtils_1.hasWebview(frame);
        this.log.debug(`check has webview [${isWebview}] done`);
        if (isWebview) {
            // 包含webview，直接任务失败, 页面是否包含webview，在 page dom ready后就可以知道
            log_1.default.debug('task fail because page has webview');
            reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.PAGE_IS_WEBVIEW);
            return { hasWebview: true, frame, frameData, timeout: 0, id };
        }
        // if fail because of frame detach, try to return new frame
        // 需要mainFrame（waitCode1)和当前frame(waitCode2)的网络同时空闲
        const [waitCode1, waitCode2] = await Promise.all([this.mainFrameData.waitForNetworkIdle(), frameData.waitForNetworkIdle()]);
        const currentId = await domUtils_1.getCurrentId(this.page);
        if (waitCode2 === -2 || frame.isDetached() || id !== currentId) {
            // waitCode2 = 0 但其实frame已经detach的，发生在页面先networkidle再被detach的case, 所以这里要兼容一下
            // 在等当前frame网络时，页面跳转，当前frame已经变，需要重新获取
            // 还有一种case是，延时一会再有跳转，这种情况暂时无办法处理
            log_1.default.debug(`wait for current frame[${frame.name()}] idle fail: already detach, try again`);
            return this.waitForCurrentFrameIdle(timeoutCnt); // 等待时frame detach了，需要重新拿当前frame;
            // return {hasWebview: false, frame: undefined, frameData, timeout: 0, id}
        }
        else if (waitCode1 === -1 || waitCode2 === -1) {
            log_1.default.debug(`frame[${frame.name()}] idle timeout, code: `, waitCode1, waitCode2);
            timeoutCnt++;
        }
        log_1.default.debug(`current frame[${frame.name()}] network idle done`);
        return { hasWebview: false, frame, frameData, timeout: timeoutCnt, id };
    }
    // protected async waitForFrameIdle(frame: puppeteer.Frame, timeout: number) {
    //     const frameData = this.getFrameData(frame);
    //     if (!frameData) return Promise.resolve(-2);
    //     const [waitCode1, waitCode2] = await Promise.all([this.mainFrameData.waitForNetworkIdle(timeout), frameData.waitForNetworkIdle(timeout)]);
    //     debug('wait for frame idle', waitCode1, waitCode2);
    //     return Promise.resolve(waitCode2);
    // }
    getFrameData(frame) {
        return this.frameMap.get(frame);
    }
    async waitForFrameChange(webviewId, { timeout }) {
        return this.page.waitFor((id) => window.native.webviewManager.getCurrent().id !== id, { timeout }, webviewId);
    }
    isPageRedirected(url) {
        return this.page.evaluate((url) => {
            return url.indexOf(location.pathname) === -1;
        }, url);
    }
    getTime() {
        return Date.now() - this.initTs;
    }
}
exports.default = PageBase;


/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const await_to_js_1 = __webpack_require__(4);
// import {IdKey} from "../config";
const log_1 = __webpack_require__(0);
const utils_1 = __webpack_require__(3);
async function getCurrentFrame(page) {
    const id = await getCurrentId(page);
    // debug('get Current Frame Id:', id);
    const frame = await getCurrentFrameByWebviewId(page, id);
    return {
        frame,
        id
    };
}
exports.getCurrentFrame = getCurrentFrame;
function getCurrentId(page) {
    return page.evaluate(() => {
        const current = window.native.webviewManager.getCurrent();
        return current.id;
    });
}
exports.getCurrentId = getCurrentId;
async function getCurrentFrameData(page, frameMap) {
    const { frame } = await getCurrentFrame(page);
    if (!frame)
        return undefined;
    return frameMap.get(frame);
}
exports.getCurrentFrameData = getCurrentFrameData;
async function getCurrentFrameByWebviewId(page, webviewId) {
    const frameList = await page.frames();
    const pendingFrame = [];
    for (const frame of frameList) {
        if (frame.name() === '') {
            pendingFrame.push(frame);
            continue;
        }
        if (frame.name() === `webview-${webviewId}`) {
            // Logger.info(`found webview-${webviewId}!!!`);
            return frame;
        }
    }
    // in the pending frame wait for it and return
    // debug('get current frame by id in pending list');
    for (const frame of pendingFrame) {
        const [waitTimeout] = await await_to_js_1.default(frame.waitForNavigation({ timeout: 1000 }));
        if (frame.name() === `webview-${webviewId}`) {
            return frame;
        }
    }
}
exports.getCurrentFrameByWebviewId = getCurrentFrameByWebviewId;
async function getAppServiceFrame(page) {
    const frameList = await page.frames();
    for (const frame of frameList) {
        if (frame.name() === 'appservice') {
            return frame;
        }
    }
    return null;
}
exports.getAppServiceFrame = getAppServiceFrame;
function scrollToTop(frame) {
    return utils_1.frameEvaluate(frame, () => {
        // @todo 判定当前页面是否有scroll-view, 有scroll-view时，需要别的方式滚动
        window.scrollTo(0, 0);
    });
}
exports.scrollToTop = scrollToTop;
function scrollToBottom(frame) {
    return utils_1.frameEvaluate(frame, () => {
        // @todo 判定当前页面是否有scroll-view, 有scroll-view时，需要别的方式滚动
        const height = document.body.scrollHeight;
        const windowHeight = window.innerHeight;
        window.scrollTo(0, height - windowHeight);
        // window.wx.publishPageEvent('onReachBottom', {});
    });
}
exports.scrollToBottom = scrollToBottom;
function scrollDown(frame) {
    return utils_1.frameEvaluate(frame, () => {
        const scrollTop = window.scrollY;
        const windowHeight = window.innerHeight;
        window.scrollTo(0, scrollTop + windowHeight - 64);
        return window.innerHeight;
    });
}
exports.scrollDown = scrollDown;
function elemInWindow(frame) {
}
exports.elemInWindow = elemInWindow;
function dumpScopeDataToDOMNode(frame) {
    return utils_1.frameEvaluate(frame, () => {
        try {
            window.__virtualDOM__.spreadScopeDataToDOMNode();
        }
        catch (e) {
            console.log(`scope data error ${e.message} ${e.stack}`);
        }
    });
}
exports.dumpScopeDataToDOMNode = dumpScopeDataToDOMNode;
function getFrameHtml(frame) {
    return utils_1.frameEvaluate(frame, () => {
        try {
            window.__virtualDOM__.spreadScopeDataToDOMNode();
        }
        catch (e) {
            console.log(`scope data error ${e.message} ${e.stack}`);
        }
        const styleSheets = document.styleSheets;
        let css = '';
        const elements = document.querySelectorAll('*');
        for (let i = 0, len = elements.length; i < len; i++) {
            const el = elements[i];
            for (let i = 0, len = styleSheets.length; i < len; i++) {
                const cssRules = styleSheets[i].cssRules;
                for (let i = 0, len = cssRules.length; i < len; i++) {
                    const rule = cssRules[i];
                    if (rule.added) {
                        continue;
                    }
                    if (el.webkitMatchesSelector(rule.selectorText)) {
                        rule.added = true;
                        css += rule.cssText;
                    }
                }
            }
        }
        return `<html><meta charset="UTF-8"><meta name="viewport" content="width=device-width,
                user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"><style>${css}</style>
                ${document.body.outerHTML}`;
    });
}
exports.getFrameHtml = getFrameHtml;
async function getElemCrw(elem, frame) {
    const [err, crw] = await await_to_js_1.default(utils_1.frameEvaluate(frame, (elem) => {
        const rect = elem.getBoundingClientRect();
        const comStyle = window.getComputedStyle(elem);
        return `${rect.left},${rect.top},${rect.right},${rect.bottom},${comStyle.fontSize},${comStyle.borderWidth},${comStyle.backgroundColor},${comStyle.borderColor},${comStyle.color},${comStyle.padding},${comStyle.margin}`;
    }, elem));
    if (err) {
        log_1.default.error('fail get elem crw', err);
        return '';
    }
    return crw;
}
exports.getElemCrw = getElemCrw;
async function insertCrwInfo(frame) {
    const msg = await utils_1.frameEvaluate(frame, () => {
        // @ts-ignore
        function traverseElement(el) {
            const childElCnt = el.childElementCount;
            for (let i = 0; i < childElCnt; ++i) {
                const rect = el.children[i].getClientRects();
                const comStyle = window.getComputedStyle(el.children[i]);
                let crwAttr = '';
                if (rect.length) {
                    crwAttr = `${rect[0].left},${rect[0].top},${rect[0].right},`
                        + `${rect[0].bottom},${comStyle.fontSize},${comStyle.borderWidth},`
                        + `${comStyle.backgroundColor},${comStyle.borderColor},${comStyle.color},`
                        + `${comStyle.padding},${comStyle.margin}`;
                    el.children[i].setAttribute('wx-crw', crwAttr);
                }
                traverseElement(el.children[i]);
            }
        }
        try {
            window.scrollTo(0, 0);
            traverseElement(document.body);
        }
        catch (e) {
            console.log(`traverseElement error ${e.message} ${e.stack}`);
            return e.message;
        }
        return 'ok';
    });
    if (msg !== 'ok') {
        log_1.default.error(`insertCrwInfo error! ${msg}`);
        // reportIdKey(IdKey.INSERT_CRW_ERR);
    }
    return msg;
}
exports.insertCrwInfo = insertCrwInfo;
async function getAndInsertShareData(page, frame) {
    let shareData;
    try {
        await page.evaluate(() => {
            // 触发分享
            const webview = window.native.webviewManager.getCurrent();
            window.native.appServiceMessenger.send({
                command: 'APPSERVICE_ON_EVENT',
                data: {
                    eventName: 'onShareAppMessage',
                    data: {
                        path: webview.url,
                        mode: 'common',
                    },
                },
                webviewId: webview.id,
            });
        });
        await utils_1.sleep(200);
        shareData = await page.evaluate(() => {
            console.log(window.shareData);
            return window.shareData;
        });
    }
    catch (e) {
        log_1.default.error(`!!!!! getShareData evaluate failed ${e.message} ${e.stack}`);
    }
    log_1.default.info(`sharedata is ${JSON.stringify(shareData)}`);
    if (shareData && (shareData.hasOwnProperty("title") || shareData.hasOwnProperty("imageUrl"))) {
        const realShareData = {
            "title": shareData.title ? shareData.title : "",
            "imageUrl": ""
        };
        if (shareData.imageUrl && await utils_1.checkImageValid(shareData.imageUrl) === 0) {
            realShareData.imageUrl = shareData.imageUrl;
        }
        else {
            log_1.default.error(`image:${shareData.imageUrl} is invalid!`);
        }
        await utils_1.frameEvaluate(frame, (sData) => {
            document.body.setAttribute('wx-share-data', JSON.stringify(sData));
        }, realShareData);
    }
}
exports.getAndInsertShareData = getAndInsertShareData;
function getFrameInfo(frame) {
    return utils_1.frameEvaluate(frame, () => {
        return {
            pageHeight: document.body.offsetHeight,
            windowHeight: window.innerHeight,
        };
    });
}
exports.getFrameInfo = getFrameInfo;
async function getUserInfo(frame, page) {
    const frameList = await page.frames();
    for (const frame of frameList) {
        if (frame.name() === 'appservice') {
            const [err, userInfo] = await await_to_js_1.default(utils_1.frameEvaluate(frame, () => {
                return new Promise((resolve, reject) => {
                    // @ts-ignore
                    wx.getUserInfo({
                        // @ts-ignore
                        success(res) {
                            resolve(res.userInfo);
                        },
                        fail() {
                            reject('');
                        }
                    });
                });
            }));
            log_1.default.info(`userinfo is ${JSON.stringify(userInfo)}`);
            if (userInfo) {
                return userInfo;
            }
            else {
                // reportIdKey(IdKey.GET_USERINFO_EMPTY);
                return {};
            }
        }
    }
    return;
}
exports.getUserInfo = getUserInfo;
function getWebviewInfo(page) {
    return page.evaluate(() => {
        const currentWebview = window.native.webviewManager.getCurrent();
        return {
            url: currentWebview.url,
            id: currentWebview.id,
            path: currentWebview.path,
            pageTitle: currentWebview.pageConfig.window.navigationBarTitleText,
            stack: window.native.webviewManager.getPageStack().map((webview) => webview.path),
        };
    });
}
exports.getWebviewInfo = getWebviewInfo;
function hasWebview(frame) {
    return utils_1.frameEvaluate(frame, () => {
        return document.querySelector('wx-web-view') !== null;
    });
}
exports.hasWebview = hasWebview;
function insertTaskInfo(taskInfo, frame) {
    const d = new Date();
    taskInfo.time = d.toLocaleString();
    return utils_1.frameEvaluate(frame, (sData) => {
        document.body.setAttribute('wx-crawler-taskinfo', JSON.stringify(sData));
    }, taskInfo);
}
exports.insertTaskInfo = insertTaskInfo;


/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = __webpack_require__(1);
const log_1 = __webpack_require__(0);
const reportIdKey_1 = __webpack_require__(2);
const BlackList = {
    "https://log.mengtuiapp.com/report/v1": true,
    "https://log.aldwx.com/d.html": true,
    "log.aldwx.com": true
};
let reportNewProxyIp = false;
class FrameData extends events_1.EventEmitter {
    constructor(frame, opt = {}) {
        super();
        this.extra = {};
        this.requestMap = new Map();
        this.frame = frame;
        this.requestNum = 0;
        this.isNetworkIdle = false;
        this.networkIdleTimer = null;
        this.disableImg = opt.disableImg || false;
        this.disableMedia = opt.disableMedia || false;
        this.isMpcrawler = opt.isMpcrawler || false;
        this.timePerRequest = 0;
        this.isMainFrame = opt.isMainFrame || false;
        this.setMaxListeners(100);
    }
    isDetach() {
        return this.frame.isDetached();
    }
    setTaskExtra(extra) {
        this.extra = extra;
    }
    getPerformance(isReset = false) {
        const time = this.timePerRequest;
        if (isReset) {
            this.timePerRequest = 0;
        }
        return {
            averageTime: Math.round(time),
            timeout: this.requestNum,
        };
    }
    resetPerformance() {
        this.timePerRequest = 0;
    }
    async onRequestStart(request) {
        this.requestMap.set(request._requestId, Date.now());
        this.requestNum++;
        // Logger.debug(`frame[${this.frame.name()}] requestNum++ ${this.requestNum}`)
        this.isNetworkIdle = false;
        if (this.networkIdleTimer) {
            clearTimeout(this.networkIdleTimer);
        }
    }
    async onRequestEnd(request, endType) {
        // @ts-ignore
        const costTime = Date.now() - this.requestMap.get(request._requestId);
        const rUrl = request.url();
        if (rUrl.search('/wxacrawler/') !== -1) {
            // codesvr
            if (endType === 'failed' && request.resourceType() !== 'image') {
                log_1.default.error(`end ${endType} resType ${request.resourceType()} request:'${request.url()}' error: ${request._failureText} cost time : ${costTime}`);
            }
            endType === 'failed' ? reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.CODESVR_REQUEST_FAILED) : reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.CODESVR_REQUEST_SUCC);
        }
        else if (rUrl.search('wxacrawlerrequest/proxy') !== -1) {
            // requestproxy代理
            if (rUrl.search('servicewechat') !== -1) {
                if (endType === 'failed') {
                    log_1.default.error(`end ${endType} request:'${request.url()}' 
                    error: ${request._failureText} cost time : ${costTime}`);
                }
                endType === 'failed' ? reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.REQUEST_SW_FAILED) : reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.REQUEST_SW_SUCC);
            }
            endType === 'failed' ? reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.REQUEST_FAILED) : reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.REQUEST_SUCC);
            if (endType === 'failed') {
                const response = request.response();
                if (response) {
                    const headers = response ? response.headers() : {};
                    const newProxyIp = headers['x-requestproxy-ip'];
                    const oldProxyIp = headers['x-old-requestproxy-ip'];
                    log_1.default.error(`failed request!!! NewProxy:${newProxyIp}. OldProxy:${oldProxyIp}. url:${rUrl}. retcode:${response.status()}`);
                }
                else {
                    log_1.default.error(`failed request!!! ${rUrl}.`);
                }
            }
        }
        else {
            endType === 'failed' ? reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.SQUID_REQUEST_FAILED) : reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.SQUID_REQUEST_SUCC);
        }
        this.requestNum--;
        // Logger.debug(`frame[${this.frame.name()}] requestNum-- ${this.requestNum}`)
        if (this.requestNum <= 0) {
            if (this.networkIdleTimer) {
                clearTimeout(this.networkIdleTimer);
            }
            this.networkIdleTimer = setTimeout(() => {
                this.isNetworkIdle = true;
                // debug('network idle', this.frame.name());
                this.emit('networkIdle');
            }, 500);
            // 500ms 没有新请求就认为是networkIdle
        }
        // 更新frame的平均耗时
        if (this.timePerRequest === 0) {
            this.timePerRequest = costTime;
        }
        else {
            this.timePerRequest = (this.timePerRequest + costTime) / 2;
        }
        if (this.isMainFrame) {
            // wx.request
            const response = request.response();
            const headers = response ? response.headers() : {};
            const newProxyIp = headers['x-requestproxy-ip'];
            const oldProxyIp = headers['x-old-requestproxy-ip'];
            if (newProxyIp && !reportNewProxyIp) {
                // debug(`New Proxy Ip`, newProxyIp);
                reportNewProxyIp = true;
            }
            else if (oldProxyIp && !reportNewProxyIp) {
                // debug(`Old Proxy Ip`, oldProxyIp);
                reportNewProxyIp = true;
            }
        }
    }
    /**
     * 0: 正常
     * -1: 超时
     * -2: frame detached
     * @param {number} timeout
     * @returns {any}
     */
    waitForNetworkIdle(timeout = 5000) {
        if (this.isDetach())
            return Promise.resolve(-2);
        if (this.isNetworkIdle)
            return Promise.resolve(0);
        return new Promise((resolve, reject) => {
            const timeoutHandle = setTimeout(() => {
                log_1.default.error(`waitForNetworkIdle timeout:${timeout}`);
                reportIdKey_1.reportIdKey(reportIdKey_1.IdKey.NETWORK_IDLE_TIMEOUT);
                resolve(-1);
            }, timeout);
            this.once('networkIdle', () => {
                resolve(0);
                clearTimeout(timeoutHandle);
            });
            this.once('detach', (frameName) => {
                log_1.default.info(`waitForNetworkIdle fail: frame[${frameName}] detach`);
                resolve(-2);
                clearTimeout(timeoutHandle);
            });
        });
    }
}
exports.default = FrameData;


/***/ })
/******/ ]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL2F1dG8tcnVuL2xvZy50cyIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJldmVudHNcIiIsIndlYnBhY2s6Ly8vLi9zcmMvYXV0by1ydW4vdXRpbC9yZXBvcnRJZEtleS50cyIsIndlYnBhY2s6Ly8vLi9zcmMvYXV0by1ydW4vdXRpbC91dGlscy50cyIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJhd2FpdC10by1qc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcInBhdGhcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJmcy1leHRyYVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInVybFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInFzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicHVwcGV0ZWVyL0RldmljZURlc2NyaXB0b3JzXCIiLCJ3ZWJwYWNrOi8vLy4vc3JjL2F1dG8tcnVuL3V0aWwvY29uZmlnLnRzIiwid2VicGFjazovLy8uL3NyYy9hdXRvLXJ1bi9ydW50aW1lL2F1ZGl0c0F1dG9FbnRyeS50cyIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJwdXBwZXRlZXJcIiIsIndlYnBhY2s6Ly8vLi9zcmMvYXV0by1ydW4vcnVudGltZS9BdWRpdHNBdXRvLnRzIiwid2VicGFjazovLy8uL3NyYy9hdXRvLXJ1bi9ydW50aW1lL05ldHdvcmtMaXN0ZW5lci50cyIsIndlYnBhY2s6Ly8vLi9zcmMvanMvdXRpbHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2F1dG8tcnVuL3J1bnRpbWUvTWluYUhlYXJ0YmVhdC50cyIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJqaW1wXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibG9nNGpzXCIiLCJ3ZWJwYWNrOi8vLy4vc3JjL2F1dG8tcnVuL3J1bnRpbWUvYmFzZS9IaWphY2sudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2F1dG8tcnVuL3J1bnRpbWUvYmFzZS9QYWdlQmFzZS50cyIsIndlYnBhY2s6Ly8vLi9zcmMvYXV0by1ydW4vdXRpbC9kb21VdGlscy50cyIsIndlYnBhY2s6Ly8vLi9zcmMvYXV0by1ydW4vcnVudGltZS9iYXNlL0ZyYW1lRGF0YS50cyJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnRzIiwiJCIsInNlbGVjdG9yIiwiZWwiLCJkb2N1bWVudCIsInF1ZXJ5U2VsZWN0b3IiLCIkJCIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJzaG93Iiwic3R5bGUiLCJkaXNwbGF5IiwiaGlkZSIsInNwcmludGYiLCJzdHIiLCJhcmdzIiwiaSIsImxlbmd0aCIsInJlcGxhY2UiLCJyZXBvcnRCZWhhdmlvciIsImRhdGEiLCJsb2ciLCJwbHVnaW5NZXNzYWdlciIsImludm9rZSIsIkpTT04iLCJzdHJpbmdpZnkiLCJwcm9jZXNzIiwiZm9ybWF0U2l6ZSIsInNpemUiLCJ1bml0cyIsInVuaXQiLCJzaGlmdCIsInRvRml4ZWQiLCJoYXNoIiwidGV4dCIsImluZGV4IiwiY2hhckNvZGVBdCIsImJ5dGVDb3VudCIsInMiLCJlbmNvZGVVUkkiLCJzcGxpdCIsInVuaXF1ZSIsImFyciIsIm5ld0FyciIsImluZGV4T2YiLCJwdXNoIiwiZ2V0VHlwZSIsInZhbCIsIk9iamVjdCIsInByb3RvdHlwZSIsInRvU3RyaW5nIiwiY2FsbCIsInNsaWNlIiwidG9Mb3dlckNhc2UiLCJjb21wYXJlVmVyc2lvbiIsInYxIiwidjIiLCJsZW4iLCJNYXRoIiwibWF4IiwibnVtMSIsInBhcnNlSW50IiwibnVtMiIsImlzUmVxdWVzdE5vdEZvckF1ZGl0IiwidXJsIiwiaW52YWxpZERvbWFpblJlZyIsIm1hdGNoIiwiZmlsdGVyTGliU3RhY2siLCJzdGFja3MiLCJmaWx0ZXIiLCJzdGFjayIsInRlc3QiLCJmaWxlIiwicGFyc2VTdGFja1N0cmluZ3MiLCJzdGFja1N0ciIsImZpbHRlckxpYiIsIlJFR19FWFAiLCJyZXN1bHQiLCJtYXAiLCJmaWxlU3RyaW5nIiwibGluZSIsImNvbHVtbiIsImZ1bmMiLCJnZXRDYWxsU3RhY2siLCJFcnJvciIsIm9uR2VuZXJhdGVGdW5jUmVhZHkiLCJ3aW5kb3ciLCJfX2dlbmVyYXRlRnVuY19fIiwic2V0VGltZW91dCIsImFkZEV2ZW50TGlzdGVuZXIiLCJzdGF0dXMiLCJ0cmltIiwibm9kZUlEQ2xhc3NUZXh0Iiwibm9kZSIsImlkU3RyIiwiaWQiLCJjbGFzc05hbWUiLCJjbGFzc1N0ciIsInRhZ05hbWUiXSwibWFwcGluZ3MiOiI7QUFBQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGtEQUEwQyxnQ0FBZ0M7QUFDMUU7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxnRUFBd0Qsa0JBQWtCO0FBQzFFO0FBQ0EseURBQWlELGNBQWM7QUFDL0Q7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlEQUF5QyxpQ0FBaUM7QUFDMUUsd0hBQWdILG1CQUFtQixFQUFFO0FBQ3JJO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsbUNBQTJCLDBCQUEwQixFQUFFO0FBQ3ZELHlDQUFpQyxlQUFlO0FBQ2hEO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDhEQUFzRCwrREFBK0Q7O0FBRXJIO0FBQ0E7OztBQUdBO0FBQ0E7Ozs7Ozs7O0FDbEZhO0FBQ2IsOENBQThDLGNBQWM7QUFDNUQsZUFBZSxtQkFBTyxDQUFDLEVBQVE7QUFDL0I7QUFDQTtBQUNBLGVBQWUsWUFBb0I7QUFDbkMsa0VBQWtFLE1BQXNDLEdBQUcsU0FBTztBQUNsSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0Msb0JBQW9CO0FBQzFEO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQSxpQ0FBaUMsYUFBYSxHQUFHLE1BQU07QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNDQUFzQyxvQkFBb0I7QUFDMUQ7QUFDQSxpQkFBaUI7QUFDakIsYUFBYTtBQUNiO0FBQ0EsNkJBQTZCLGtEQUFrRDtBQUMvRSx3QkFBd0Isa0RBQWtEO0FBQzFFLDBCQUEwQiwwQ0FBMEM7QUFDcEU7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7QUM1RUEsbUM7Ozs7Ozs7QUNBYTtBQUNiLDhDQUE4QyxjQUFjO0FBQzVELGlCQUFpQixtQkFBTyxDQUFDLEVBQVU7QUFDbkMsY0FBYyxtQkFBTyxDQUFDLENBQVE7QUFDOUIsb0JBQW9CLEtBQXlDLEdBQUcsT0FBdUIsR0FBRyxTQUFPO0FBQ2pHLGVBQWUsWUFBb0I7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLG1CQUFPLENBQUMsRUFBVTtBQUNqQzs7Ozs7Ozs7QUMxQ2E7QUFDYiw4Q0FBOEMsY0FBYztBQUM1RCxlQUFlLG1CQUFPLENBQUMsRUFBTTtBQUM3QixzQkFBc0IsbUJBQU8sQ0FBQyxDQUFhO0FBQzNDLFdBQVcsY0FBYztBQUN6QixXQUFXLG1CQUFPLENBQUMsQ0FBSTtBQUN2QixnQkFBZ0IsbUJBQU8sQ0FBQyxDQUFLO0FBQzdCLFdBQVcsTUFBTTtBQUNqQixjQUFjLG1CQUFPLENBQUMsQ0FBUTtBQUM5QixXQUFXLFlBQVk7QUFDdkIsZ0JBQWdCLG1CQUFPLENBQUMsQ0FBNkI7QUFDckQ7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwREFBMEQsYUFBYTtBQUN2RSxnREFBZ0QsYUFBYTtBQUM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOERBQThELGFBQWE7QUFDM0UscURBQXFELGFBQWE7QUFDbEU7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlEQUFpRCxhQUFhO0FBQzlEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaURBQWlELGFBQWE7QUFDOUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBaUQsYUFBYTtBQUM5RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcseUVBQXlFO0FBQ3BGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxtQ0FBbUMsWUFBWTtBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLDJEQUEyRCxTQUFTLFdBQVcsTUFBTTtBQUNyRjtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBLGlFQUFpRSxTQUFTLElBQUksVUFBVTtBQUN4RjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLE9BQU8sSUFBSSxHQUFHO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLElBQUk7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTLElBQUk7QUFDYiwwQkFBMEIsS0FBSyxHQUFHLHVCQUF1QjtBQUN6RCxpREFBaUQsSUFBSSxNQUFNLE9BQU87QUFDbEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0MsT0FBTztBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0NBQXdDLEtBQUs7QUFDN0M7QUFDQSwrQ0FBK0MsS0FBSztBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQyxLQUFLLGdCQUFnQiw2QkFBNkI7QUFDbkY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDO0FBQ2xDLGdDQUFnQztBQUNoQyxrQ0FBa0M7QUFDbEM7QUFDQSxvQ0FBb0MsbUJBQW1CLFVBQVUsb0JBQW9CO0FBQ3JGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5REFBeUQsRUFBRSxLQUFLLEVBQUUsT0FBTyxJQUFJLE9BQU8sSUFBSTtBQUN4RjtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsZ0RBQWdELGdCQUFnQix3QkFBd0IsbUJBQW1CO0FBQzNHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIsSUFBSSxZQUFZLG9CQUFvQjtBQUNsRTtBQUNBO0FBQ0E7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBLHNEQUFzRCxJQUFJO0FBQzFEO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7Ozs7OztBQzdUQSx3Qzs7Ozs7O0FDQUEsaUM7Ozs7OztBQ0FBLHFDOzs7Ozs7QUNBQSxnQzs7Ozs7O0FDQUEsK0I7Ozs7OztBQ0FBLHdEOzs7Ozs7O0FDQWE7QUFDYiw4Q0FBOEMsY0FBYztBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQyw4Q0FBOEM7Ozs7Ozs7O0FDbENsQztBQUNiLDhDQUE4QyxjQUFjO0FBQzVELGFBQWEsbUJBQU8sQ0FBQyxDQUFNO0FBQzNCLFdBQVcsbUJBQU8sQ0FBQyxDQUFVO0FBQzdCLGtCQUFrQixtQkFBTyxDQUFDLEVBQVc7QUFDckMscUJBQXFCLG1CQUFPLENBQUMsRUFBYztBQUMzQyxjQUFjLG1CQUFPLENBQUMsQ0FBUTtBQUM5QixzQkFBc0IsbUJBQU8sQ0FBQyxDQUFxQjtBQUNuRCxlQUFlLFlBQW9CO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDREQUE0RCxNQUFNLEdBQUcsT0FBTztBQUM1RTtBQUNBLDhEQUE4RCxNQUFNLEdBQUcsT0FBTztBQUM5RTtBQUNBO0FBQ0EsdURBQXVELElBQUksS0FBSyxJQUFJO0FBQ3BFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaURBQWlELHNCQUFzQjtBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMENBQTBDLHdCQUF3QjtBQUNsRTtBQUNBO0FBQ0EscURBQXFELG9CQUFvQjtBQUN6RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsWUFBWTtBQUN2QjtBQUNBLGdEQUFnRCxzQkFBc0I7QUFDdEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsb0JBQW9CO0FBQzNDO0FBQ0Esd0JBQXdCLG9CQUFvQjtBQUM1Qyx3QkFBd0Isb0JBQW9CO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvREFBb0QsaUJBQWlCO0FBQ3JFO0FBQ0EsbURBQW1EO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbURBQW1ELGNBQWMsS0FBSyxZQUFZO0FBQ2xGO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRCxjQUFjLEtBQUssWUFBWTtBQUMvRTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSx3Q0FBd0MsZ0RBQWdEO0FBQ3hGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnREFBZ0QsVUFBVSxLQUFLLFFBQVE7QUFDdkU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDOzs7Ozs7O0FDbkpELHNDOzs7Ozs7O0FDQWE7QUFDYiw4Q0FBOEMsY0FBYztBQUM1RCxXQUFXLG1CQUFPLENBQUMsQ0FBVTtBQUM3QixhQUFhLG1CQUFPLENBQUMsQ0FBTTtBQUMzQixzQkFBc0IsbUJBQU8sQ0FBQyxDQUFhO0FBQzNDLDBCQUEwQixtQkFBTyxDQUFDLEVBQW1CO0FBQ3JELHdCQUF3QixtQkFBTyxDQUFDLEVBQWlCO0FBQ2pELGlCQUFpQixtQkFBTyxDQUFDLEVBQWU7QUFDeEMsbUJBQW1CLG1CQUFPLENBQUMsRUFBaUI7QUFDNUMsY0FBYyxtQkFBTyxDQUFDLENBQWU7QUFDckMsZ0JBQWdCLG1CQUFPLENBQUMsQ0FBNkI7QUFDckQsc0JBQXNCLG1CQUFPLENBQUMsQ0FBcUI7QUFDbkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDLDZCQUE2QjtBQUNsRSwyQkFBMkI7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUMsa0JBQWtCO0FBQ3pEO0FBQ0E7QUFDQTtBQUNBLHNGQUFzRixnQ0FBZ0M7QUFDdEg7QUFDQTtBQUNBLHVHQUF1RyxnQ0FBZ0M7QUFDdkk7QUFDQTtBQUNBLHdDQUF3QyxrQkFBa0IsSUFBSSxnQkFBZ0I7QUFDOUU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrREFBa0Qsc0JBQXNCO0FBQ3hFLGdEQUFnRCxrQkFBa0Isa0JBQWtCLGFBQWEsSUFBSSw4QkFBOEI7QUFDbkk7QUFDQSxrRUFBa0Usc0JBQXNCLGFBQWEsaUNBQWlDO0FBQ3RJO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0M7QUFDeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdURBQXVELCtCQUErQixJQUFJLDZCQUE2QjtBQUN2SDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBLDBHQUEwRyxpQkFBaUI7QUFDM0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdDQUF3QztBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QztBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDLGtCQUFrQjtBQUM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNENBQTRDLG9DQUFvQyxHQUFHLDJCQUEyQjtBQUM5RywwQ0FBMEMsZ0JBQWdCO0FBQzFEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQSwySEFBMkgsaUJBQWlCO0FBQzVJO0FBQ0E7QUFDQTtBQUNBLGdEQUFnRDtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0RBQWdEO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRDQUE0QztBQUM1QztBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSx1RkFBdUY7QUFDdkY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUVBQXVFLFVBQVUsVUFBVSxjQUFjO0FBQ3pHLDhDQUE4QyxTQUFTO0FBQ3ZELCtDQUErQyxpQkFBaUI7QUFDaEU7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0RBQXdELHVCQUF1QixJQUFJLHFCQUFxQjtBQUN4RztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkJBQTZCLFFBQVE7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsb0JBQW9CO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QyxrQkFBa0IsSUFBSSxnQkFBZ0I7QUFDL0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixTQUFTO0FBQ3hDLGdDQUFnQyxTQUFTO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULG1DQUFtQyxJQUFJO0FBQ3ZDO0FBQ0E7QUFDQSxlQUFlLHdCQUF3QjtBQUN2QztBQUNBLG9CQUFvQjtBQUNwQjtBQUNBO0FBQ0Esb0JBQW9CO0FBQ3BCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDLGFBQWE7QUFDeEQ7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxzQ0FBc0MsYUFBYTtBQUNuRDtBQUNBO0FBQ0EsK0JBQStCLGFBQWEseUJBQXlCLHlCQUF5QjtBQUM5RixnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQ0FBb0MsYUFBYTtBQUNqRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxhQUFhO0FBQ2pEO0FBQ0E7QUFDQSxvREFBb0QsU0FBUztBQUM3RCxtQkFBbUIsY0FBYztBQUNqQztBQUNBO0FBQ0E7QUFDQSw2Q0FBNkMsWUFBWTtBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0NBQStDLGdCQUFnQixJQUFJLFlBQVk7QUFDL0U7QUFDQTtBQUNBO0FBQ0EsNENBQTRDLGdCQUFnQixjQUFjLFlBQVk7QUFDdEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0EsNkNBQTZDLGdCQUFnQixJQUFJLFlBQVksVUFBVSwwQkFBMEIsSUFBSSxnQkFBZ0IsV0FBVyxTQUFTO0FBQ3pKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFFQUFxRSxnQkFBZ0I7QUFDckY7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUMsYUFBYTtBQUNwRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUMsYUFBYTtBQUNwRDtBQUNBLDJDQUEyQyxhQUFhLGdCQUFnQixnQkFBZ0IsZUFBZSxrQkFBa0I7QUFDekg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLGFBQWE7QUFDcEQ7QUFDQTtBQUNBO0FBQ0EsdUNBQXVDLGFBQWE7QUFDcEQ7QUFDQTtBQUNBO0FBQ0EsK0NBQStDLGFBQWE7QUFDNUQ7QUFDQSxtQ0FBbUMsYUFBYTtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtEQUFrRCxrQkFBa0I7QUFDcEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvREFBb0QsU0FBUztBQUM3RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsY0FBYztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsNkJBQTZCLEdBQUcsOEJBQThCLEdBQUcsZUFBZTtBQUM1RztBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDZFQUE2RSxTQUFTO0FBQ3RGLG9DQUFvQyxrREFBa0Q7QUFDdEY7QUFDQTtBQUNBO0FBQ0EsaUVBQWlFLFNBQVM7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDLFNBQVMsaUJBQWlCLGFBQWEsaUJBQWlCLGFBQWE7QUFDdkc7QUFDQSxtQ0FBbUMsMkNBQTJDO0FBQzlFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBLHlEQUF5RCxXQUFXO0FBQ3BFO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ25zQmE7QUFDYiw4Q0FBOEMsY0FBYztBQUM1RCxjQUFjLG1CQUFPLENBQUMsRUFBbUI7QUFDekMsY0FBYyxtQkFBTyxDQUFDLENBQUs7QUFDM0IsaUJBQWlCLG1CQUFPLENBQUMsQ0FBUTtBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyREFBMkQ7QUFDM0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQixhQUFhLEdBQUcsY0FBYztBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1EQUFtRCxJQUFJLHlCQUF5QixnQ0FBZ0M7QUFDaEg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7Ozs7Ozs7QUMzS0FBLE9BQU9DLE9BQVAsQ0FBZUMsQ0FBZixHQUFtQixVQUFVQyxRQUFWLEVBQW9CQyxFQUFwQixFQUF3QjtBQUN6QyxNQUFJLE9BQU9BLEVBQVAsS0FBYyxRQUFsQixFQUE0QjtBQUMxQkEsU0FBS0MsU0FBU0MsYUFBVCxDQUF1QkYsRUFBdkIsQ0FBTDtBQUNEOztBQUVELFNBQU8sQ0FBQ0EsTUFBTUMsUUFBUCxFQUFpQkMsYUFBakIsQ0FBK0JILFFBQS9CLENBQVA7QUFDRCxDQU5EOztBQVFBSCxPQUFPQyxPQUFQLENBQWVNLEVBQWYsR0FBb0IsVUFBVUosUUFBVixFQUFvQjtBQUN0QyxTQUFPRSxTQUFTRyxnQkFBVCxDQUEwQkwsUUFBMUIsQ0FBUDtBQUNELENBRkQ7O0FBSUFILE9BQU9DLE9BQVAsQ0FBZVEsSUFBZixHQUFzQixVQUFVTCxFQUFWLEVBQWM7QUFDbEMsTUFBSSxPQUFPQSxFQUFQLEtBQWMsUUFBbEIsRUFBNEI7QUFDMUJBLFNBQUtDLFNBQVNDLGFBQVQsQ0FBdUJGLEVBQXZCLENBQUw7QUFDRDs7QUFFREEsS0FBR00sS0FBSCxDQUFTQyxPQUFULEdBQW1CLEVBQW5CO0FBQ0QsQ0FORDs7QUFRQVgsT0FBT0MsT0FBUCxDQUFlVyxJQUFmLEdBQXNCLFVBQVVSLEVBQVYsRUFBYztBQUNsQyxNQUFJLE9BQU9BLEVBQVAsS0FBYyxRQUFsQixFQUE0QjtBQUMxQkEsU0FBS0MsU0FBU0MsYUFBVCxDQUF1QkYsRUFBdkIsQ0FBTDtBQUNEOztBQUVEQSxLQUFHTSxLQUFILENBQVNDLE9BQVQsR0FBbUIsTUFBbkI7QUFDRCxDQU5EOztBQVFBWCxPQUFPQyxPQUFQLENBQWVZLE9BQWYsR0FBeUIsVUFBVUMsR0FBVixFQUFlQyxJQUFmLEVBQXFCO0FBQzVDLE9BQUssSUFBSUMsSUFBSSxDQUFiLEVBQWdCQSxJQUFJRCxLQUFLRSxNQUF6QixFQUFpQ0QsR0FBakMsRUFBc0M7QUFDcENGLFVBQU1BLElBQUlJLE9BQUosQ0FBWSxJQUFaLEVBQWtCSCxLQUFLQyxDQUFMLENBQWxCLENBQU47QUFDRDtBQUNELFNBQU9GLEdBQVA7QUFDRCxDQUxEOztBQU9BZCxPQUFPQyxPQUFQLENBQWVrQixjQUFmLEdBQWdDLFVBQVVDLElBQVYsRUFBZ0I7QUFDOUM7QUFDQSxPQUFLQyxHQUFMLENBQVMsZ0JBQVQsRUFBMkJELElBQTNCO0FBQ0FFLGlCQUFlQyxNQUFmLENBQXNCLFFBQXRCLEVBQWdDQyxLQUFLQyxTQUFMLENBQWVMLElBQWYsQ0FBaEM7QUFDRCxDQUpEOztBQU1BcEIsT0FBT0MsT0FBUCxDQUFlb0IsR0FBZixHQUFxQixZQUFZO0FBQy9CLE1BQUlLLEtBQUosRUFBNEMsRUFNM0M7QUFDRixDQVJEOztBQVVBMUIsT0FBT0MsT0FBUCxDQUFlMEIsVUFBZixHQUE0QixVQUFVQyxJQUFWLEVBQWdCO0FBQzFDLFFBQU1DLFFBQVEsQ0FBQyxHQUFELEVBQU0sR0FBTixFQUFXLEdBQVgsRUFBZ0IsR0FBaEIsQ0FBZDtBQUNBLE1BQUlDLElBQUo7QUFDQSxTQUFPLENBQUNBLE9BQU9ELE1BQU1FLEtBQU4sRUFBUixLQUEwQkgsT0FBTyxJQUF4QyxFQUE4QztBQUM1Q0EsWUFBUSxJQUFSO0FBQ0Q7QUFDRCxTQUFPLENBQUNFLFNBQVMsR0FBVCxHQUFlRixJQUFmLEdBQXNCQSxLQUFLSSxPQUFMLENBQWEsQ0FBYixDQUF2QixJQUEwQ0YsSUFBakQ7QUFDRCxDQVBEOztBQVNBOUIsT0FBT0MsT0FBUCxDQUFlZ0MsSUFBZixHQUFzQixVQUFVQyxJQUFWLEVBQWdCO0FBQ3BDLE1BQUlELE9BQU8sSUFBWDtBQUNBLE1BQUlFLFFBQVFELEtBQUtqQixNQUFqQjs7QUFFQSxTQUFPa0IsS0FBUCxFQUFjO0FBQ1pGLFdBQVFBLE9BQU8sRUFBUixHQUFjQyxLQUFLRSxVQUFMLENBQWdCLEVBQUVELEtBQWxCLENBQXJCO0FBQ0Q7O0FBRUQsU0FBT0YsU0FBUyxDQUFoQjtBQUNELENBVEQ7O0FBV0E7QUFDQWpDLE9BQU9DLE9BQVAsQ0FBZW9DLFNBQWYsR0FBMkIsVUFBVUMsQ0FBVixFQUFhO0FBQ3RDLFNBQU9DLFVBQVVELENBQVYsRUFBYUUsS0FBYixDQUFtQixPQUFuQixFQUE0QnZCLE1BQTVCLEdBQXFDLENBQTVDO0FBQ0QsQ0FGRDs7QUFJQTtBQUNBakIsT0FBT0MsT0FBUCxDQUFld0MsTUFBZixHQUF3QixVQUFVQyxHQUFWLEVBQWU7QUFDckM7QUFDQSxRQUFNQyxTQUFTLEVBQWY7QUFDQSxPQUFLLElBQUkzQixJQUFJLENBQWIsRUFBZ0JBLElBQUkwQixJQUFJekIsTUFBeEIsRUFBZ0NELEdBQWhDLEVBQXFDO0FBQ25DLFFBQUkyQixPQUFPQyxPQUFQLENBQWVGLElBQUkxQixDQUFKLENBQWYsTUFBMkIsQ0FBQyxDQUFoQyxFQUFtQztBQUNqQzJCLGFBQU9FLElBQVAsQ0FBWUgsSUFBSTFCLENBQUosQ0FBWjtBQUNEO0FBQ0Y7QUFDRCxTQUFPMkIsTUFBUDtBQUNELENBVEQ7O0FBV0EzQyxPQUFPQyxPQUFQLENBQWU2QyxPQUFmLEdBQXlCLFVBQVVDLEdBQVYsRUFBZTtBQUN0QyxTQUFPQyxPQUFPQyxTQUFQLENBQWlCQyxRQUFqQixDQUEwQkMsSUFBMUIsQ0FBK0JKLEdBQS9CLEVBQW9DSyxLQUFwQyxDQUEwQyxDQUExQyxFQUE2QyxDQUFDLENBQTlDLEVBQWlEQyxXQUFqRCxFQUFQO0FBQ0QsQ0FGRDs7QUFJQXJELE9BQU9DLE9BQVAsQ0FBZXFELGNBQWYsR0FBZ0MsVUFBVUMsRUFBVixFQUFjQyxFQUFkLEVBQWtCO0FBQ2hERCxPQUFLQSxHQUFHZixLQUFILENBQVMsR0FBVCxDQUFMO0FBQ0FnQixPQUFLQSxHQUFHaEIsS0FBSCxDQUFTLEdBQVQsQ0FBTDtBQUNBLFFBQU1pQixNQUFNQyxLQUFLQyxHQUFMLENBQVNKLEdBQUd0QyxNQUFaLEVBQW9CdUMsR0FBR3ZDLE1BQXZCLENBQVo7O0FBRUEsU0FBT3NDLEdBQUd0QyxNQUFILEdBQVl3QyxHQUFuQixFQUF3QjtBQUN0QkYsT0FBR1YsSUFBSCxDQUFRLEdBQVI7QUFDRDtBQUNELFNBQU9XLEdBQUd2QyxNQUFILEdBQVl3QyxHQUFuQixFQUF3QjtBQUN0QkQsT0FBR1gsSUFBSCxDQUFRLEdBQVI7QUFDRDs7QUFFRCxPQUFLLElBQUk3QixJQUFJLENBQWIsRUFBZ0JBLElBQUl5QyxHQUFwQixFQUF5QnpDLEdBQXpCLEVBQThCO0FBQzVCLFVBQU00QyxPQUFPQyxTQUFTTixHQUFHdkMsQ0FBSCxDQUFULENBQWI7QUFDQSxVQUFNOEMsT0FBT0QsU0FBU0wsR0FBR3hDLENBQUgsQ0FBVCxDQUFiOztBQUVBLFFBQUk0QyxPQUFPRSxJQUFYLEVBQWlCO0FBQ2YsYUFBTyxDQUFQO0FBQ0QsS0FGRCxNQUVPLElBQUlGLE9BQU9FLElBQVgsRUFBaUI7QUFDdEIsYUFBTyxDQUFDLENBQVI7QUFDRDtBQUNGOztBQUVELFNBQU8sQ0FBUDtBQUNELENBeEJEOztBQTBCQTlELE9BQU9DLE9BQVAsQ0FBZThELG9CQUFmLEdBQXNDLFVBQVVDLEdBQVYsRUFBZTtBQUNuRCxRQUFNQyxtQkFBbUIsQ0FDdkIsU0FEdUI7QUFFdkI7QUFDQSw2REFIdUIsRUFJdkIsc0NBSnVCO0FBS3ZCO0FBQ0EsNENBTnVCLEVBT3ZCLCtCQVB1QjtBQVF2QjtBQUNBLGtDQVR1QjtBQVV2QjtBQUNBLGdDQVh1QixFQVl2QixpQ0FadUIsRUFhdkIsaUNBYnVCO0FBY3ZCO0FBQ0Esd0JBZnVCO0FBZ0J2QjtBQUNBLDBCQWpCdUI7QUFrQnZCO0FBQ0Esb0NBbkJ1QixFQW9CdkIsb0JBcEJ1QixFQXFCdkIsZ0JBckJ1QixFQXVCdkIsd0NBdkJ1QixDQUF6Qjs7QUE2QkEsT0FBSyxJQUFJakQsSUFBSSxDQUFiLEVBQWdCQSxJQUFJaUQsaUJBQWlCaEQsTUFBckMsRUFBNkNELEdBQTdDLEVBQWtEO0FBQ2hELFFBQUlnRCxJQUFJRSxLQUFKLENBQVVELGlCQUFpQmpELENBQWpCLENBQVYsQ0FBSixFQUFvQztBQUNsQyxhQUFPLElBQVA7QUFDRDtBQUNGOztBQUVELFNBQU8sS0FBUDtBQUNELENBckNEOztBQXVDQSxNQUFNbUQsaUJBQWlCLFVBQVVDLE1BQVYsRUFBa0I7QUFDdkMsU0FBT0EsT0FBT0MsTUFBUCxDQUFlQyxLQUFELElBQVc7QUFDOUIsV0FBTyxDQUFDLHdIQUF3SEMsSUFBeEgsQ0FBNkhELE1BQU1FLElBQW5JLENBQVI7QUFDRCxHQUZNLENBQVA7QUFHRCxDQUpEOztBQU1BeEUsT0FBT0MsT0FBUCxDQUFld0UsaUJBQWYsR0FBbUMsVUFBVUMsUUFBVixFQUFvQkMsWUFBWSxJQUFoQyxFQUFzQztBQUN2RSxNQUFJUCxTQUFTTSxTQUFTbEMsS0FBVCxDQUFlLElBQWYsQ0FBYjtBQUNBLE1BQUlvQyxVQUFVLDBCQUFkO0FBQ0EsTUFBSUMsU0FBU1QsT0FBT1UsR0FBUCxDQUFZUixLQUFELElBQVc7QUFDakMsUUFBSU8sU0FBU1AsTUFBTUosS0FBTixDQUFZVSxPQUFaLENBQWI7QUFDQSxRQUFJQyxVQUFVQSxPQUFPLENBQVAsQ0FBVixJQUF1QkEsT0FBTyxDQUFQLENBQTNCLEVBQXNDO0FBQ3BDLFVBQUlFLGFBQWFGLE9BQU8sQ0FBUCxFQUFVM0QsT0FBVixDQUFrQixNQUFsQixFQUEwQixFQUExQixFQUE4QkEsT0FBOUIsQ0FBc0MsaUZBQXRDLEVBQXlILEVBQXpILENBQWpCO0FBQ0EsVUFBSSxDQUFDc0QsSUFBRCxFQUFPUSxJQUFQLEVBQWFDLE1BQWIsSUFBdUJGLFdBQVd2QyxLQUFYLENBQWlCLEdBQWpCLENBQTNCO0FBQ0EsVUFBSXVDLFdBQVd2QyxLQUFYLENBQWlCLEdBQWpCLEVBQXNCdkIsTUFBdEIsSUFBZ0MsQ0FBcEMsRUFBdUM7QUFDckMsZUFBTztBQUNMaUUsZ0JBQU1MLE9BQU8sQ0FBUCxFQUFVM0QsT0FBVixDQUFrQixzQ0FBbEIsRUFBMEQsSUFBMUQsQ0FERDtBQUVMc0QsY0FGSztBQUdMUSxnQkFBTSxDQUFDQSxJQUhGO0FBSUxDLGtCQUFRLENBQUNBO0FBSkosU0FBUDtBQU1EO0FBQ0Y7QUFDRCxXQUFPLElBQVA7QUFDRCxHQWZZLEVBZVZaLE1BZlUsQ0FlSEMsU0FBUyxDQUFDLENBQUNBLEtBZlIsQ0FBYjs7QUFpQkEsTUFBSUssU0FBSixFQUFlO0FBQ2JFLGFBQVNWLGVBQWVVLE1BQWYsQ0FBVDtBQUNEOztBQUVELFNBQU9BLE1BQVA7QUFDRCxDQXpCRDs7QUEyQkE3RSxPQUFPQyxPQUFQLENBQWVrRixZQUFmLEdBQThCLFVBQVVSLFlBQVksSUFBdEIsRUFBNEI7QUFDeEQsTUFBSUUsU0FBUzVFLFFBQVF3RSxpQkFBUixDQUEwQixJQUFJVyxLQUFKLEdBQVlkLEtBQXRDLENBQWI7O0FBRUEsTUFBSUssU0FBSixFQUFlO0FBQ2JFLGFBQVNWLGVBQWVVLE1BQWYsQ0FBVDtBQUNEOztBQUVELFNBQU9BLE1BQVA7QUFDRCxDQVJEOztBQVVBN0UsT0FBT0MsT0FBUCxDQUFlb0YsbUJBQWYsR0FBcUMsVUFBVUgsSUFBVixFQUFnQjtBQUNuRCxNQUFJSSxPQUFPQyxnQkFBWCxFQUE2QjtBQUMzQkMsZUFBV04sSUFBWDtBQUNELEdBRkQsTUFFTztBQUNMN0UsYUFBU29GLGdCQUFULENBQTBCLG1CQUExQixFQUErQ1AsSUFBL0M7QUFDRDtBQUNGLENBTkQ7O0FBUUFsRixPQUFPQyxPQUFQLENBQWV5RixNQUFmLEdBQXdCLFNBQXhCOztBQUVBMUYsT0FBT0MsT0FBUCxDQUFlMEYsSUFBZixHQUFzQixVQUFVN0UsR0FBVixFQUFlO0FBQ25DLFNBQU9BLElBQUlJLE9BQUosQ0FBWSxZQUFaLEVBQTBCLEVBQTFCLENBQVA7QUFDRCxDQUZEOztBQUlBbEIsT0FBT0MsT0FBUCxDQUFlMkYsZUFBZixHQUFpQyxVQUFVQyxJQUFWLEVBQWdCO0FBQy9DLFFBQU1DLFFBQVFELEtBQUtFLEVBQUwsR0FBVyxJQUFHRixLQUFLRSxFQUFHLEVBQXRCLEdBQTBCLEVBQXhDO0FBQ0EsUUFBTUMsWUFBWWhHLE9BQU9DLE9BQVAsQ0FBZTBGLElBQWYsQ0FBb0JFLEtBQUtHLFNBQXpCLENBQWxCO0FBQ0EsUUFBTUMsV0FBV0QsWUFBWSxNQUFNQSxVQUFVOUUsT0FBVixDQUFrQixLQUFsQixFQUF5QixHQUF6QixDQUFsQixHQUFrRCxFQUFuRTs7QUFFQSxTQUFPMkUsS0FBS0ssT0FBTCxDQUFhN0MsV0FBYixHQUEyQm5DLE9BQTNCLENBQW1DLE1BQW5DLEVBQTJDLEVBQTNDLElBQWlENEUsS0FBakQsR0FBeURHLFFBQWhFO0FBQ0QsQ0FORCxDOzs7Ozs7O0FDdE5hO0FBQ2IsOENBQThDLGNBQWM7QUFDNUQsaUJBQWlCLG1CQUFPLENBQUMsQ0FBUTtBQUNqQyxjQUFjLG1CQUFPLENBQUMsQ0FBZTtBQUNyQyxjQUFjLG1CQUFPLENBQUMsQ0FBUTtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTs7Ozs7OztBQzdCQSxpQzs7Ozs7O0FDQUEsbUM7Ozs7Ozs7QUNBYTtBQUNiLDhDQUE4QyxjQUFjO0FBQzVELGlCQUFpQixtQkFBTyxDQUFDLENBQVE7QUFDakMsV0FBVyxtQkFBTyxDQUFDLENBQUk7QUFDdkIsY0FBYyxtQkFBTyxDQUFDLENBQVc7QUFDakMsZ0JBQWdCLG1CQUFPLENBQUMsQ0FBa0I7QUFDMUMsc0JBQXNCLG1CQUFPLENBQUMsQ0FBd0I7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvREFBb0QsV0FBVztBQUMvRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlEQUFpRCxZQUFZO0FBQzdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHdEQUF3RCxLQUFLLGFBQWEsaUJBQWlCO0FBQzNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxtQkFBbUIsc0JBQXNCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBLHVCQUF1QjtBQUN2QjtBQUNBLHdCQUF3QjtBQUN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzR0FBc0c7QUFDdEc7QUFDQSxtRUFBbUUsU0FBUztBQUM1RTtBQUNBO0FBQ0EsOENBQThDO0FBQzlDLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkRBQTJELGNBQWMsYUFBYSxVQUFVO0FBQ2hHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MsaUNBQWlDO0FBQ25FO0FBQ0Esc0NBQXNDLElBQUksR0FBRyxnQ0FBZ0M7QUFDN0UseUJBQXlCO0FBQ3pCLHNFQUFzRSxNQUFNO0FBQzVFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNkNBQTZDLElBQUk7QUFDakQ7QUFDQTtBQUNBO0FBQ0EsNkNBQTZDLElBQUk7QUFDakQ7QUFDQTtBQUNBO0FBQ0EsNENBQTRDLElBQUk7QUFDaEQ7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDLElBQUk7QUFDL0M7QUFDQTtBQUNBO0FBQ0EsK0NBQStDLElBQUk7QUFDbkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUMsSUFBSTtBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVDQUF1QyxnQkFBZ0I7QUFDdkQ7QUFDQSx5QkFBeUIsa0JBQWtCO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2IsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLGVBQWUsTUFBTTtBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7Ozs7Ozs7O0FDMU1hO0FBQ2IsOENBQThDLGNBQWM7QUFDNUQsaUJBQWlCLG1CQUFPLENBQUMsQ0FBUTtBQUNqQyxjQUFjLG1CQUFPLENBQUMsQ0FBVztBQUNqQyxtQkFBbUIsbUJBQU8sQ0FBQyxFQUFxQjtBQUNoRCxvQkFBb0IsbUJBQU8sQ0FBQyxFQUFhO0FBQ3pDLHNCQUFzQixtQkFBTyxDQUFDLENBQXdCO0FBQ3REO0FBQ0EsOEJBQThCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlFQUFpRSxtREFBbUQ7QUFDcEg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDLHVCQUF1QixJQUFJLGNBQWM7QUFDcEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnRUFBZ0Usa0JBQWtCO0FBQ2xGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSxvREFBb0QsY0FBYyxHQUFHLFlBQVk7QUFDakY7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxlQUFlLFlBQVk7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQjtBQUNwQjtBQUNBLDRDQUE0QyxhQUFhO0FBQ3pEO0FBQ0EsNkNBQTZDLFVBQVU7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvQkFBb0I7QUFDcEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMERBQTBELGFBQWE7QUFDdkUsNERBQTREO0FBQzVELHVCQUF1QjtBQUN2QjtBQUNBO0FBQ0EseUNBQXlDLGFBQWE7QUFDdEQ7QUFDQTtBQUNBLDZDQUE2QyxhQUFhO0FBQzFELGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDLFVBQVU7QUFDbkQsK0ZBQStGLFVBQVU7QUFDekc7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7OztBQ3ZKYTtBQUNiLDhDQUE4QyxjQUFjO0FBQzVELHNCQUFzQixtQkFBTyxDQUFDLENBQWE7QUFDM0MsV0FBVyxNQUFNO0FBQ2pCLGNBQWMsbUJBQU8sQ0FBQyxDQUFRO0FBQzlCLGdCQUFnQixtQkFBTyxDQUFDLENBQVM7QUFDakM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxXQUFXLFFBQVE7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3Q0FBd0MsVUFBVTtBQUNsRCw0Q0FBNEMsVUFBVTtBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtRkFBbUYsZ0JBQWdCO0FBQ25HLHdDQUF3QyxVQUFVO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5REFBeUQ7QUFDekQsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRDQUE0QyxVQUFVLEdBQUcsUUFBUTtBQUNqRTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNENBQTRDLFVBQVUsR0FBRyxRQUFRO0FBQ2pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOENBQThDLFNBQVM7QUFDdkQ7QUFDQSxxREFBcUQsU0FBUztBQUM5RDtBQUNBLHNEQUFzRCxTQUFTO0FBQy9EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9HQUFvRyxJQUFJO0FBQ3hHLGtCQUFrQix3QkFBd0I7QUFDMUMsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixVQUFVLEdBQUcsU0FBUyxHQUFHLFdBQVcsR0FBRyxZQUFZLEdBQUcsa0JBQWtCLEdBQUcscUJBQXFCLEdBQUcseUJBQXlCLEdBQUcscUJBQXFCLEdBQUcsZUFBZSxHQUFHLGlCQUFpQixHQUFHLGdCQUFnQjtBQUMvTixLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLGdCQUFnQjtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQyxhQUFhLEdBQUcsWUFBWSxHQUFHLGNBQWM7QUFDOUUsNkJBQTZCLGVBQWUsR0FBRyxrQkFBa0IsR0FBRyxxQkFBcUI7QUFDekYsNkJBQTZCLHlCQUF5QixHQUFHLHFCQUFxQixHQUFHLGVBQWU7QUFDaEcsNkJBQTZCLGlCQUFpQixHQUFHLGdCQUFnQjtBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlEQUFpRCxVQUFVLEdBQUcsUUFBUTtBQUN0RTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxvREFBb0QsSUFBSTtBQUN4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckIsaUJBQWlCO0FBQ2pCO0FBQ0EsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0Esa0VBQWtFLFVBQVUsR0FBRyxRQUFRO0FBQ3ZGO0FBQ0EsdUNBQXVDLDBCQUEwQjtBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5Q0FBeUMsbUJBQW1CO0FBQzVEO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0EscUJBQXFCO0FBQ3JCLGlCQUFpQjtBQUNqQixhQUFhO0FBQ2IsOENBQThDLHlCQUF5QjtBQUN2RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7Ozs7Ozs7O0FDeFNhO0FBQ2IsOENBQThDLGNBQWM7QUFDNUQsaUJBQWlCLG1CQUFPLENBQUMsQ0FBUTtBQUNqQyxjQUFjLG1CQUFPLENBQUMsQ0FBVztBQUNqQyxzQkFBc0IsbUJBQU8sQ0FBQyxDQUF3QjtBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUMsa0JBQWtCLGlCQUFpQixnQkFBZ0I7QUFDcEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDLFFBQVEsV0FBVyx1QkFBdUIsWUFBWSxjQUFjLFdBQVcscUJBQXFCLGVBQWUsU0FBUztBQUN2SztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQyxRQUFRLFlBQVksY0FBYztBQUNqRiw2QkFBNkIscUJBQXFCLGVBQWUsU0FBUztBQUMxRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHNFQUFzRSxXQUFXLGFBQWEsV0FBVyxRQUFRLEtBQUssWUFBWSxrQkFBa0I7QUFDcEo7QUFDQTtBQUNBLDZEQUE2RCxLQUFLO0FBQ2xFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUNBQWlDLGtCQUFrQixpQkFBaUIsZ0JBQWdCO0FBQ3BGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsT0FBTztBQUN0QixpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtFQUFrRSxRQUFRO0FBQzFFO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0EscUVBQXFFLFVBQVU7QUFDL0U7QUFDQTtBQUNBLGFBQWE7QUFDYixTQUFTO0FBQ1Q7QUFDQTtBQUNBIiwiZmlsZSI6ImF1dG8tcnVuL2F1ZGl0c0F1dG9FbnRyeS5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0ge307XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSAxMSk7XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmNvbnN0IGxvZzRqcyA9IHJlcXVpcmUoXCJsb2c0anNcIik7XG4vLyBAdG9kbyDov5DokKXop4TojIPml6Xlv5fmoLzlvI/kuLogL2hvbWUvcXNwYWNlL2xvZy/lupTnlKjlkI0vZXJyb3IveXl5eU1NZGRoaC5sb2dcbi8vIGxvZzRqc+S4jeaUr+aMgeWPquaciXBhdHRlcm7nmoTmlofku7blkI3vvIzov5nph4zmipXmnLrlj5blt6fkuIDmiorvvIzmlofku7blkI3kuLoyMCwg5ZCO5Yqg5bm05Lu95ZCO5Lik5L2N77yM5ZyoMjEwMOWJjeayoeaciemXrumimOOAgkBxeWJkc2hlblxuY29uc3QgaXNQcm9kID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT0gJ3Byb2R1Y3Rpb24nO1xuY29uc3QgbG9nTGV2ZWwgPSBwcm9jZXNzLmVudi5MT0dfTEVWRUwgPyBwcm9jZXNzLmVudi5MT0dfTEVWRUwgOiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcgPyAnZGVidWcnIDogJ2luZm8nKTtcbmNsYXNzIExvZ2dlckNsYXNzIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5sb2dQYXRoID0gcHJvY2Vzcy5jd2QoKSArICcvbG9ncy8nO1xuICAgICAgICBpZiAoaXNQcm9kKSB7XG4gICAgICAgICAgICB0aGlzLmxvZ2dlciA9IGxvZzRqcy5nZXRMb2dnZXIoJ3Byb2R1Y3Rpb24nKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubG9nZ2VyID0gbG9nNGpzLmdldExvZ2dlcignZGVidWcnKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpbml0TG9nZ2VyKGxvZ1BhdGgsIGFwcGlkKSB7XG4gICAgICAgIHRoaXMubG9nUGF0aCA9IGxvZ1BhdGg7XG4gICAgICAgIGxvZzRqcy5jb25maWd1cmUoe1xuICAgICAgICAgICAgYXBwZW5kZXJzOiB7XG4gICAgICAgICAgICAgICAgY29uc29sZToge1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiAnY29uc29sZScsXG4gICAgICAgICAgICAgICAgICAgIGxheW91dDoge1xuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3BhdHRlcm4nLFxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0dGVybjogYFslZHt5eXl5LU1NLWRkIGhoOm1tOnNzfV0gJVtbJWNdIFslcF0gJW0lXWAsXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGZpbGU6IHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogJ2ZpbGUnLFxuICAgICAgICAgICAgICAgICAgICBmaWxlbmFtZTogYCR7dGhpcy5sb2dQYXRofS8ke2FwcGlkfS5sb2dgLFxuICAgICAgICAgICAgICAgICAgICBtYXhMb2dTaXplOiA1MjQyODgwMDAsXG4gICAgICAgICAgICAgICAgICAgIGFsd2F5c0luY2x1ZGVQYXR0ZXJuOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBiYWNrdXBzOiAyMCxcbiAgICAgICAgICAgICAgICAgICAgbGF5b3V0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAncGF0dGVybicsXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXR0ZXJuOiBgWyVke3l5eXktTU0tZGQgaGg6bW06c3N9XSBbJWNdIFslcF0gJW0lYCxcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY2F0ZWdvcmllczoge1xuICAgICAgICAgICAgICAgIHByb2R1Y3Rpb246IHsgYXBwZW5kZXJzOiBbJ2NvbnNvbGUnLCAnZmlsZSddLCBsZXZlbDogbG9nTGV2ZWwgfSxcbiAgICAgICAgICAgICAgICBkZWJ1ZzogeyBhcHBlbmRlcnM6IFsnY29uc29sZScsICdmaWxlJ10sIGxldmVsOiBsb2dMZXZlbCB9LFxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6IHsgYXBwZW5kZXJzOiBbJ2NvbnNvbGUnXSwgbGV2ZWw6IGxvZ0xldmVsIH0sXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoaXNQcm9kKSB7XG4gICAgICAgICAgICB0aGlzLmxvZ2dlciA9IGxvZzRqcy5nZXRMb2dnZXIoJ3Byb2R1Y3Rpb24nKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubG9nZ2VyID0gbG9nNGpzLmdldExvZ2dlcignZGVidWcnKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICB0cmFjZShmaXJzdEFyZywgLi4uYXJncykge1xuICAgICAgICB0aGlzLmxvZ2dlci50cmFjZShmaXJzdEFyZywgLi4uYXJncyk7XG4gICAgfVxuICAgIGRlYnVnKGZpcnN0QXJnLCAuLi5hcmdzKSB7XG4gICAgICAgIHRoaXMubG9nZ2VyLmRlYnVnKGZpcnN0QXJnLCAuLi5hcmdzKTtcbiAgICB9XG4gICAgaW5mbyhmaXJzdEFyZywgLi4uYXJncykge1xuICAgICAgICB0aGlzLmxvZ2dlci5pbmZvKGZpcnN0QXJnLCAuLi5hcmdzKTtcbiAgICB9XG4gICAgd2FybihmaXJzdEFyZywgLi4uYXJncykge1xuICAgICAgICB0aGlzLmxvZ2dlci53YXJuKGZpcnN0QXJnLCAuLi5hcmdzKTtcbiAgICB9XG4gICAgZXJyb3IoZmlyc3RBcmcsIC4uLmFyZ3MpIHtcbiAgICAgICAgdGhpcy5sb2dnZXIuZXJyb3IoZmlyc3RBcmcsIC4uLmFyZ3MpO1xuICAgIH1cbiAgICBmYXRhbChmaXJzdEFyZywgLi4uYXJncykge1xuICAgICAgICB0aGlzLmxvZ2dlci5mYXRhbChmaXJzdEFyZywgLi4uYXJncyk7XG4gICAgfVxuICAgIGxvZyhmaXJzdEFyZywgLi4uYXJncykge1xuICAgICAgICB0aGlzLmxvZ2dlci5sb2coZmlyc3RBcmcsIC4uLmFyZ3MpO1xuICAgIH1cbn1cbmNvbnN0IExvZ2dlciA9IG5ldyBMb2dnZXJDbGFzcygpO1xuZXhwb3J0cy5kZWZhdWx0ID0gTG9nZ2VyO1xuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZXZlbnRzXCIpOyIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuY29uc3QgY29uZmlnXzEgPSByZXF1aXJlKFwiLi9jb25maWdcIik7XG5jb25zdCBsb2dfMSA9IHJlcXVpcmUoXCIuLi9sb2dcIik7XG5jb25zdCByZXF1aXJlRnVuYyA9IHR5cGVvZiBfX3dlYnBhY2tfcmVxdWlyZV9fID09PSBcImZ1bmN0aW9uXCIgPyBfX25vbl93ZWJwYWNrX3JlcXVpcmVfXyA6IHJlcXVpcmU7XG5jb25zdCBpc1Byb2QgPSBwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nO1xubGV0IGxpYjtcbmlmIChpc1Byb2QpIHtcbiAgICBjb25zdCBmZmkgPSByZXF1aXJlRnVuYygnZmZpJyk7XG4gICAgbGliID0gZmZpLkxpYnJhcnkoY29uZmlnXzEuSURLX0xJQiwge1xuICAgICAgICAnT3NzQXR0ckluYyc6IFsnaW50JywgWydpbnQnLCAnaW50JywgJ2ludCddXSxcbiAgICB9KTtcbn1cbmZ1bmN0aW9uIHJlcG9ydChpZCwga2V5LCB2YWwpIHtcbiAgICBpZiAoaXNQcm9kKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBsaWIuT3NzQXR0ckluYyhpZCwga2V5LCB2YWwpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgIGxvZ18xLmRlZmF1bHQuZXJyb3IoJ3JlcG9ydElkS2V5IGZhaWwnLCBlcnIpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBsb2dfMS5kZWZhdWx0LmRlYnVnKCdyZXBvcnRJZEtleSByZXBvcnQnLCBpZCwga2V5LCB2YWwpO1xuICAgIH1cbn1cbi8qKlxuICog5LiK5oql55uR5o6n5pWw5o2uXG4gKiBAcGFyYW0ga2V5XG4gKiBAcGFyYW0ge251bWJlcn0gdmFsXG4gKi9cbmZ1bmN0aW9uIHJlcG9ydElkS2V5KGtleSwgdmFsID0gMSkge1xuICAgIGNvbnN0IHRlbXAgPSAoa2V5ICsgJycpLnNwbGl0KCdfJyk7XG4gICAgaWYgKHRlbXAubGVuZ3RoID09PSAyKSB7XG4gICAgICAgIHJlcG9ydChwYXJzZUludCh0ZW1wWzBdLCAxMCksIHBhcnNlSW50KHRlbXBbMV0sIDEwKSwgdmFsKTtcbiAgICB9XG4gICAgZWxzZSBpZiAoY29uZmlnXzEuTWFpbklkS2V5ICYmIHRlbXAubGVuZ3RoID09PSAxKSB7XG4gICAgICAgIHJlcG9ydChjb25maWdfMS5NYWluSWRLZXksIGtleSwgdmFsKTtcbiAgICB9XG59XG5leHBvcnRzLnJlcG9ydElkS2V5ID0gcmVwb3J0SWRLZXk7XG52YXIgY29uZmlnXzIgPSByZXF1aXJlKFwiLi9jb25maWdcIik7XG5leHBvcnRzLklkS2V5ID0gY29uZmlnXzIuSWRLZXk7XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmNvbnN0IGppbXBfMSA9IHJlcXVpcmUoXCJqaW1wXCIpO1xuY29uc3QgYXdhaXRfdG9fanNfMSA9IHJlcXVpcmUoXCJhd2FpdC10by1qc1wiKTtcbi8vIGltcG9ydCB7RWxlbWVudEhhbmRsZX0gZnJvbSBcInB1cHBldGVlclwiO1xuY29uc3QgcXMgPSByZXF1aXJlKFwicXNcIik7XG5jb25zdCB1cmxVdGlsID0gcmVxdWlyZShcInVybFwiKTtcbi8vIGltcG9ydCB7SWRLZXl9IGZyb20gXCIuLi9jb25maWdcIjtcbmNvbnN0IGxvZ18xID0gcmVxdWlyZShcIi4uL2xvZ1wiKTtcbi8vIGltcG9ydCB7cmVwb3J0SWRLZXl9IGZyb20gXCIuLi9yZXBvcnRJZEtleVwiO1xuY29uc3QgZGV2aWNlcyA9IHJlcXVpcmUoJ3B1cHBldGVlci9EZXZpY2VEZXNjcmlwdG9ycycpO1xuZnVuY3Rpb24gc2xlZXAodGltZSkge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICBzZXRUaW1lb3V0KHJlc29sdmUsIHRpbWUpO1xuICAgIH0pO1xufVxuZXhwb3J0cy5zbGVlcCA9IHNsZWVwO1xuZnVuY3Rpb24gZnJhbWVFdmFsdWF0ZShmcmFtZSwgZnVuYywgLi4uYXJncykge1xuICAgIGlmICghZnJhbWUuaXNEZXRhY2hlZCgpKSB7XG4gICAgICAgIHJldHVybiBmcmFtZS5ldmFsdWF0ZShmdW5jLCAuLi5hcmdzKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIHJlcG9ydElkS2V5KElkS2V5LkZSQU1FX0RFVEFDSEVEKTtcbiAgICAgICAgbG9nXzEuZGVmYXVsdC5lcnJvcihgZnJhbWVFdmFsdWF0ZSBmYWlsZWQgZnJhbWVbJHtmcmFtZS5uYW1lKCl9XSBkZXRhY2hlZCFgKTtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBmcmFtZSBkZXRhY2hlZCEgbmFtZToke2ZyYW1lLm5hbWUoKX1gKTtcbiAgICB9XG59XG5leHBvcnRzLmZyYW1lRXZhbHVhdGUgPSBmcmFtZUV2YWx1YXRlO1xuZnVuY3Rpb24gdGltZW91dEV2YWx1YXRlRnJhbWUoZnJhbWUsIHRpbWVvdXQgPSAzMDAwLCBmdW5jLCAuLi5hcmdzKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKGFzeW5jIChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgaWYgKCFmcmFtZS5pc0RldGFjaGVkKCkpIHtcbiAgICAgICAgICAgIGxldCBpc0ZpbmlzaGVkID0gZmFsc2U7XG4gICAgICAgICAgICBsb2dfMS5kZWZhdWx0LmluZm8oJ3RpbWVvdXRFdmFsdWF0ZUZyYW1lZWVlZWVlZWVlZWVlZWVlZWVlJyk7XG4gICAgICAgICAgICBjb25zdCB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGlzRmluaXNoZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGxvZ18xLmRlZmF1bHQuZXJyb3IoJ3RpbWVvdXRFdmFsdWF0ZUZyYW1lIHRpbWVvdXQhISEnKTtcbiAgICAgICAgICAgICAgICByZWplY3QobmV3IEVycm9yKCdmcmFtZSBldmFsdWF0ZSB0aW1lb3V0IGVycm9yJykpO1xuICAgICAgICAgICAgfSwgdGltZW91dCk7XG4gICAgICAgICAgICBjb25zdCBbZXZhbEVycm9yLCBldmFsUmVzdWx0XSA9IGF3YWl0IGF3YWl0X3RvX2pzXzEuZGVmYXVsdChmcmFtZS5ldmFsdWF0ZShmdW5jLCAuLi5hcmdzKSk7XG4gICAgICAgICAgICBpZiAoIWlzRmluaXNoZWQpIHtcbiAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgICAgICAgICAgICAgIGlzRmluaXNoZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGV2YWxFcnJvciA/IHJlamVjdChldmFsRXJyb3IpIDogcmVzb2x2ZShldmFsUmVzdWx0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIC8vIHJlcG9ydElkS2V5KElkS2V5LkZSQU1FX0RFVEFDSEVEKTtcbiAgICAgICAgICAgIGxvZ18xLmRlZmF1bHQuZXJyb3IoYGZyYW1lRXZhbHVhdGUgZmFpbGVkIGZyYW1lWyR7ZnJhbWUubmFtZSgpfV0gZGV0YWNoZWQhYCk7XG4gICAgICAgICAgICByZWplY3QobmV3IEVycm9yKGBmcmFtZSBkZXRhY2hlZCEgbmFtZToke2ZyYW1lLm5hbWUoKX1gKSk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cbmV4cG9ydHMudGltZW91dEV2YWx1YXRlRnJhbWUgPSB0aW1lb3V0RXZhbHVhdGVGcmFtZTtcbmZ1bmN0aW9uIHRpbWVvdXRFdmFsdWF0ZVBhZ2UocGFnZSwgdGltZW91dCA9IDUwMDAsIGZ1bmMsIC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoYXN5bmMgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBpZiAoIXBhZ2UuaXNDbG9zZWQoKSkge1xuICAgICAgICAgICAgbGV0IGlzRmluaXNoZWQgPSBmYWxzZTtcbiAgICAgICAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgaXNGaW5pc2hlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcigncGFnZSBldmFsdWF0ZSB0aW1lb3V0IGVycm9yJykpO1xuICAgICAgICAgICAgfSwgdGltZW91dCk7XG4gICAgICAgICAgICBjb25zdCBbZXZhbEVycm9yLCBldmFsUmVzdWx0XSA9IGF3YWl0IGF3YWl0X3RvX2pzXzEuZGVmYXVsdChwYWdlLmV2YWx1YXRlKGZ1bmMsIC4uLmFyZ3MpKTtcbiAgICAgICAgICAgIGlmICghaXNGaW5pc2hlZCkge1xuICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7XG4gICAgICAgICAgICAgICAgaXNGaW5pc2hlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgZXZhbEVycm9yID8gcmVqZWN0KGV2YWxFcnJvcikgOiByZXNvbHZlKGV2YWxSZXN1bHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIHJlamVjdChuZXcgRXJyb3IoJ3BhZ2UgaXMgY2xvc2VkJykpO1xuICAgICAgICB9XG4gICAgfSk7XG59XG5leHBvcnRzLnRpbWVvdXRFdmFsdWF0ZVBhZ2UgPSB0aW1lb3V0RXZhbHVhdGVQYWdlO1xuZnVuY3Rpb24gdGltZW91dFdyYXAoYXN5bmNGdW5jLCB0aW1lb3V0ID0gNTAwMCkge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZShhc3luYyAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIGxldCBpc0ZpbmlzaGVkID0gZmFsc2U7XG4gICAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICBpc0ZpbmlzaGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoJ2FzeW5jRnVuYyBleGVjIHRpbWVvdXQgZXJyb3InKSk7XG4gICAgICAgIH0sIHRpbWVvdXQpO1xuICAgICAgICBjb25zdCBbYXN5bmNFcnJvciwgYXN5bmNSZXN1bHRdID0gYXdhaXQgYXdhaXRfdG9fanNfMS5kZWZhdWx0KGFzeW5jRnVuYygpKTtcbiAgICAgICAgaWYgKCFpc0ZpbmlzaGVkKSB7XG4gICAgICAgICAgICBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgICAgICAgICAgaXNGaW5pc2hlZCA9IHRydWU7XG4gICAgICAgICAgICBhc3luY0Vycm9yID8gcmVqZWN0KGFzeW5jRXJyb3IpIDogcmVzb2x2ZShhc3luY1Jlc3VsdCk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cbmV4cG9ydHMudGltZW91dFdyYXAgPSB0aW1lb3V0V3JhcDtcbmZ1bmN0aW9uIGZyYW1lJCQoZnJhbWUsIHNlbGVjdG9yKSB7XG4gICAgaWYgKCFmcmFtZS5pc0RldGFjaGVkKCkpIHtcbiAgICAgICAgcmV0dXJuIGZyYW1lLiQkKHNlbGVjdG9yKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIHJlcG9ydElkS2V5KElkS2V5LkZSQU1FX0RFVEFDSEVEKTtcbiAgICAgICAgbG9nXzEuZGVmYXVsdC5lcnJvcihgZnJhbWUuJCQgZmFpbGVkIGZyYW1lIGRldGFjaGVkIWApO1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYGZyYW1lIGRldGFjaGVkISBuYW1lOiAke2ZyYW1lLm5hbWUoKX1gKTtcbiAgICB9XG59XG5leHBvcnRzLmZyYW1lJCQgPSBmcmFtZSQkO1xuZnVuY3Rpb24gZnJhbWUkJGV2YWwoZnJhbWUsIHNlbGVjdG9yLCBmdW5jLCAuLi5hcmdzKSB7XG4gICAgaWYgKCFmcmFtZS5pc0RldGFjaGVkKCkpIHtcbiAgICAgICAgcmV0dXJuIGZyYW1lLiQkZXZhbChzZWxlY3RvciwgZnVuYywgLi4uYXJncyk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICAvLyByZXBvcnRJZEtleShJZEtleS5GUkFNRV9ERVRBQ0hFRCk7XG4gICAgICAgIGxvZ18xLmRlZmF1bHQuZXJyb3IoYGZyYW1lLiQkIGZhaWxlZCBmcmFtZSBkZXRhY2hlZCFgKTtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBmcmFtZSBkZXRhY2hlZCEgbmFtZTogJHtmcmFtZS5uYW1lKCl9YCk7XG4gICAgfVxufVxuZXhwb3J0cy5mcmFtZSQkZXZhbCA9IGZyYW1lJCRldmFsO1xuZnVuY3Rpb24gZnJhbWUkKGZyYW1lLCBzZWxlY3Rvcikge1xuICAgIGlmICghZnJhbWUuaXNEZXRhY2hlZCgpKSB7XG4gICAgICAgIHJldHVybiBmcmFtZS4kKHNlbGVjdG9yKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIHJlcG9ydElkS2V5KElkS2V5LkZSQU1FX0RFVEFDSEVEKTtcbiAgICAgICAgbG9nXzEuZGVmYXVsdC5lcnJvcihgZnJhbWUuJCBmYWlsZWQgZnJhbWUgZGV0YWNoZWQhYCk7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgZnJhbWUgZGV0YWNoZWQhIG5hbWU6ICR7ZnJhbWUubmFtZSgpfWApO1xuICAgIH1cbn1cbmV4cG9ydHMuZnJhbWUkID0gZnJhbWUkO1xuZnVuY3Rpb24gZ2V0RGF0YVJlcG9ydERlZmF1bHQocGFyYW1zKSB7XG4gICAgY29uc3QgeyBUYXNrVXJsLCBSZXN1bHRTdGF0dXMsIElzV2ViVmlldyA9IDAsIFBhcmVudFVybCA9ICcnLCBQa2dVbmV4aXN0ZWQgPSAwIH0gPSBwYXJhbXM7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgVGFza1BhZ2U6IFRhc2tVcmwuc3BsaXQoJz8nKVswXSxcbiAgICAgICAgVGFza1VybDogVGFza1VybC5zdWJzdHIoMCwgMTAwMCksXG4gICAgICAgIFJlc3VsdFBhZ2U6ICcnLFxuICAgICAgICBSZXN1bHRVcmw6ICcnLFxuICAgICAgICBIYXNBdXRvQ2xpY2s6IDAsXG4gICAgICAgIElzTmV0d29ya0lkbGVUaW1lT3V0OiAwLFxuICAgICAgICBJc1dlYnZpZXdXYWl0VGltZU91dDogMCxcbiAgICAgICAgVGltZUNvc3Q6IDAsXG4gICAgICAgIElzV2ViVmlldyxcbiAgICAgICAgV2FpdEZvcldlYnZpZXdFcnJvcjogMCxcbiAgICAgICAgUmVzdWx0U3RhdHVzOiBSZXN1bHRTdGF0dXMgfHwgMCxcbiAgICAgICAgVXJsQ3Jhd2xCZWdpblRpbWU6IERhdGUubm93KCksXG4gICAgICAgIFBrZ1VuZXhpc3RlZCxcbiAgICAgICAgUGFyZW50VXJsOiBQYXJlbnRVcmwuc3Vic3RyKDAsIDEwMDApXG4gICAgfTtcbn1cbmV4cG9ydHMuZ2V0RGF0YVJlcG9ydERlZmF1bHQgPSBnZXREYXRhUmVwb3J0RGVmYXVsdDtcbmZ1bmN0aW9uIGdldERldmljZUluZm8oKSB7XG4gICAgY29uc3QgaVBob25lID0gZGV2aWNlc1snaVBob25lIDYnXTtcbiAgICBpUGhvbmUudmlld3BvcnQuZGV2aWNlU2NhbGVGYWN0b3IgPSAxO1xuICAgIHJldHVybiBpUGhvbmU7XG59XG5leHBvcnRzLmdldERldmljZUluZm8gPSBnZXREZXZpY2VJbmZvO1xuZnVuY3Rpb24gZ2V0Q29va2llSW5mbyhhcHB1aW4sIHVybCkge1xuICAgIGNvbnN0IGRvbWFpbiA9IHVybC5tYXRjaCgvXmh0dHBzPzpcXC9cXC8oW146XFwvXSspWzpcXC9dL2kpO1xuICAgIGNvbnN0IHd4dWluID0gYXBwdWluID8gYXBwdWluIDogRGF0ZS5ub3coKSAqIDEwMDAgKyBwYXJzZUludChNYXRoLnJhbmRvbSgpICogMTAwMCArICcnLCAxMCk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbmFtZTogJ3d4dWluJyxcbiAgICAgICAgdmFsdWU6IHd4dWluICsgJycsXG4gICAgICAgIGV4cGlyZXM6IG5ldyBEYXRlKCcyMDM4LTAxLTE5VDAzOjE0OjA3LjAwJykuZ2V0VGltZSgpLFxuICAgICAgICBkb21haW46IGRvbWFpbiA/IGRvbWFpblsxXSA6ICd3eGFjcmF3bGVyLmNvbScsXG4gICAgICAgIHBhdGg6ICcvJyxcbiAgICAgICAgaHR0cE9ubHk6IGZhbHNlLFxuICAgIH07XG59XG5leHBvcnRzLmdldENvb2tpZUluZm8gPSBnZXRDb29raWVJbmZvO1xuZnVuY3Rpb24gZ2V0RmlsZU5hbWVCeVVybCh1cmwpIHtcbiAgICBsZXQgbmFtZSA9IHVybC5yZXBsYWNlKC9cXC58XFwvfFxcXFx8XFwqfFxcP3w9fCZ8JS9nLCAnXycpO1xuICAgIGlmIChuYW1lLmxlbmd0aCA+IDE2OCkge1xuICAgICAgICBuYW1lID0gbmFtZS5zdWJzdHIoMCwgMTY4KSArICdfJyArIE1hdGgucm91bmQoRGF0ZS5ub3coKSAvIDEwMDApO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgbmFtZSArPSAnXycgKyBNYXRoLnJvdW5kKERhdGUubm93KCkgLyAxMDAwKTtcbiAgICB9XG4gICAgcmV0dXJuIG5hbWU7XG59XG5leHBvcnRzLmdldEZpbGVOYW1lQnlVcmwgPSBnZXRGaWxlTmFtZUJ5VXJsO1xuZnVuY3Rpb24gY2hlY2tJbWFnZVZhbGlkKGltYWdlVXJsKSB7XG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgwKTtcbiAgICAvKlxuICAgIGNvbnN0IHJhbmQgPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkqKDEwMCkpO1xuICAgIGlmIChyYW5kID4gMCkge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKDApO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJlcXVlc3Qoe1xuICAgICAgICAgICAgICAgIHVybDogaW1hZ2VVcmwsXG4gICAgICAgICAgICAgICAgbWV0aG9kOiBcIkdFVFwiLFxuICAgICAgICAgICAgICAgIHRpbWVvdXQ6IDMwMDAsXG4gICAgICAgICAgICB9LCAoZXJyb3IsIHJlc3BvbnNlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFlcnJvciAmJiAvMlxcZFxcZHwzMDQvLnRlc3QocmVzcG9uc2Uuc3RhdHVzQ29kZS50b1N0cmluZygpKSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjb250ZW50VHlwZTogc3RyaW5nID0gcmVzcG9uc2UuaGVhZGVyc1snY29udGVudC10eXBlJ10gfHwgJyc7XG4gICAgICAgICAgICAgICAgICAgIExvZ2dlci5pbmZvKGAke2NvbnRlbnRUeXBlfWApO1xuICAgICAgICAgICAgICAgICAgICBpZiAoL2ltYWdlL2kudGVzdChjb250ZW50VHlwZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNvbHZlKDApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVwb3J0SWRLZXkoSWRLZXkuSU5WQUxJRF9TSEFSRV9JTUFHRSk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzb2x2ZSgtMSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICByZXBvcnRJZEtleShJZEtleS5DSEVDS19TSEFSRV9JTUFHRV9FUlIpO1xuICAgICAgICAgICAgICAgICAgICBMb2dnZXIuZXJyb3IoYGNoZWNrU2hhcmVEYXRhSW1hZ2VVcmwgJHtpbWFnZVVybH0gZmFpbGVkISAke2Vycm9yfWApO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzb2x2ZSgtMSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIHJlcG9ydElkS2V5KElkS2V5LkNIRUNLX1NIQVJFX0lNQUdFX0NBVENIX0VSUik7XG4gICAgICAgICAgICBMb2dnZXIuZXJyb3IoYGNoZWNrU2hhcmVEYXRhSW1hZ2VVcmwgcmVxdWVzdCBlcnJvciAke2ltYWdlVXJsfSEgJHtlLm1lc3NhZ2V9YCk7XG4gICAgICAgICAgICByZXR1cm4gcmVzb2x2ZSgtMSk7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICAqL1xufVxuZXhwb3J0cy5jaGVja0ltYWdlVmFsaWQgPSBjaGVja0ltYWdlVmFsaWQ7XG5jb25zdCBwcmVmaXggPSBTdHJpbmcoRGF0ZS5ub3coKSkuc3Vic3RyKDAsIDUpO1xuY29uc3QgdGltZVJlZyA9IG5ldyBSZWdFeHAoYD0ke3ByZWZpeH1cXFxcZHs4LH0oJHwmKWApO1xuZnVuY3Rpb24gcmVwbGFjZVRpbWVTdGFtcCh1cmwpIHtcbiAgICBpZiAoIXVybClcbiAgICAgICAgcmV0dXJuIHVybDtcbiAgICBpZiAoIXRpbWVSZWcudGVzdCh1cmwpKVxuICAgICAgICByZXR1cm4gdXJsO1xuICAgIC8vIOmcgOimgeabv+aNolxuICAgIGNvbnN0IFtwYXRoLCBwYXJhbXNdID0gdXJsLnNwbGl0KCc/Jyk7XG4gICAgaWYgKHBhcmFtcykge1xuICAgICAgICBjb25zdCBxdWVyeSA9IHFzLnBhcnNlKHBhcmFtcyk7XG4gICAgICAgIGNvbnN0IG5ld1F1ZXJ5ID0gT2JqZWN0LmtleXMocXVlcnkpLnJlZHVjZSgob2JqLCBrZXkpID0+IHtcbiAgICAgICAgICAgIGlmICgvXlxcZHsxMyx9JC8udGVzdChxdWVyeVtrZXldKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBvYmo7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvYmpba2V5XSA9IHF1ZXJ5W2tleV07XG4gICAgICAgICAgICByZXR1cm4gb2JqO1xuICAgICAgICB9LCB7fSk7XG4gICAgICAgIGNvbnN0IG5ld1VybCA9IGAke3BhdGh9PyR7cXMuc3RyaW5naWZ5KG5ld1F1ZXJ5KX1gO1xuICAgICAgICBsb2dfMS5kZWZhdWx0LmluZm8oYHJlcGxhY2UgdGltZXN0YW1wOiAke3VybH0gPT4gJHtuZXdVcmx9YCk7XG4gICAgICAgIHJldHVybiBuZXdVcmw7XG4gICAgfVxuICAgIHJldHVybiB1cmw7XG59XG5leHBvcnRzLnJlcGxhY2VUaW1lU3RhbXAgPSByZXBsYWNlVGltZVN0YW1wO1xuZnVuY3Rpb24gcmVtb3ZlVXNlbGVzc1BhcmFtKHVybCkge1xuICAgIGlmICghdXJsKVxuICAgICAgICByZXR1cm4gdXJsO1xuICAgIGNvbnN0IHVybE9iaiA9IG5ldyB1cmxVdGlsLlVSTCh1cmwsICdodHRwOi8vbXBjcmF3bGVyJyk7XG4gICAgdXJsT2JqLnNlYXJjaFBhcmFtcy5kZWxldGUoJ3B0cCcpO1xuICAgIHVybE9iai5zZWFyY2hQYXJhbXMuZGVsZXRlKCdyZWZfcGFnZV9uYW1lJyk7XG4gICAgdXJsT2JqLnNlYXJjaFBhcmFtcy5kZWxldGUoJ3JlZl9wYWdlX2lkJyk7XG4gICAgdXJsT2JqLnNlYXJjaFBhcmFtcy5kZWxldGUoJ2FjbScpO1xuICAgIHVybE9iai5zZWFyY2hQYXJhbXMuZGVsZXRlKCdvcGVuaWQnKTtcbiAgICB1cmxPYmouc2VhcmNoUGFyYW1zLmRlbGV0ZSgnY29tZWZyb20nKTtcbiAgICBjb25zdCBuZXdVcmwgPSB1cmxPYmouaHJlZi5yZXBsYWNlKCdodHRwOi8vbXBjcmF3bGVyLycsICcnKTtcbiAgICBsb2dfMS5kZWZhdWx0LmluZm8oYG5ld1VybCBpcyAke25ld1VybH1gKTtcbiAgICByZXR1cm4gbmV3VXJsO1xufVxuZXhwb3J0cy5yZW1vdmVVc2VsZXNzUGFyYW0gPSByZW1vdmVVc2VsZXNzUGFyYW07XG5mdW5jdGlvbiBpc0JsYWNrUmVxdWVzdCh1cmwsIGJsYWNrVXJsTGlzdCkge1xuICAgIGlmICghdXJsKVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgY29uc3QgdXJsT2JqID0gbmV3IHVybFV0aWwuVVJMKHVybCwgJ2h0dHA6Ly9tcGNyYXdsZXInKTtcbiAgICBjb25zdCByZXF1ZXN0VXJsID0gdXJsT2JqLnNlYXJjaFBhcmFtcy5nZXQoJ3VybCcpO1xuICAgIGlmIChyZXF1ZXN0VXJsKSB7XG4gICAgICAgIGNvbnN0IHJlTWF0Y2ggPSByZXF1ZXN0VXJsLnNwbGl0KCc/JylbMF0ubWF0Y2goL2h0dHBzOlxcL1xcLyguKz8pXFwvL2kpO1xuICAgICAgICBjb25zdCBob3N0ID0gcmVNYXRjaCA/IHJlTWF0Y2hbMV0ucmVwbGFjZSgvXlxccyt8XFxzKyQvZywgXCJcIikgOiBcIlwiO1xuICAgICAgICAvLyBMb2dnZXIuaW5mbyhgYmxhY2sgaG9zdCBpcyAke2hvc3R9YClcbiAgICAgICAgaWYgKGJsYWNrVXJsTGlzdC5pbmRleE9mKGhvc3QpICE9PSAtMSkge1xuICAgICAgICAgICAgbG9nXzEuZGVmYXVsdC5pbmZvKGBibGFjayB1cmwgaXMgJHtob3N0fWApO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gY29uc3QgaG9zdCA9IHJlcXVlc3RVcmwgPyByZXF1ZXN0VXJsLnNwbGl0KCc/JylbMF0ucmVwbGFjZSgvXlxccyt8XFxzKyQvZyxcIlwiKSA6IFwiXCI7XG4gICAgLy8gTG9nZ2VyLmluZm8oYHVybGhvc3QgaXMgJHtob3N0fSBibGFjayB1cmwgaXMgJHtKU09OLnN0cmluZ2lmeShibGFja1VybExpc3QpfWApO1xuICAgIC8vIGlmIChyZXF1ZXN0VXJsICYmIHJlcXVlc3RVcmwuc3BsaXQoJz8nKVswXSBpbiBibGFja1VybExpc3QpIHtcbiAgICByZXR1cm4gZmFsc2U7XG59XG5leHBvcnRzLmlzQmxhY2tSZXF1ZXN0ID0gaXNCbGFja1JlcXVlc3Q7XG5mdW5jdGlvbiBpc0JsYW5rUGljdHVyZShwaWMpIHtcbiAgICBjb25zdCByZXN1bHQgPSBqaW1wXzEuZGVmYXVsdC5yZWFkKHBpYykudGhlbihpbWFnZSA9PiB7XG4gICAgICAgIGltYWdlID0gaW1hZ2UuZ3JleXNjYWxlKCk7IC8vIC53cml0ZSgnbGFqaWdvdS5qcGcnKTtcbiAgICAgICAgLy8gY29uc3QgdGhyZXNob2xkID0gODA7IC8vIOmYiOWAvFxuICAgICAgICBjb25zdCBwaXhlbENvbG9ySW5mbyA9IHt9OyAvLyA6IE1hcDxudW1iZXIsIG51bWJlcj4gPSBuZXcgTWFwKCk7XG4gICAgICAgIC8vIOWDj+e0oOajgOa1i1xuICAgICAgICBsb2dfMS5kZWZhdWx0LmluZm8oYHdpZHRoPSR7aW1hZ2UuYml0bWFwLndpZHRofSBoZWlnaHQ9JHtpbWFnZS5iaXRtYXAuaGVpZ2h0fWApO1xuICAgICAgICBpbWFnZS5zY2FuKDAsIDY3LCBpbWFnZS5iaXRtYXAud2lkdGggLSAxLCBpbWFnZS5iaXRtYXAuaGVpZ2h0IC0gNjcsIGZ1bmN0aW9uICh4LCB5LCBpZHgpIHtcbiAgICAgICAgICAgIGlmICh4ICE9PSBpbWFnZS5iaXRtYXAud2lkdGggLSAxICYmIHkgIT09IGltYWdlLmJpdG1hcC5oZWlnaHQgLSAxKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgYml0ID0gdGhpcy5iaXRtYXAuZGF0YVtpZHggKyAwXTtcbiAgICAgICAgICAgICAgICBpZiAoIXBpeGVsQ29sb3JJbmZvW2JpdF0pIHtcbiAgICAgICAgICAgICAgICAgICAgcGl4ZWxDb2xvckluZm9bYml0XSA9IDA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHBpeGVsQ29sb3JJbmZvW2JpdF0gKz0gMTtcbiAgICAgICAgICAgICAgICBpZiAoYml0ID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgbG9nXzEuZGVmYXVsdC5pbmZvKGB1bmRlZmluZSBiaXQgeD0ke3h9IHk9JHt5fSBpZHg9JHtpZHh9IGJpdD0ke2JpdH1gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICAvLyDpmY3luo9cbiAgICAgICAgY29uc3QgcGl4ZWxDb2xvckxpc3QgPSBPYmplY3Qua2V5cyhwaXhlbENvbG9ySW5mbykuc29ydCgoYSwgYikgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHBpeGVsQ29sb3JJbmZvW2FdIDwgcGl4ZWxDb2xvckluZm9bYl0gPyAxIDogLTE7XG4gICAgICAgIH0pO1xuICAgICAgICBsZXQgbWF4UGl4ZWxQZXJjZW50ID0gcGl4ZWxDb2xvckluZm9bcGl4ZWxDb2xvckxpc3RbMF1dIC8gKGltYWdlLmJpdG1hcC53aWR0aCAqIGltYWdlLmJpdG1hcC5oZWlnaHQpO1xuICAgICAgICBjb25zdCBzZWNvbmRQaXhlbFBlcmNlbnQgPSBwaXhlbENvbG9ySW5mb1twaXhlbENvbG9yTGlzdFsxXV0gLyAoaW1hZ2UuYml0bWFwLndpZHRoICogaW1hZ2UuYml0bWFwLmhlaWdodCk7XG4gICAgICAgIGxvZ18xLmRlZmF1bHQuaW5mbyhgbWF4UGl4ZWxQZXJjZW50ID0gJHttYXhQaXhlbFBlcmNlbnR9IHNlY29uZFBpeGVsUGVyY2VudCA9ICR7c2Vjb25kUGl4ZWxQZXJjZW50fWApO1xuICAgICAgICBpZiAobWF4UGl4ZWxQZXJjZW50ID4gMC41ICYmIHNlY29uZFBpeGVsUGVyY2VudCA+IDAuMikge1xuICAgICAgICAgICAgbWF4UGl4ZWxQZXJjZW50ICs9IDAuMTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbWF4UGl4ZWxQZXJjZW50ICogMTAwO1xuICAgICAgICAvLyBmb3IgKGNvbnN0IGtleSBvZiBwaXhlbENvbG9yTGlzdCkge1xuICAgICAgICAvLyAgICAgTG9nZ2VyLmluZm8oYCR7a2V5fSBjb3VudCBpcyAke3BpeGVsQ29sb3JJbmZvW2tleV19YCk7XG4gICAgICAgIC8vIH1cbiAgICAgICAgLy8gaWYgKG1heFBpeGVsUGVyY2VudCoxMDAgPiB0aHJlc2hvbGQpIHtcbiAgICAgICAgLy8gICAgIHJldHVybiB0cnVlO1xuICAgICAgICAvLyB9IGVsc2Uge1xuICAgICAgICAvLyAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAvLyB9XG4gICAgfSlcbiAgICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgbG9nXzEuZGVmYXVsdC5lcnJvcihgaXNCbGFua1BpY3R1cmUgZmFpbGVkISAke2Vycn1gKTtcbiAgICAgICAgcmV0dXJuIDA7XG4gICAgfSk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cbmV4cG9ydHMuaXNCbGFua1BpY3R1cmUgPSBpc0JsYW5rUGljdHVyZTtcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImF3YWl0LXRvLWpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInBhdGhcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZnMtZXh0cmFcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwidXJsXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInFzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInB1cHBldGVlci9EZXZpY2VEZXNjcmlwdG9yc1wiKTsiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuSURLX0xJQiA9ICcvaG9tZS9xc3BhY2UvbW1iaXp3eGFjcmF3bGVyd29ya2VyL2xpYjY0L2xpYm9zc2F0dHJhcGknO1xuZXhwb3J0cy5NYWluSWRLZXkgPSAxMTg3MjI7XG52YXIgSWRLZXk7XG4oZnVuY3Rpb24gKElkS2V5KSB7XG4gICAgSWRLZXlbSWRLZXlbXCJUQVNLX1NUQVJUXCJdID0gMV0gPSBcIlRBU0tfU1RBUlRcIjtcbiAgICBJZEtleVtJZEtleVtcIlBST0NFU1NfQ1JBU0hcIl0gPSAyXSA9IFwiUFJPQ0VTU19DUkFTSFwiO1xuICAgIElkS2V5W0lkS2V5W1wiUEFHRV9DUkFTSFwiXSA9IDNdID0gXCJQQUdFX0NSQVNIXCI7XG4gICAgSWRLZXlbSWRLZXlbXCJUQVNLX1NVQ0NcIl0gPSA0XSA9IFwiVEFTS19TVUNDXCI7XG4gICAgSWRLZXlbSWRLZXlbXCJDUkFXTEVSX0VSUk9SXCJdID0gNV0gPSBcIkNSQVdMRVJfRVJST1JcIjtcbiAgICBJZEtleVtJZEtleVtcIkZJUlNUX1BBR0VfUkVESVJFQ1RcIl0gPSA2XSA9IFwiRklSU1RfUEFHRV9SRURJUkVDVFwiO1xuICAgIElkS2V5W0lkS2V5W1wiSVNfQWxsX1dFQlZJRVdcIl0gPSA3XSA9IFwiSVNfQWxsX1dFQlZJRVdcIjtcbiAgICBJZEtleVtJZEtleVtcIkFVRElUU19GUkFNRV9ERVRBQ0hFRFwiXSA9IDhdID0gXCJBVURJVFNfRlJBTUVfREVUQUNIRURcIjtcbiAgICBJZEtleVtJZEtleVtcIkdFTl9SRVNVTFRfRVJST1JcIl0gPSA5XSA9IFwiR0VOX1JFU1VMVF9FUlJPUlwiO1xuICAgIElkS2V5W0lkS2V5W1wiR0VOX1JFU1VMVF9PVVRfT0ZfVElNRVwiXSA9IDEwXSA9IFwiR0VOX1JFU1VMVF9PVVRfT0ZfVElNRVwiO1xuICAgIElkS2V5W0lkS2V5W1wiUEFHRV9JU19XRUJWSUVXXCJdID0gMTFdID0gXCJQQUdFX0lTX1dFQlZJRVdcIjtcbiAgICBJZEtleVtJZEtleVtcIlBBR0VfTk9fRlJBTUVcIl0gPSAxMl0gPSBcIlBBR0VfTk9fRlJBTUVcIjtcbiAgICBJZEtleVtJZEtleVtcIkdFVF9DTElDS0FCTEVfRUxFTUVOVF9FUlJPUlwiXSA9IDEzXSA9IFwiR0VUX0NMSUNLQUJMRV9FTEVNRU5UX0VSUk9SXCI7XG4gICAgSWRLZXlbSWRLZXlbXCJGT1VORF9OT19DTElDS0FCTEVfRUxFTUVOVFNcIl0gPSAxNF0gPSBcIkZPVU5EX05PX0NMSUNLQUJMRV9FTEVNRU5UU1wiO1xuICAgIElkS2V5W0lkS2V5W1wiQ0xJQ0tfRUxFTUVOVF9FUlJPUlwiXSA9IDE1XSA9IFwiQ0xJQ0tfRUxFTUVOVF9FUlJPUlwiO1xuICAgIElkS2V5W0lkS2V5W1wiUEFHRV9FWENFUFRJT05cIl0gPSAxNl0gPSBcIlBBR0VfRVhDRVBUSU9OXCI7XG4gICAgSWRLZXlbSWRLZXlbXCJDT0RFU1ZSX1JFUVVFU1RfRkFJTEVEXCJdID0gMTddID0gXCJDT0RFU1ZSX1JFUVVFU1RfRkFJTEVEXCI7XG4gICAgSWRLZXlbSWRLZXlbXCJDT0RFU1ZSX1JFUVVFU1RfU1VDQ1wiXSA9IDE4XSA9IFwiQ09ERVNWUl9SRVFVRVNUX1NVQ0NcIjtcbiAgICBJZEtleVtJZEtleVtcIlJFUVVFU1RfU1dfRkFJTEVEXCJdID0gMTldID0gXCJSRVFVRVNUX1NXX0ZBSUxFRFwiO1xuICAgIElkS2V5W0lkS2V5W1wiUkVRVUVTVF9TV19TVUNDXCJdID0gMjBdID0gXCJSRVFVRVNUX1NXX1NVQ0NcIjtcbiAgICBJZEtleVtJZEtleVtcIlJFUVVFU1RfRkFJTEVEXCJdID0gMjFdID0gXCJSRVFVRVNUX0ZBSUxFRFwiO1xuICAgIElkS2V5W0lkS2V5W1wiUkVRVUVTVF9TVUNDXCJdID0gMjJdID0gXCJSRVFVRVNUX1NVQ0NcIjtcbiAgICBJZEtleVtJZEtleVtcIlNRVUlEX1JFUVVFU1RfRkFJTEVEXCJdID0gMjNdID0gXCJTUVVJRF9SRVFVRVNUX0ZBSUxFRFwiO1xuICAgIElkS2V5W0lkS2V5W1wiU1FVSURfUkVRVUVTVF9TVUNDXCJdID0gMjRdID0gXCJTUVVJRF9SRVFVRVNUX1NVQ0NcIjtcbiAgICBJZEtleVtJZEtleVtcIk5FVFdPUktfSURMRV9USU1FT1VUXCJdID0gMjVdID0gXCJORVRXT1JLX0lETEVfVElNRU9VVFwiO1xuICAgIElkS2V5W0lkS2V5W1wiVEFTS19OT19SRVNVTFRcIl0gPSAyNl0gPSBcIlRBU0tfTk9fUkVTVUxUXCI7XG4gICAgSWRLZXlbSWRLZXlbXCJESUFMT0dfRVZFTlRcIl0gPSAyN10gPSBcIkRJQUxPR19FVkVOVFwiO1xuICAgIElkS2V5W0lkS2V5W1wiQVBQX0RFQURcIl0gPSAyOF0gPSBcIkFQUF9ERUFEXCI7XG59KShJZEtleSA9IGV4cG9ydHMuSWRLZXkgfHwgKGV4cG9ydHMuSWRLZXkgPSB7fSkpO1xuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5jb25zdCBwYXRoID0gcmVxdWlyZShcInBhdGhcIik7XG5jb25zdCBmcyA9IHJlcXVpcmUoXCJmcy1leHRyYVwiKTtcbmNvbnN0IHB1cHBldGVlciA9IHJlcXVpcmUoXCJwdXBwZXRlZXJcIik7XG5jb25zdCBBdWRpdHNBdXRvXzEgPSByZXF1aXJlKFwiLi9BdWRpdHNBdXRvXCIpO1xuY29uc3QgbG9nXzEgPSByZXF1aXJlKFwiLi4vbG9nXCIpO1xuY29uc3QgcmVwb3J0SWRLZXlfMSA9IHJlcXVpcmUoXCIuLi91dGlsL3JlcG9ydElkS2V5XCIpO1xuY29uc3QgaXNQcm9kID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdwcm9kdWN0aW9uJztcbmNvbnN0IGdldFRhc2tFbnYgPSBmdW5jdGlvbiAoKSB7XG4gICAgY29uc3QgYXBwaWQgPSBwcm9jZXNzLmVudi5hcHBpZDtcbiAgICBjb25zdCB0YXNraWQgPSBwcm9jZXNzLmVudi50YXNraWQ7XG4gICAgY29uc3QgYXBwdWluID0gcGFyc2VJbnQocHJvY2Vzcy5lbnYuYXBwdWluLCAxMCkgfHwgMDtcbiAgICBjb25zdCBpbmRleFBhZ2VVcmwgPSBwcm9jZXNzLmVudi5pbmRleFBhZ2VVcmw7XG4gICAgY29uc3QgdGVzdFRpY2tldCA9IHByb2Nlc3MuZW52LnRpY2tldDtcbiAgICBsZXQgUkVTVUxUX1BBVEggPSBwYXRoLnJlc29sdmUocHJvY2Vzcy5jd2QoKSwgYC4vdGFzay8ke2FwcGlkfV8ke3Rhc2tpZH0vcmVzdWx0YCk7XG4gICAgaWYgKHByb2Nlc3MuZW52LnRhc2tQYXRoKSB7XG4gICAgICAgIFJFU1VMVF9QQVRIID0gcGF0aC5yZXNvbHZlKHByb2Nlc3MuZW52LnRhc2tQYXRoLCBgLi8ke2FwcGlkfV8ke3Rhc2tpZH0vcmVzdWx0YCk7XG4gICAgfVxuICAgIGNvbnN0IGF1ZGl0QnVzaW5lc3MgPSBbMiwgNCwgNywgMTAsIDEzLCAxNCwgMTVdO1xuICAgIGNvbnN0IHJlTWF0Y2ggPSBpbmRleFBhZ2VVcmwubWF0Y2goL3d4YWNyYXdsZXJcXC9cXGR7MSwyfV8oXFxkezEsMn0pXFwvL2kpO1xuICAgIGNvbnN0IGJ1c2luZXNzSWQgPSByZU1hdGNoID8gcGFyc2VJbnQocmVNYXRjaFsxXSwgMTApIDogMDtcbiAgICBsZXQgaXNNcGNyYXdsZXIgPSBmYWxzZTtcbiAgICBpZiAoYXVkaXRCdXNpbmVzcy5pbmRleE9mKGJ1c2luZXNzSWQpID09PSAtMSkge1xuICAgICAgICBpc01wY3Jhd2xlciA9IHRydWU7XG4gICAgfVxuICAgIGxldCBwYXJhbUxpc3QgPSBbXTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBwYXJhbUpzb24gPSBKU09OLnBhcnNlKHByb2Nlc3MuZW52LnRhc2tQYXJhbSk7XG4gICAgICAgIGlmIChwYXJhbUpzb24uaGFzT3duUHJvcGVydHkoJ3BhcmFtX2xpc3QnKSkge1xuICAgICAgICAgICAgcGFyYW1MaXN0ID0gcGFyYW1Kc29uLnBhcmFtX2xpc3Q7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgbG9nXzEuZGVmYXVsdC5lcnJvcihganNvbiBwYXJzZSBlcnJvciEgJHtwcm9jZXNzLmVudi50YXNrUGFyYW19YCk7XG4gICAgfVxuICAgIGxldCBleHRJbmZvID0ge307XG4gICAgaWYgKHByb2Nlc3MuZW52LmV4dEluZm8gJiYgcHJvY2Vzcy5lbnYuZXh0SW5mby5sZW5ndGgpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGV4dEluZm8gPSBKU09OLnBhcnNlKHByb2Nlc3MuZW52LmV4dEluZm8pO1xuICAgICAgICAgICAgbG9nXzEuZGVmYXVsdC5pbmZvKGBleHRJbmZvICR7SlNPTi5zdHJpbmdpZnkoZXh0SW5mbyl9YCk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGxvZ18xLmRlZmF1bHQuZXJyb3IoYGpzb24gcGFyc2UgZXJyb3IhICR7cHJvY2Vzcy5lbnYuZXh0SW5mb31gKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBhcHBpZCxcbiAgICAgICAgdGFza2lkLFxuICAgICAgICBhcHB1aW4sXG4gICAgICAgIGluZGV4UGFnZVVybCxcbiAgICAgICAgdGVzdFRpY2tldCxcbiAgICAgICAgUkVTVUxUX1BBVEgsXG4gICAgICAgIGlzTXBjcmF3bGVyLFxuICAgICAgICBidXNpbmVzc0lkLFxuICAgICAgICBwYXJhbUxpc3QsXG4gICAgICAgIGV4dEluZm8sXG4gICAgfTtcbn07XG4oYXN5bmMgKCkgPT4ge1xuICAgIHJlcG9ydElkS2V5XzEucmVwb3J0SWRLZXkocmVwb3J0SWRLZXlfMS5JZEtleS5UQVNLX1NUQVJUKTtcbiAgICBjb25zdCB0YXNrU3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcbiAgICBjb25zdCB0YXNrRW52ID0gZ2V0VGFza0VudigpO1xuICAgIGNvbnN0IHsgcGFyYW1MaXN0IH0gPSB0YXNrRW52O1xuICAgIGlmIChwYXJhbUxpc3QubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIGxvZ18xLmRlZmF1bHQuZXJyb3IoYHBhcmFtTGlzdCBlcnJvciEgJHtwcm9jZXNzLmVudi50YXNrUGFyYW19YCk7XG4gICAgICAgIHJldHVybiAtNDAwMDtcbiAgICB9XG4gICAgY29uc3QgY29uZmlnID0ge1xuICAgICAgICB1cmw6IHRhc2tFbnYuaW5kZXhQYWdlVXJsLFxuICAgICAgICBhcHBpZDogdGFza0Vudi5hcHBpZCxcbiAgICAgICAgdGFza2lkOiB0YXNrRW52LnRhc2tpZCxcbiAgICAgICAgYXBwdWluOiB0YXNrRW52LmFwcHVpbixcbiAgICAgICAgYnVzaW5lc3NJZDogdGFza0Vudi5idXNpbmVzc0lkLFxuICAgICAgICByZXN1bHRQYXRoOiB0YXNrRW52LlJFU1VMVF9QQVRILFxuICAgICAgICB0YXNrU3RhcnRUaW1lLFxuICAgICAgICBjcmF3bF90eXBlOiBwYXJhbUxpc3RbMF0uY3Jhd2xfdHlwZSxcbiAgICAgICAgbG9uZ2l0dWRlOiBwYXJhbUxpc3RbMF0ubG9uZ2l0dWRlLFxuICAgICAgICBsYXRpdHVkZTogcGFyYW1MaXN0WzBdLmxhdGl0dWRlLFxuICAgICAgICByZWRpcmVjdHRvX3VybDogcGFyYW1MaXN0WzBdLnJlZGlyZWN0dG9fdXJsLFxuICAgICAgICBleHRJbmZvOiB0YXNrRW52LmV4dEluZm9cbiAgICB9O1xuICAgIGNvbnN0IGxvZ1BhdGggPSBgJHt0YXNrRW52LlJFU1VMVF9QQVRIfWA7XG4gICAgZnMuZW5zdXJlRGlyU3luYyhsb2dQYXRoKTtcbiAgICBmcy5lbnN1cmVEaXJTeW5jKGAke3Rhc2tFbnYuUkVTVUxUX1BBVEh9L3NjcmVlbnNob3RgKTtcbiAgICBmcy5lbnN1cmVEaXJTeW5jKGAke3Rhc2tFbnYuUkVTVUxUX1BBVEh9L2h0bWxgKTtcbiAgICBsb2dfMS5kZWZhdWx0LmluaXRMb2dnZXIobG9nUGF0aCwgY29uZmlnLmFwcGlkKTtcbiAgICBsZXQgYnJvd3NlckFyZ3MgPSBbXTtcbiAgICBpZiAoaXNQcm9kKSB7XG4gICAgICAgIGJyb3dzZXJBcmdzID0gW1xuICAgICAgICAgICAgJy0tcHJveHktc2VydmVyPWh0dHA6Ly9tbWJpend4YWF1ZGl0bmF0cHJveHkud3guY29tOjExMTc3JyxcbiAgICAgICAgICAgICctLXByb3h5LWJ5cGFzcy1saXN0PTEwLjIwNi4zMC44MDoxMjM2MTs5LjIuODcuMjIyOjEyMzYxOyo6MTg1NjknXG4gICAgICAgIF07XG4gICAgICAgIC8vICctLXByb3h5LWJ5cGFzcy1saXN0PTEwLjIwNi4zMC44MDoxMjM2MTs5LjIuODcuMjIyOjEyMzYxJ107XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBicm93c2VyQXJncyA9IFtcbiAgICAgICAgLy8gJy0tcHJveHktc2VydmVyPWh0dHA6Ly8xMjcuMC4wLjE6MTI2MzknXG4gICAgICAgIF07XG4gICAgfVxuICAgIGNvbnN0IGlzSGVhZGxlc3MgPSBwcm9jZXNzLmVudi5jaHJvbWVNb2RlID09PSAnaGVhZGxlc3MnO1xuICAgIGNvbnN0IHB1cHBldGVlckNvbmZpZyA9IHtcbiAgICAgICAgaGVhZGxlc3M6IGlzSGVhZGxlc3MsXG4gICAgICAgIGRldnRvb2xzOiBmYWxzZSxcbiAgICAgICAgaWdub3JlSFRUUFNFcnJvcnM6IHRydWUsXG4gICAgICAgIGFyZ3M6IFsnLS1uby1zYW5kYm94JywgLi4uYnJvd3NlckFyZ3NdLFxuICAgIH07XG4gICAgbG9nXzEuZGVmYXVsdC5pbmZvKCdwdXBwZXRlZXJDb25maWcnLCBwdXBwZXRlZXJDb25maWcpO1xuICAgIGNvbnN0IGJyb3dzZXIgPSBhd2FpdCBwdXBwZXRlZXIubGF1bmNoKHB1cHBldGVlckNvbmZpZyk7XG4gICAgcHJvY2Vzcy5vbigndW5jYXVnaHRFeGNlcHRpb24nLCBhc3luYyAoZXJyb3IpID0+IHtcbiAgICAgICAgbG9nXzEuZGVmYXVsdC5lcnJvcihgY2F0Y2ggcHJvY2VzcyBlcnJvciAke2Vycm9yLm1lc3NhZ2V9XFxuICR7ZXJyb3Iuc3RhY2t9YCk7XG4gICAgICAgIHJlcG9ydElkS2V5XzEucmVwb3J0SWRLZXkocmVwb3J0SWRLZXlfMS5JZEtleS5QUk9DRVNTX0NSQVNIKTtcbiAgICAgICAgYXdhaXQgYnJvd3Nlci5jbG9zZSgpO1xuICAgICAgICBwcm9jZXNzLmV4aXQoKTtcbiAgICB9KTtcbiAgICBwcm9jZXNzLm9uKCd3YXJuaW5nJywgKGVycm9yKSA9PiB7XG4gICAgICAgIGxvZ18xLmRlZmF1bHQud2FybigncHJvY2VzcyBvbiB3YXJuaW5nJyk7XG4gICAgICAgIGxvZ18xLmRlZmF1bHQud2FybihlcnJvci5tZXNzYWdlKTtcbiAgICAgICAgbG9nXzEuZGVmYXVsdC53YXJuKGVycm9yLnN0YWNrKTtcbiAgICB9KTtcbiAgICBjb25zdCBwYWdlID0gYXdhaXQgYnJvd3Nlci5uZXdQYWdlKCk7XG4gICAgY29uc3QgYXVkaXRzQXV0byA9IG5ldyBBdWRpdHNBdXRvXzEuZGVmYXVsdChwYWdlLCBjb25maWcpO1xuICAgIGxvZ18xLmRlZmF1bHQuaW5mbygnbmV3IEF1ZGl0c0F1dG8gQ3Jhd2xlciBzdWNjJyk7XG4gICAgYXVkaXRzQXV0by5vbigncGFnZUVycm9yJywgYXN5bmMgKGVycm9yKSA9PiB7XG4gICAgICAgIGxvZ18xLmRlZmF1bHQuZXJyb3IoYGNhdGNoIHBhZ2UgY3Jhc2ggJHtlcnJvci5tZXNzYWdlfVxcbiAke2Vycm9yLnN0YWNrfWApO1xuICAgICAgICBhd2FpdCBicm93c2VyLmNsb3NlKCk7XG4gICAgICAgIHByb2Nlc3MuZXhpdCgpO1xuICAgIH0pO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHRhc2tSZXN1bHQgPSBhd2FpdCBhdWRpdHNBdXRvLnN0YXJ0KCk7XG4gICAgICAgIGxvZ18xLmRlZmF1bHQuaW5mbyhgVGltZSBjb3N0ICR7TWF0aC5yb3VuZCgoRGF0ZS5ub3coKSAtIHRhc2tTdGFydFRpbWUpIC8gMTAwMCl9IHNgKTtcbiAgICAgICAgbG9nXzEuZGVmYXVsdC5pbmZvKCdBdWRpdHMgcmVzdWx0OiAnLCBKU09OLnN0cmluZ2lmeSh0YXNrUmVzdWx0KSk7XG4gICAgICAgIGlmICh0YXNrUmVzdWx0KSB7XG4gICAgICAgICAgICByZXBvcnRJZEtleV8xLnJlcG9ydElkS2V5KHJlcG9ydElkS2V5XzEuSWRLZXkuVEFTS19TVUNDKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJlcG9ydElkS2V5XzEucmVwb3J0SWRLZXkocmVwb3J0SWRLZXlfMS5JZEtleS5UQVNLX05PX1JFU1VMVCk7XG4gICAgICAgIH1cbiAgICAgICAgYXdhaXQgYnJvd3Nlci5jbG9zZSgpO1xuICAgICAgICBwcm9jZXNzLmV4aXQoKTtcbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgbG9nXzEuZGVmYXVsdC5lcnJvcihgY2F0Y2ggbWFpbiBlcnJvciAke2UubWVzc2FnZX1cXG4gJHtlLnN0YWNrfWApO1xuICAgICAgICByZXBvcnRJZEtleV8xLnJlcG9ydElkS2V5KHJlcG9ydElkS2V5XzEuSWRLZXkuQ1JBV0xFUl9FUlJPUik7XG4gICAgICAgIGF3YWl0IGJyb3dzZXIuY2xvc2UoKTtcbiAgICAgICAgcHJvY2Vzcy5leGl0KCk7XG4gICAgfVxufSkoKTtcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInB1cHBldGVlclwiKTsiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmNvbnN0IGZzID0gcmVxdWlyZShcImZzLWV4dHJhXCIpO1xuY29uc3QgcGF0aCA9IHJlcXVpcmUoXCJwYXRoXCIpO1xuY29uc3QgYXdhaXRfdG9fanNfMSA9IHJlcXVpcmUoXCJhd2FpdC10by1qc1wiKTtcbmNvbnN0IE5ldHdvcmtMaXN0ZW5lcl8xID0gcmVxdWlyZShcIi4vTmV0d29ya0xpc3RlbmVyXCIpO1xuY29uc3QgTWluYUhlYXJ0YmVhdF8xID0gcmVxdWlyZShcIi4vTWluYUhlYXJ0YmVhdFwiKTtcbmNvbnN0IEhpamFja18xID0gcmVxdWlyZShcIi4vYmFzZS9IaWphY2tcIik7XG5jb25zdCBQYWdlQmFzZV8xID0gcmVxdWlyZShcIi4vYmFzZS9QYWdlQmFzZVwiKTtcbmNvbnN0IHV0aWxzID0gcmVxdWlyZShcIi4uL3V0aWwvdXRpbHNcIik7XG5jb25zdCBkZXZpY2VzID0gcmVxdWlyZShcInB1cHBldGVlci9EZXZpY2VEZXNjcmlwdG9yc1wiKTtcbmNvbnN0IHJlcG9ydElkS2V5XzEgPSByZXF1aXJlKFwiLi4vdXRpbC9yZXBvcnRJZEtleVwiKTtcbmZ1bmN0aW9uIHNsZWVwKHRpbWUpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgdGltZSkpO1xufVxuY29uc3QgVElNRV9MSU1JVCA9IDE4ICogNjAgKiAxMDAwO1xuY29uc3QgaVBob25lWCA9IGRldmljZXNbJ2lQaG9uZSBYJ107XG5pUGhvbmVYLnZpZXdwb3J0LmRldmljZVNjYWxlRmFjdG9yID0gMTtcbmNsYXNzIEF1ZGl0c0F1dG8gZXh0ZW5kcyBQYWdlQmFzZV8xLmRlZmF1bHQge1xuICAgIGNvbnN0cnVjdG9yKHBhZ2UsIG9wdGlvbnMpIHtcbiAgICAgICAgc3VwZXIocGFnZSk7XG4gICAgICAgIHRoaXMuY2xpY2tDbnQgPSAwO1xuICAgICAgICB0aGlzLnd4Q29uZmlnID0ge307XG4gICAgICAgIHRoaXMudXJsUGF0aE1hcCA9IHt9O1xuICAgICAgICB0aGlzLmVsZW1lbnRDbGlja0NvdW50TWFwID0gbmV3IE1hcCgpO1xuICAgICAgICB0aGlzLmVsZW1lbnRUZXh0TWFwID0gbmV3IE1hcCgpO1xuICAgICAgICB0aGlzLmRyaXZlclN0YXJ0VGltZSA9IDA7XG4gICAgICAgIHRoaXMudGFza0ZpbmlzaGVkVGltZSA9IDA7XG4gICAgICAgIHRoaXMuanNDb3ZlcmFnZSA9ICcnO1xuICAgICAgICB0aGlzLmlzVGltZW91dCA9IGZhbHNlO1xuICAgICAgICB0aGlzLmlzQXBwRGVhZCA9IGZhbHNlO1xuICAgICAgICB0aGlzLmFwcGlkID0gb3B0aW9ucy5hcHBpZCB8fCAnJztcbiAgICAgICAgdGhpcy5hcHB1aW4gPSBvcHRpb25zLmFwcHVpbjtcbiAgICAgICAgdGhpcy50YXNraWQgPSBvcHRpb25zLnRhc2tpZDtcbiAgICAgICAgdGhpcy5wYWdlID0gcGFnZTtcbiAgICAgICAgdGhpcy5pbmRleFBhZ2VVcmwgPSBvcHRpb25zLnVybCB8fCAnJztcbiAgICAgICAgdGhpcy5yZXN1bHRQYXRoID0gb3B0aW9ucy5yZXN1bHRQYXRoO1xuICAgICAgICB0aGlzLnRhc2tTdGFydFRpbWUgPSBvcHRpb25zLnRhc2tTdGFydFRpbWU7XG4gICAgICAgIHRoaXMubG9uZ2l0dWRlID0gb3B0aW9ucy5sb25naXR1ZGUgfHwgMTEzLjI2NDU7XG4gICAgICAgIHRoaXMubGF0aXR1ZGUgPSBvcHRpb25zLmxhdGl0dWRlIHx8IDIzLjEyODg7XG4gICAgICAgIHRoaXMucmVkaXJlY3RUb1VybExpc3QgPSBvcHRpb25zLnJlZGlyZWN0dG9fdXJsIHx8IFtdO1xuICAgICAgICB0aGlzLmV4dEluZm8gPSBvcHRpb25zLmV4dEluZm8gfHwge307XG4gICAgICAgIHRoaXMuaGlqYWNrID0gbmV3IEhpamFja18xLmRlZmF1bHQocGFnZSk7XG4gICAgICAgIHRoaXMubmV0d29ya0xpc3RlbmVyID0gbmV3IE5ldHdvcmtMaXN0ZW5lcl8xLmRlZmF1bHQodGhpcy5wYWdlKTtcbiAgICAgICAgaWYgKHRoaXMuZXh0SW5mby5zaW5nbGVQYWdlTW9kZSAmJiB0aGlzLnJlZGlyZWN0VG9VcmxMaXN0Lmxlbmd0aCkge1xuICAgICAgICAgICAgdGhpcy5pbmRleFBhZ2VVcmwgPSB0aGlzLmluZGV4UGFnZVVybC5yZXBsYWNlKC8jLiokLywgJycpO1xuICAgICAgICAgICAgdGhpcy5pbmRleFBhZ2VVcmwgKz0gJyMhJyArIHRoaXMucmVkaXJlY3RUb1VybExpc3RbMF0ucmVwbGFjZSgvXlxcLy8sICcnKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmxvZy5pbmZvKGBlZWVlZXh0SW5mbyAke0pTT04uc3RyaW5naWZ5KHRoaXMuZXh0SW5mbyl9YCk7XG4gICAgICAgIHRoaXMudGFza1Jlc3VsdCA9IHsgcGFnZXM6IFtdLCBtbWRhdGE6IFtdIH07XG4gICAgICAgIHRoaXMuaW5pdCgpO1xuICAgIH1cbiAgICBpbml0KCkge1xuICAgICAgICB0aGlzLmluaXRQYWdlRXZlbnQoKTtcbiAgICAgICAgdGhpcy5pbml0TmV0d29ya0V2ZW50KCk7XG4gICAgICAgIHRoaXMuaW5pdEhlYXJ0YmVhdExpc3RlbigpO1xuICAgICAgICB0aGlzLnRpbWVvdXRQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5sb2cuaW5mbygnc3RhcnQgY291bnQgZG93bicpO1xuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcigndGltZW91dCcpKTtcbiAgICAgICAgICAgIH0sIFRJTUVfTElNSVQpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgaW5pdE5ldHdvcmtFdmVudCgpIHtcbiAgICAgICAgdGhpcy5uZXR3b3JrTGlzdGVuZXIub24oJ09OX1JFUVVFU1RfRVZFTlQnLCAobWVzc2FnZSkgPT4ge1xuICAgICAgICAgICAgdGhpcy5zZW5kTmV0d29ya0V2ZW50MkZyYW1lKHtcbiAgICAgICAgICAgICAgICBjb21tYW5kOiAnT05fUkVRVUVTVF9FVkVOVCcsXG4gICAgICAgICAgICAgICAgZGF0YTogbWVzc2FnZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBpbml0SGVhcnRiZWF0TGlzdGVuKCkge1xuICAgICAgICB0aGlzLmhlYXJ0YmVhdFByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBoZWFydGJlYXRMaXN0ZW5lciA9IG5ldyBNaW5hSGVhcnRiZWF0XzEuZGVmYXVsdCh7XG4gICAgICAgICAgICAgICAgcGFnZTogdGhpcy5wYWdlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGhlYXJ0YmVhdExpc3RlbmVyLm9uKCdOT19IRUFSVF9CRUFUJywgKCkgPT4ge1xuICAgICAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoJ05PX0hFQVJUX0JFQVQnKSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGFzeW5jIHNlbmROZXR3b3JrRXZlbnQyRnJhbWUobWVzc2FnZSkge1xuICAgICAgICBjb25zdCBbc2VuZE1lc3NhZ2VFcnJvcl0gPSBhd2FpdCBhd2FpdF90b19qc18xLmRlZmF1bHQodGhpcy5wYWdlLmV2YWx1YXRlKChhdWRpdHNGcmFtZSwgbWVzc2FnZSkgPT4ge1xuICAgICAgICAgICAgaWYgKGF1ZGl0c0ZyYW1lKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbXNnID0gSlNPTi5wYXJzZShtZXNzYWdlKTtcbiAgICAgICAgICAgICAgICBtc2cucHJvdG9jb2wgPSAnQVVESVRTX0ZSQU1FJztcbiAgICAgICAgICAgICAgICBhdWRpdHNGcmFtZS5jb250ZW50V2luZG93LnBvc3RNZXNzYWdlKG1zZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sIGF3YWl0IHRoaXMucGFnZS4kKCcjYXVkaXRzRnJhbWUnKSwgSlNPTi5zdHJpbmdpZnkobWVzc2FnZSkpKTtcbiAgICAgICAgaWYgKHNlbmRNZXNzYWdlRXJyb3IpIHtcbiAgICAgICAgICAgIHRoaXMubG9nLmVycm9yKCdzZW5kIG5ldHdvcmsgZXZlbnQgZXJyb3InLCBzZW5kTWVzc2FnZUVycm9yKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBhc3luYyBnb0luZGV4UGFnZVVybChpc1JlbG9hZCA9IGZhbHNlKSB7XG4gICAgICAgIHRoaXMubG9nLmluZm8oYGluZGV4UGFnZVVybDogJHt0aGlzLmluZGV4UGFnZVVybH1gKTtcbiAgICAgICAgbGV0IGdvdG9FcnJvciwgcGFnZVJlc3BvbnNlO1xuICAgICAgICBpZiAoaXNSZWxvYWQpIHtcbiAgICAgICAgICAgIHRoaXMubG9nLmluZm8oJ3JlbG9hZCBwYWdlJyk7XG4gICAgICAgICAgICBbZ290b0Vycm9yLCBwYWdlUmVzcG9uc2VdID0gYXdhaXQgYXdhaXRfdG9fanNfMS5kZWZhdWx0KHRoaXMucGFnZS5yZWxvYWQoeyB3YWl0VW50aWw6ICdkb21jb250ZW50bG9hZGVkJyB9KSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBbZ290b0Vycm9yLCBwYWdlUmVzcG9uc2VdID0gYXdhaXQgYXdhaXRfdG9fanNfMS5kZWZhdWx0KHRoaXMucGFnZS5nb3RvKHRoaXMuaW5kZXhQYWdlVXJsLCB7IHdhaXRVbnRpbDogJ2RvbWNvbnRlbnRsb2FkZWQnIH0pKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZ290b0Vycm9yKSB7XG4gICAgICAgICAgICB0aGlzLmxvZy5lcnJvcihgZ290b0Vycm9yICR7Z290b0Vycm9yLm1lc3NhZ2V9XFxuJHtnb3RvRXJyb3Iuc3RhY2t9LCByZXRyeWApO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChwYWdlUmVzcG9uc2UpIHtcbiAgICAgICAgICAgIGNvbnN0IGNoYWluID0gcGFnZVJlc3BvbnNlLnJlcXVlc3QoKS5yZWRpcmVjdENoYWluKCk7XG4gICAgICAgICAgICB0aGlzLmxvZy5pbmZvKGBwYWdlIHJlc3BvbnNlIHN0YXR1cyAke3BhZ2VSZXNwb25zZS5zdGF0dXMoKX1gKTtcbiAgICAgICAgICAgIHRoaXMubG9nLmluZm8oYHBhZ2VSZXNwb25zZSBpcyBva1ske3BhZ2VSZXNwb25zZS5vaygpfV0gY2hhaW4gbGVuZ3RoIFske2NoYWluLmxlbmd0aH1dICR7Y2hhaW4ubWFwKChyZXEpID0+IHJlcS51cmwoKSl9YCk7XG4gICAgICAgICAgICBpZiAoIXBhZ2VSZXNwb25zZS5vaygpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuZXJyb3IoYHBhZ2UgcmVzcG9uc2UgZXJyb3IsIHN0YXR1c0NvZGVbJHtwYWdlUmVzcG9uc2Uuc3RhdHVzKCl9XSwgZmFpbHVyZVske3BhZ2VSZXNwb25zZS5yZXF1ZXN0KCkuZmFpbHVyZSgpfV1gKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGFzeW5jIHN0YXJ0KHJldHJ5Q250ID0gMCkge1xuICAgICAgICBpZiAocmV0cnlDbnQgPiAyKSB7XG4gICAgICAgICAgICB0aGlzLmxvZy5lcnJvcignc3RhcnQgY3Jhd2wgZmFpbGVkLCByZXRyeSAzIHRpbWVzJyk7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5nZW5UYXNrUmVzdWx0KHt9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXJldHJ5Q250KSB7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLmluaXRQYWdlKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFhd2FpdCB0aGlzLmdvSW5kZXhQYWdlVXJsKHJldHJ5Q250ID4gMCkpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnN0YXJ0KHJldHJ5Q250ICsgMSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgW3dhaXRGb3JBcHBzZXJ2aWNlRXJyb3JdID0gYXdhaXQgYXdhaXRfdG9fanNfMS5kZWZhdWx0KHRoaXMucGFnZS53YWl0Rm9yKCgpID0+ICEhZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2FwcHNlcnZpY2UnKSkpO1xuICAgICAgICBpZiAod2FpdEZvckFwcHNlcnZpY2VFcnJvcikge1xuICAgICAgICAgICAgdGhpcy5sb2cuZXJyb3IoYHdhaXRGb3IgYXBwc2VydmljZSBlcnJvciAke3dhaXRGb3JBcHBzZXJ2aWNlRXJyb3IubWVzc2FnZX1cXG4ke3dhaXRGb3JBcHBzZXJ2aWNlRXJyb3Iuc3RhY2t9LCByZXRyeWApO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc3RhcnQocmV0cnlDbnQgKyAxKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmxvZy5kZWJ1ZygnYXBwc2VydmljZSByZWFkeScpO1xuICAgICAgICBhd2FpdCB0aGlzLmhpamFjay5oaWphY2tEZWZhdWx0KHtcbiAgICAgICAgICAgIGxvbmdpdHVkZTogdGhpcy5sb25naXR1ZGUsXG4gICAgICAgICAgICBsYXRpdHVkZTogdGhpcy5sYXRpdHVkZVxuICAgICAgICB9KTtcbiAgICAgICAgYXdhaXQgdGhpcy5oaWphY2suaGlqYWNrUGFnZUV2ZW50KCk7XG4gICAgICAgIC8vIOiyjOS8vOS4jeS4gOWumuebkeWQrOW+l+WIsO+8jOi2heaXtuS5n+WFgeiuuOe7p+e7rei3kVxuICAgICAgICBjb25zdCBbZG9tUmVhZHlUaW1lb3V0XSA9IGF3YWl0IGF3YWl0X3RvX2pzXzEuZGVmYXVsdCh0aGlzLmhpamFjay53YWl0Rm9yUGFnZUV2ZW50KFwiX19ET01SZWFkeVwiLCB7IHRpbWVvdXQ6IDEyMDAwIH0pKTtcbiAgICAgICAgaWYgKGRvbVJlYWR5VGltZW91dCkge1xuICAgICAgICAgICAgdGhpcy5sb2cuZXJyb3IoYHBhZ2UgZXZlbnQgW19fRE9NUmVhZHldIHRpbWVvdXQuIFRyeSB0byBjb250aW51ZS5gKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmxvZy5pbmZvKCdhZnRlciB3YWl0IGZvciBfX0RPTVJlYWR5Jyk7XG4gICAgICAgIGNvbnN0IFt3ZWJ2aWV3TWFuYWdlclRpbWVvdXRdID0gYXdhaXQgYXdhaXRfdG9fanNfMS5kZWZhdWx0KHRoaXMucGFnZS53YWl0Rm9yKCgpID0+IHdpbmRvdy5uYXRpdmUgJiYgd2luZG93Lm5hdGl2ZS53ZWJ2aWV3TWFuYWdlciAmJiB3aW5kb3cubmF0aXZlLndlYnZpZXdNYW5hZ2VyLmdldEN1cnJlbnQoKSAhPSBudWxsKSk7XG4gICAgICAgIGlmICh3ZWJ2aWV3TWFuYWdlclRpbWVvdXQpIHtcbiAgICAgICAgICAgIHRoaXMubG9nLmVycm9yKCd3YWl0IGZvciB3ZWJ2aWV3TWFuYWdlciByZWFkeSB0aW1lb3V0Jyk7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zdGFydChyZXRyeUNudCArIDEpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMud3hDb25maWcgPSBhd2FpdCB0aGlzLnBhZ2UuZXZhbHVhdGUoKCkgPT4gd2luZG93Ll9fd3hDb25maWcpO1xuICAgICAgICB0aGlzLmxvZy5pbmZvKCd3eENvbmZpZyByZWFkeScpO1xuICAgICAgICB0aGlzLmxvZy5pbmZvKCdjaGVja2luZyBpcyByZWRpcmVjdCcpO1xuICAgICAgICBjb25zdCBpc1BhZ2VSZWRpcmVjdGVkID0gYXdhaXQgdGhpcy5pc1BhZ2VSZWRpcmVjdGVkKHRoaXMuaW5kZXhQYWdlVXJsKTtcbiAgICAgICAgaWYgKGlzUGFnZVJlZGlyZWN0ZWQpIHtcbiAgICAgICAgICAgIC8vIHJlZGlyZWN0IG1lYW5zIHBhY2thZ2UgaXMgbm90IGV4aXN0XG4gICAgICAgICAgICB0aGlzLmxvZy5lcnJvcigncGFnZSByZWRpcmVjdGVkLCBwYWNrYWdlIGlzIG5vdCBleGlzdCcpO1xuICAgICAgICAgICAgcmVwb3J0SWRLZXlfMS5yZXBvcnRJZEtleShyZXBvcnRJZEtleV8xLklkS2V5LkZJUlNUX1BBR0VfUkVESVJFQ1QpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2VuVGFza1Jlc3VsdCh7fSk7XG4gICAgICAgIH1cbiAgICAgICAgLy8g6L+Z6YeM5YWIc2xlZXAgMXPvvIx3YWl0Rm9yQ3VycmVudEZyYW1lSWRsZeajgOafpeeahOaXtuWAmVxuICAgICAgICAvLyDlj6/og73pobXpnaLnmoTor7fmsYLpg73msqHlvIDlp4vlj5HotbfvvIzpgKDmiJBpZGxl55qE5YGH6LGhXG4gICAgICAgIGF3YWl0IHNsZWVwKDEwMDApO1xuICAgICAgICAvLyB0aGlzLmxvZy5kZWJ1Zygnd2FpdGluZyBmb3IgZnJhbWUgaWRsZScpXG4gICAgICAgIC8vIGNvbnN0IHdhaXRGcmFtZUluZm8gPSBhd2FpdCB0aGlzLndhaXRGb3JDdXJyZW50RnJhbWVJZGxlKCk7XG4gICAgICAgIC8vIGlmICh3YWl0RnJhbWVJbmZvLmhhc1dlYnZpZXcpIHtcbiAgICAgICAgLy8gICAvLyBoYXMgd2VidmlldyBtZWFucyBubyBvdGhlciBjb21wb25lbnRzIHNob3duXG4gICAgICAgIC8vICAgdGhpcy5sb2cuZXJyb3IoJ2hhcyB3ZWJ2aWV3IGF0IHRoZSBiZWdpbm5pbmcsIG5vdGhpbmcgdG8gZG8nKVxuICAgICAgICAvLyAgIHJlcG9ydElkS2V5KElkS2V5LklTX0FsbF9XRUJWSUVXKVxuICAgICAgICAvLyAgIHJldHVybiB0aGlzLmdlblRhc2tSZXN1bHQoe30pXG4gICAgICAgIC8vIH1cbiAgICAgICAgdGhpcy5sb2cuZGVidWcoJ2ZyYW1lIGlkbGUgdGltZScsIHRoaXMuZ2V0VGltZSgpKTtcbiAgICAgICAgaWYgKHRoaXMuZXh0SW5mby5zaW5nbGVQYWdlTW9kZSkge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5oaWphY2suaGlqYWNrTmF2aWdhdGlvbigpO1xuICAgICAgICAgICAgdGhpcy5sb2cuZGVidWcoJ2hpamFjayBwYWdlIG5hdmlnYXRpb24gZG9uZScpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBQcm9taXNlLmFsbChbXG4gICAgICAgICAgICB0aGlzLnRpbWVvdXRQcm9taXNlLFxuICAgICAgICAgICAgdGhpcy5oZWFydGJlYXRQcm9taXNlLFxuICAgICAgICAgICAgbmV3IFByb21pc2UoYXN5bmMgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuc3RhcnRPcGVyYXRlKCk7XG4gICAgICAgICAgICAgICAgLy8gYXdhaXQgc2xlZXAoNjAwMDAwMClcbiAgICAgICAgICAgICAgICByZWplY3QobmV3IEVycm9yKCdmaW5pc2hlZCcpKTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgIF0pLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcignZmluaXNoZWQnKSk7XG4gICAgICAgIH0pLmNhdGNoKGFzeW5jIChlcnJvcikgPT4ge1xuICAgICAgICAgICAgaWYgKGVycm9yLm1lc3NhZ2UgPT0gJ2ZpbmlzaGVkJykge1xuICAgICAgICAgICAgICAgIHRoaXMubG9nLmluZm8oJ2NyYXdsIGZpbmlzaGVkIGluIHRpbWUnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGVycm9yLm1lc3NhZ2UgPT0gJ05PX0hFQVJUX0JFQVQnKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5pc0FwcERlYWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHJlcG9ydElkS2V5XzEucmVwb3J0SWRLZXkocmVwb3J0SWRLZXlfMS5JZEtleS5BUFBfREVBRCk7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuZXJyb3IoJ2FwcCBpcyBkZWFkLCBjcmF3bCBmYWlsZWQnKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5nZW5UYXNrUmVzdWx0KHsgaXNBcHBEZWFkOiB0cnVlIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5pc1RpbWVvdXQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHRoaXMubG9nLmluZm8oJ2NyYXdsIHRpbWVvdXQsIHN0b3AgYXVkaXRzIHRvIGdldCByZXN1bHQnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IFtzdG9wQ292ZXJhZ2VFcnJvciwganNDb3ZlcmFnZV0gPSBhd2FpdCBhd2FpdF90b19qc18xLmRlZmF1bHQodXRpbHMudGltZW91dFdyYXAoYXN5bmMgKCkgPT4gYXdhaXQgdGhpcy5wYWdlLmNvdmVyYWdlLnN0b3BKU0NvdmVyYWdlKCkpKTtcbiAgICAgICAgICAgIGxldCBzZXJ2aWNlQ292ZXJhZ2UgPSBudWxsO1xuICAgICAgICAgICAgaWYgKHN0b3BDb3ZlcmFnZUVycm9yKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuZXJyb3IoJ3N0b3BKU0NvdmVyYWdlIGVycm9yJywgc3RvcENvdmVyYWdlRXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuaW5mbygnc3RvcEpTQ292ZXJhZ2Ugc3VjYycpO1xuICAgICAgICAgICAgICAgIHNlcnZpY2VDb3ZlcmFnZSA9IGpzQ292ZXJhZ2UuZmlsdGVyKChpdGVtKSA9PiAvYXBwXFwtc2VydmljZVxcLmpzLy50ZXN0KGl0ZW0udXJsKSlbMF07XG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuaW5mbygnZmlsdGVyIGpzQ292ZXJhZ2Ugc3VjYycpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHNlcnZpY2VDb3ZlcmFnZSAmJiBzZXJ2aWNlQ292ZXJhZ2UucmFuZ2VzKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5qc0NvdmVyYWdlID0gKDEwMCAqIHNlcnZpY2VDb3ZlcmFnZS5yYW5nZXMucmVkdWNlKCh0b3RhbCwgaXRlbSkgPT4gdG90YWwgKyBpdGVtLmVuZCAtIGl0ZW0uc3RhcnQsIDApIC8gc2VydmljZUNvdmVyYWdlLnRleHQubGVuZ3RoKS50b0ZpeGVkKDIpICsgJyUnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5qc0NvdmVyYWdlID0gJzAlJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGF1ZGl0c0ZyYW1lID0gdGhpcy5wYWdlLmZyYW1lcygpLmZpbmQoKGZyYW1lKSA9PiBmcmFtZS5uYW1lKCkgPT0gJ2F1ZGl0c0ZyYW1lJyk7XG4gICAgICAgICAgICB0aGlzLmxvZy5pbmZvKCdhdWRpdGVkIHBhZ2VzJywgT2JqZWN0LmtleXModGhpcy51cmxQYXRoTWFwKSk7XG4gICAgICAgICAgICB0aGlzLmxvZy5pbmZvKGBwYWdlIGNvdmVyYWdlOiAke09iamVjdC5rZXlzKHRoaXMudXJsUGF0aE1hcCkubGVuZ3RofS8ke3RoaXMud3hDb25maWcucGFnZXMubGVuZ3RofWApO1xuICAgICAgICAgICAgdGhpcy5sb2cuaW5mbyhganMgY292ZXJhZ2U6ICR7dGhpcy5qc0NvdmVyYWdlfWApO1xuICAgICAgICAgICAgaWYgKGF1ZGl0c0ZyYW1lKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuaW5mbygnaGFzIGF1ZGl0c0ZyYW1lJyk7XG4gICAgICAgICAgICAgICAgYXdhaXQgc2xlZXAoMjAwMCk7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuaW5mbygnc3RvcHBpbmcgYXVkaXRzJyk7XG4gICAgICAgICAgICAgICAgY29uc3QgW3N0b3BBdWRpdEVycm9yXSA9IGF3YWl0IGF3YWl0X3RvX2pzXzEuZGVmYXVsdCh1dGlscy50aW1lb3V0RXZhbHVhdGVGcmFtZShhdWRpdHNGcmFtZSwgNTAwMCwgKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cub25TdG9wQ2xpY2tlZCgpO1xuICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgICAgICBpZiAoc3RvcEF1ZGl0RXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2cuZXJyb3IoJ3N0b3AgYXVkaXQgZXJyb3InLCBzdG9wQXVkaXRFcnJvcik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IFt3YWl0Rm9yRXJyb3JdID0gYXdhaXQgYXdhaXRfdG9fanNfMS5kZWZhdWx0KHRoaXMucGFnZS53YWl0Rm9yRnVuY3Rpb24oKCkgPT4gISF3aW5kb3cuYXVkaXRzUmVzdWx0LCB7IHRpbWVvdXQ6IDEwMDAwIH0pKTtcbiAgICAgICAgICAgICAgICBpZiAod2FpdEZvckVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlcG9ydElkS2V5XzEucmVwb3J0SWRLZXkocmVwb3J0SWRLZXlfMS5JZEtleS5HRU5fUkVTVUxUX09VVF9PRl9USU1FKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2cuZXJyb3IoJ3dhaXRpbmcgYXVkaXRzIHJlc3VsdCBlcnJvcjogJywgd2FpdEZvckVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2VuVGFza1Jlc3VsdCh7fSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IFthdWRpdHNFcnJvciwgYXVkaXRzUmVzdWx0XSA9IGF3YWl0IGF3YWl0X3RvX2pzXzEuZGVmYXVsdCh0aGlzLnBhZ2UuZXZhbHVhdGUoKCkgPT4gd2luZG93LmF1ZGl0c1Jlc3VsdCkpO1xuICAgICAgICAgICAgICAgIGlmIChhdWRpdHNFcnJvcikge1xuICAgICAgICAgICAgICAgICAgICByZXBvcnRJZEtleV8xLnJlcG9ydElkS2V5KHJlcG9ydElkS2V5XzEuSWRLZXkuR0VOX1JFU1VMVF9FUlJPUik7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMubG9nLmVycm9yKCdnZXR0aW5nIGF1ZGl0cyByZXN1bHQgZXJyb3I6ICcsIGF1ZGl0c0Vycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2VuVGFza1Jlc3VsdCh7fSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLmdlblRhc2tSZXN1bHQoYXVkaXRzUmVzdWx0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMubG9nLmVycm9yKCdhdWRpdHNGcmFtZSBkZXRhY2hlZCwgbm8gYXVkaXRzIHJlc3VsdCcpO1xuICAgICAgICAgICAgICAgIHJlcG9ydElkS2V5XzEucmVwb3J0SWRLZXkocmVwb3J0SWRLZXlfMS5JZEtleS5BVURJVFNfRlJBTUVfREVUQUNIRUQpO1xuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmdlblRhc2tSZXN1bHQoe30pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgYXN5bmMgaW5pdFBhZ2UoKSB7XG4gICAgICAgIHRoaXMuZHJpdmVyU3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcbiAgICAgICAgYXdhaXQgdGhpcy5wYWdlLnNldENvb2tpZSh1dGlscy5nZXRDb29raWVJbmZvKHRoaXMuYXBwdWluLCB0aGlzLmluZGV4UGFnZVVybCkpOyAvLyDot7PovazliY3np43lhaV3eHVpbiBjb29raWXvvIznoa7kv53miYDmnInor7fmsYLpg73liLDkuIDlj7DmnLrlmahcbiAgICAgICAgYXdhaXQgdGhpcy5wYWdlLmVtdWxhdGUoaVBob25lWCk7XG4gICAgICAgIGF3YWl0IHRoaXMucGFnZS5jb3ZlcmFnZS5zdGFydEpTQ292ZXJhZ2UoKTtcbiAgICB9XG4gICAgYXN5bmMgc3RhcnRPcGVyYXRlKCkge1xuICAgICAgICBpZiAoIXRoaXMuZXh0SW5mby5zaW5nbGVQYWdlTW9kZVxuICAgICAgICAgICAgJiYgdGhpcy53eENvbmZpZy50YWJCYXJcbiAgICAgICAgICAgICYmIHRoaXMud3hDb25maWcudGFiQmFyLmxpc3RcbiAgICAgICAgICAgICYmIHRoaXMud3hDb25maWcudGFiQmFyLmxpc3QubGVuZ3RoKSB7XG4gICAgICAgICAgICBjb25zdCBsaXN0ID0gdGhpcy53eENvbmZpZy50YWJCYXIubGlzdDtcbiAgICAgICAgICAgIHRoaXMubG9nLmluZm8oJ3RhYmJhciBsaXN0JywgbGlzdC5tYXAoKGl0ZW0pID0+IGBbdGl0bGVdICR7aXRlbS50ZXh0fSBbcGF0aF0gJHtpdGVtLnBhZ2VQYXRofWApLmpvaW4oJ1xcbicpKTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBsZW4gPSBsaXN0Lmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuaW5mbyhgY3Jhd2xpbmcgcGFnZSAke2xpc3RbaV0ucGFnZVBhdGh9YCk7XG4gICAgICAgICAgICAgICAgY29uc3QgW3N3aXRjaFRhYkVycm9yXSA9IGF3YWl0IGF3YWl0X3RvX2pzXzEuZGVmYXVsdCh1dGlscy50aW1lb3V0RXZhbHVhdGVQYWdlKHRoaXMucGFnZSwgNTAwMCwgKHVybCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cubmF0aXZlLm5hdmlnYXRvci5zd2l0Y2hUYWIodXJsKTtcbiAgICAgICAgICAgICAgICB9LCBsaXN0W2ldLnBhZ2VQYXRoKSk7XG4gICAgICAgICAgICAgICAgaWYgKCFzd2l0Y2hUYWJFcnJvcikge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmxvZy5pbmZvKCdzd2l0Y2ggdGFiIHN1Y2MnKTtcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5jcmF3bEN1cnJlbnRXZWJ2aWV3KCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmxvZy5lcnJvcihgc3dpdGNoIHRhYiBlcnJvcjogJHtzd2l0Y2hUYWJFcnJvci5tZXNzYWdlfVxcbiR7c3dpdGNoVGFiRXJyb3Iuc3RhY2t9YCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5jcmF3bEN1cnJlbnRXZWJ2aWV3KCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgYXN5bmMgY3Jhd2xDdXJyZW50V2VidmlldygpIHtcbiAgICAgICAgY29uc3QgcGFnZSA9IHRoaXMucGFnZTtcbiAgICAgICAgY29uc3Qgd2Vidmlld05hdGl2ZUhhbmRsZSA9IGF3YWl0IHRoaXMucGFnZS5ldmFsdWF0ZUhhbmRsZSgoKSA9PiB3aW5kb3cubmF0aXZlLndlYnZpZXdNYW5hZ2VyLmdldEN1cnJlbnQoKSk7XG4gICAgICAgIGNvbnN0IHVybCA9IGF3YWl0IHBhZ2UuZXZhbHVhdGUod2VidmlldyA9PiB3ZWJ2aWV3LnVybCwgd2Vidmlld05hdGl2ZUhhbmRsZSk7XG4gICAgICAgIGNvbnN0IHVybFBhdGggPSB1cmwuc3BsaXQoJz8nKVswXTtcbiAgICAgICAgdGhpcy51cmxQYXRoTWFwW3VybFBhdGhdID0gdGhpcy51cmxQYXRoTWFwW3VybFBhdGhdIHx8IHtcbiAgICAgICAgICAgIGlzV2VidmlldzogZmFsc2UsXG4gICAgICAgICAgICBjbnQ6IDBcbiAgICAgICAgfTtcbiAgICAgICAgaWYgKHRoaXMudXJsUGF0aE1hcFt1cmxQYXRoXS5jbnQgPiAyKSB7XG4gICAgICAgICAgICB0aGlzLmxvZy5pbmZvKGAke3VybFBhdGh9IGhhcyBjcmF3bGVkIDMgdGltZXNgKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICAvLyDmtYtmbXDpnIDopoExMHNcbiAgICAgICAgaWYgKHRoaXMudXJsUGF0aE1hcFt1cmxQYXRoXS5jbnQgPT0gMCkge1xuICAgICAgICAgICAgdGhpcy5sb2cuaW5mbygnc2xlZXAgMTBzIGZvciBmbXAgdGVzdGluZycpO1xuICAgICAgICAgICAgYXdhaXQgc2xlZXAoMTAwMDApO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMudXJsUGF0aE1hcFt1cmxQYXRoXS5jbnQrKztcbiAgICAgICAgY29uc3QgeyBoYXNXZWJ2aWV3LCBmcmFtZSB9ID0gYXdhaXQgdGhpcy5pc0N1cnJlbnRGcmFtZVJlYWR5NENyYXdsKCk7XG4gICAgICAgIGlmICghZnJhbWUpIHtcbiAgICAgICAgICAgIHRoaXMubG9nLmVycm9yKCdjdXJyZW50IGZyYW1lIGNhbiBub3QgYmUgY3Jhd2xpbmcnKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBbZ2V0VGl0bGVFcnJvciwgdGl0bGVdID0gYXdhaXQgYXdhaXRfdG9fanNfMS5kZWZhdWx0KGZyYW1lLmV2YWx1YXRlKCgpID0+IGRvY3VtZW50LnRpdGxlKSk7XG4gICAgICAgIGlmIChnZXRUaXRsZUVycm9yKSB7XG4gICAgICAgICAgICB0aGlzLmxvZy5lcnJvcihgZ2V0VGl0bGVFcnJvcmAsIGdldFRpdGxlRXJyb3IpO1xuICAgICAgICAgICAgaWYgKGZyYW1lLmlzRGV0YWNoZWQoKSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzLmxvZy5pbmZvKCdwYWdlIHRpdGxlOiAnLCB0aXRsZSk7XG4gICAgICAgIGxldCBmaWxlbmFtZSA9IHV0aWxzLmdldEZpbGVOYW1lQnlVcmwodXJsKTtcbiAgICAgICAgdGhpcy5sb2cuaW5mbygncGFnZSBzYXZlIGZpbGVuYW1lOiAnLCBmaWxlbmFtZSk7XG4gICAgICAgIGNvbnN0IFtnZXRQYWdlU3RhY2tFcnJvciwgcGFnZVN0YWNrXSA9IGF3YWl0IGF3YWl0X3RvX2pzXzEuZGVmYXVsdCh0aGlzLnBhZ2UuZXZhbHVhdGUoKCkgPT4gd2luZG93Lm5hdGl2ZS53ZWJ2aWV3TWFuYWdlci5nZXRQYWdlU3RhY2soKS5tYXAoKHdlYnZpZXcpID0+IHdlYnZpZXcucGF0aCkpKTtcbiAgICAgICAgaWYgKGdldFBhZ2VTdGFja0Vycm9yKSB7XG4gICAgICAgICAgICB0aGlzLmxvZy5lcnJvcihgZ2V0UGFnZVN0YWNrRXJyb3JgLCBnZXRQYWdlU3RhY2tFcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5sb2cuaW5mbygncGFnZVN0YWNrJywgcGFnZVN0YWNrKTtcbiAgICAgICAgY29uc3QgW3NhdmVFcnJvcl0gPSBhd2FpdCBhd2FpdF90b19qc18xLmRlZmF1bHQoUHJvbWlzZS5hbGwoW1xuICAgICAgICAgICAgdGhpcy5zYXZlU2NyZWVuU2hvdChmaWxlbmFtZSksXG4gICAgICAgICAgICB0aGlzLnNhdmVGcmFtZUh0bWwoZnJhbWUsIGZpbGVuYW1lKVxuICAgICAgICBdKSk7XG4gICAgICAgIGlmIChzYXZlRXJyb3IpIHtcbiAgICAgICAgICAgIHRoaXMubG9nLmVycm9yKGBzYXZlIGVycm9yICR7c2F2ZUVycm9yLm1lc3NhZ2V9XFxuJHtzYXZlRXJyb3Iuc3RhY2t9YCk7XG4gICAgICAgICAgICBmaWxlbmFtZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWhhc1dlYnZpZXcpIHtcbiAgICAgICAgICAgIGF3YWl0IHRoaXMuY2xpY2tFbGVtZW50cyhmcmFtZSwgd2Vidmlld05hdGl2ZUhhbmRsZSwgdXJsUGF0aCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnVybFBhdGhNYXBbdXJsUGF0aF0uaXNXZWJ2aWV3ID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMubG9nLmVycm9yKCdoYXNXZWJ2aWV3ISEhISEhISEhJyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy50YXNrUmVzdWx0LnBhZ2VzLnB1c2goe1xuICAgICAgICAgICAgdGFza191cmw6IHRoaXMuaW5kZXhQYWdlVXJsLnNwbGl0KCcjIScpWzFdIHx8ICcnLFxuICAgICAgICAgICAgcGF0aDogdXJsUGF0aCxcbiAgICAgICAgICAgIGZ1bGxfcGF0aDogdXJsLFxuICAgICAgICAgICAgcGFnZXN0YWNrOiBwYWdlU3RhY2ssXG4gICAgICAgICAgICBwaWM6IGZpbGVuYW1lID8gYCR7ZmlsZW5hbWV9LmpwZ2AgOiAnJyxcbiAgICAgICAgICAgIGh0bWw6IGZpbGVuYW1lID8gYCR7ZmlsZW5hbWV9Lmh0bWxgIDogJycsXG4gICAgICAgICAgICB0aXRsZTogdGl0bGUgIT09IHVuZGVmaW5lZCA/IHRpdGxlIDogJ3VuZGVmaW5lZCcsXG4gICAgICAgICAgICBsZXZlbDogcGFnZVN0YWNrLmxlbmd0aCAtIDEsXG4gICAgICAgICAgICByZWFjaFR5cGU6IDAsXG4gICAgICAgICAgICBpc193ZWJ2aWV3OiBoYXNXZWJ2aWV3ID8gMSA6IDBcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMubG9nLmluZm8oYGNyYXdsIHVybCAke3VybH0gZG9uZWApO1xuICAgIH1cbiAgICBhc3luYyBpc0N1cnJlbnRGcmFtZVJlYWR5NENyYXdsKCkge1xuICAgICAgICBjb25zdCB7IGhhc1dlYnZpZXcsIGZyYW1lLCBpZCB9ID0gYXdhaXQgdGhpcy53YWl0Rm9yQ3VycmVudEZyYW1lSWRsZSgpO1xuICAgICAgICBpZiAoIWZyYW1lKSB7XG4gICAgICAgICAgICByZXR1cm4geyBoYXNXZWJ2aWV3IH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGhhc1dlYnZpZXcpIHtcbiAgICAgICAgICAgIHJldHVybiB7IGhhc1dlYnZpZXcsIGZyYW1lIH07XG4gICAgICAgIH1cbiAgICAgICAgLy8g6L+Z6YeM5YWIc2xlZXAgMXPvvIx3YWl0Rm9yQ3VycmVudEZyYW1lSWRsZeajgOafpeeahOaXtuWAmVxuICAgICAgICAvLyDlj6/og73pobXpnaLnmoTlvojlpJror7fmsYLpg73msqHlvIDlp4vlj5HotbfvvIzpgKDmiJBpZGxl55qE5YGH6LGhXG4gICAgICAgIGF3YWl0IHNsZWVwKDEwMDApO1xuICAgICAgICB0aGlzLmxvZy5pbmZvKGB3YWl0aW5nIGZvciBmcmFtZVske2ZyYW1lLm5hbWUoKX1dIHdlYnZpZXcgcmVhZHlgKTtcbiAgICAgICAgY29uc3Qgc3RhcnRUb1dhaXQgPSBEYXRlLm5vdygpO1xuICAgICAgICBhd2FpdCBhd2FpdF90b19qc18xLmRlZmF1bHQoZnJhbWUud2FpdEZvckZ1bmN0aW9uKCgpID0+ICEhd2luZG93LndlYnZpZXcsIHtcbiAgICAgICAgICAgIHRpbWVvdXQ6IDEwMDAwXG4gICAgICAgIH0sIGlkKSk7XG4gICAgICAgIHRoaXMubG9nLmluZm8oJ3dlYnZpZXcgb2JqZWN0IHJlYWR5Jyk7XG4gICAgICAgIGlmIChmcmFtZS5pc0RldGFjaGVkKCkpIHtcbiAgICAgICAgICAgIHRoaXMubG9nLmluZm8oYG9oIGZyYW1lWyR7ZnJhbWUubmFtZSgpfV0gZGV0YWNoZWRgKTtcbiAgICAgICAgICAgIHJldHVybiB7fTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmxvZy5pbmZvKGBmcmFtZVske2ZyYW1lLm5hbWUoKX1dIHdlYnZpZXcgcmVhZHksIHRpbWU6ICR7RGF0ZS5ub3coKSAtIHN0YXJ0VG9XYWl0fW1zYCk7XG4gICAgICAgIHJldHVybiB7IGhhc1dlYnZpZXcsIGZyYW1lIH07XG4gICAgfVxuICAgIGFzeW5jIGNsaWNrRWxlbWVudHMoZnJhbWUsIHdlYnZpZXdOYXRpdmVIYW5kbGUsIHBhZ2VQYXRoKSB7XG4gICAgICAgIGNvbnN0IG1hdGNoUmVzdWx0ID0gL3dlYnZpZXctKFxcZCspLy5leGVjKGZyYW1lLm5hbWUoKSk7XG4gICAgICAgIGlmICghbWF0Y2hSZXN1bHQpIHtcbiAgICAgICAgICAgIHRoaXMubG9nLmVycm9yKGBmcmFtZVske2ZyYW1lLm5hbWUoKX1dIGlzIG5vdCB3ZWJ2ZWl3YCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgaWQgPSArbWF0Y2hSZXN1bHRbMV07XG4gICAgICAgIGNvbnN0IFtnZXRXZWJ2aWV3RXJyb3IsIHdlYnZpZXdCcm93c2VySGFuZGxlXSA9IGF3YWl0IGF3YWl0X3RvX2pzXzEuZGVmYXVsdChmcmFtZS5ldmFsdWF0ZUhhbmRsZSgoKSA9PiB3aW5kb3cud2VidmlldykpO1xuICAgICAgICBpZiAoZ2V0V2Vidmlld0Vycm9yIHx8ICF3ZWJ2aWV3QnJvd3NlckhhbmRsZSkge1xuICAgICAgICAgICAgdGhpcy5sb2cuZXJyb3IoJ2dldFdlYnZpZXdFcnJvcicsIGdldFdlYnZpZXdFcnJvcik7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgbGV0IFtnZXRDbGlja2FibGVFbGVtZW50c0Vycm9yLCBlbGVtZW50c0hhbmRsZV0gPSBhd2FpdCBhd2FpdF90b19qc18xLmRlZmF1bHQodGhpcy5nZXRDbGlja2FibGVFbGVtZW50cyhmcmFtZSwgd2Vidmlld0Jyb3dzZXJIYW5kbGUpKTtcbiAgICAgICAgaWYgKGdldENsaWNrYWJsZUVsZW1lbnRzRXJyb3IpIHtcbiAgICAgICAgICAgIHJlcG9ydElkS2V5XzEucmVwb3J0SWRLZXkocmVwb3J0SWRLZXlfMS5JZEtleS5HRVRfQ0xJQ0tBQkxFX0VMRU1FTlRfRVJST1IpO1xuICAgICAgICAgICAgdGhpcy5sb2cuZXJyb3IoJ2dldENsaWNrYWJsZUVsZW1lbnRzRXJyb3InLCBnZXRDbGlja2FibGVFbGVtZW50c0Vycm9yKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWVsZW1lbnRzSGFuZGxlIHx8IGVsZW1lbnRzSGFuZGxlLmxlbmd0aCA9PSAwKSB7XG4gICAgICAgICAgICByZXBvcnRJZEtleV8xLnJlcG9ydElkS2V5KHJlcG9ydElkS2V5XzEuSWRLZXkuRk9VTkRfTk9fQ0xJQ0tBQkxFX0VMRU1FTlRTKTtcbiAgICAgICAgICAgIHRoaXMubG9nLmVycm9yKGBmcmFtZVske2ZyYW1lLm5hbWUoKX1dIG5vIGVsZW1lbnRzSGFuZGxlIGZvdW5kYCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIGxlbiA9IGVsZW1lbnRzSGFuZGxlLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCB7IGhhbmRsZSwga2V5IH0gPSBlbGVtZW50c0hhbmRsZVtpXTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgLy8g6L+H5ruk6YeN5aSN54K55Ye7XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMuZWxlbWVudFRleHRNYXAuZ2V0KGtleS50ZXh0S2V5KSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmxvZy5pbmZvKGB0ZXh0S2V5WyR7a2V5LnRleHRLZXl9XSBoYXMgYmVlbiBjbGlja2ApO1xuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8g6L+H5ruk5YiX6KGo6aG55aSq5aSa5pe255qE54K55Ye7XG4gICAgICAgICAgICAgICAgbGV0IGtleUNsaWNrQ250ID0gdGhpcy5lbGVtZW50Q2xpY2tDb3VudE1hcC5nZXQoa2V5LnRhZ0NsYXNzS2V5KSB8fCAwO1xuICAgICAgICAgICAgICAgIGlmIChrZXlDbGlja0NudCA+IDMpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2cuaW5mbyhgY2xpY2sga2V5WyR7a2V5LnRhZ0NsYXNzS2V5fV1bJHtrZXlDbGlja0NudH0gdGltZXNdIG91dCBvZiBjbGljayBsaW1pdGApO1xuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgaXNDbGlja2FibGUgPSBhd2FpdCB0aGlzLmVsZW1lbnRDbGlja2FibGUoZnJhbWUsIGhhbmRsZSk7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuaW5mbyhgaXMgZWxlbWVudFske2tleS50YWdDbGFzc0tleX1dIGNsaWNrYWJsZSAke2lzQ2xpY2thYmxlfWApO1xuICAgICAgICAgICAgICAgIGlmICghaXNDbGlja2FibGUpXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIGtleUNsaWNrQ250Kys7XG4gICAgICAgICAgICAgICAgdGhpcy5lbGVtZW50VGV4dE1hcC5zZXQoa2V5LnRleHRLZXksIHRydWUpO1xuICAgICAgICAgICAgICAgIHRoaXMuZWxlbWVudENsaWNrQ291bnRNYXAuc2V0KGtleS50YWdDbGFzc0tleSwga2V5Q2xpY2tDbnQpO1xuICAgICAgICAgICAgICAgIHRoaXMuY2xpY2tDbnQrKztcbiAgICAgICAgICAgICAgICAvLyBjb25zdCBmdWNvc0JvcmRlckhhbmRsZSA9IGF3YWl0IHRoaXMuYWRkUmVkQm9yZGVyNEhhbmRsZShmcmFtZSwgaGFuZGxlKVxuICAgICAgICAgICAgICAgIC8vIGF3YWl0IHRoaXMuc2F2ZVNjcmVlblNob3QoKVxuICAgICAgICAgICAgICAgIC8vIGF3YWl0IGZyYW1lLmV2YWx1YXRlKChyZWRCb3JkZXJIYW5kbGUpID0+IHtcbiAgICAgICAgICAgICAgICAvLyAgIHJlZEJvcmRlckhhbmRsZS5yZW1vdmUoKVxuICAgICAgICAgICAgICAgIC8vIH0sIGZ1Y29zQm9yZGVySGFuZGxlKVxuICAgICAgICAgICAgICAgIC8vIGF3YWl0IHRoaXMuc2NyZWVuc2hvdEJlZm9yZUNsaWNrKGZyYW1lLCBoYW5kbGUpXG4gICAgICAgICAgICAgICAgYXdhaXQgaGFuZGxlLnRhcCgpO1xuICAgICAgICAgICAgICAgIGF3YWl0IHNsZWVwKDEwMDApO1xuICAgICAgICAgICAgICAgIHRoaXMubG9nLmluZm8oYGNsaWNrZWQga2V5WyR7a2V5LnRhZ0NsYXNzS2V5fV1bJHtrZXlDbGlja0NudH0gdGltZXNdWyR7a2V5LnRleHRLZXkuc3Vic3RyKDAsIDMwKX1dICR7a2V5LnRhZ0NsYXNzS2V5fSBhdCBwYWdlICR7cGFnZVBhdGh9YCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIHJlcG9ydElkS2V5XzEucmVwb3J0SWRLZXkocmVwb3J0SWRLZXlfMS5JZEtleS5DTElDS19FTEVNRU5UX0VSUk9SKTtcbiAgICAgICAgICAgICAgICB0aGlzLmxvZy5lcnJvcihwYWdlUGF0aCwgJ3wnLCBlLm1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYXdhaXQgYXdhaXRfdG9fanNfMS5kZWZhdWx0KHRoaXMud2FpdEZvckZyYW1lQ2hhbmdlKGlkLCB7IHRpbWVvdXQ6IDEwMDAgfSkpO1xuICAgICAgICAgICAgbGV0IGlzRnJhbWVEZXRhY2hlZCA9IGZyYW1lLmlzRGV0YWNoZWQoKTtcbiAgICAgICAgICAgIGxldCBpc1dlYnZpZXdDaGFuZ2VkID0gZmFsc2U7XG4gICAgICAgICAgICBsZXQgZGV0ZWN0Q2hhbmdlRXJyb3I7XG4gICAgICAgICAgICBpZiAoaXNGcmFtZURldGFjaGVkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuaW5mbyhgZnJhbWVbJHtmcmFtZS5uYW1lKCl9XSBpcyBkZXRhY2hlZGApO1xuICAgICAgICAgICAgICAgIGlzV2Vidmlld0NoYW5nZWQgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgW2RldGVjdENoYW5nZUVycm9yLCBpc1dlYnZpZXdDaGFuZ2VkXSA9IGF3YWl0IGF3YWl0X3RvX2pzXzEuZGVmYXVsdCh0aGlzLmlzQ3VycmVudFdlYnZpZXdDaGFuZ2VkKHdlYnZpZXdOYXRpdmVIYW5kbGUpKTtcbiAgICAgICAgICAgICAgICBpZiAoZGV0ZWN0Q2hhbmdlRXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgaXNXZWJ2aWV3Q2hhbmdlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlzV2Vidmlld0NoYW5nZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmxvZy5pbmZvKGBmcmFtZVske2ZyYW1lLm5hbWUoKX1dIHdlYnZpZXcgY2hhbmdlZGApO1xuICAgICAgICAgICAgICAgIGlmIChpc0ZyYW1lRGV0YWNoZWQgfHwgZGV0ZWN0Q2hhbmdlRXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2cuaW5mbyhgZnJhbWVbJHtmcmFtZS5uYW1lKCl9XSBpcyBkZXRhY2hlZFske2lzRnJhbWVEZXRhY2hlZH1dIG9yIGRlc3Ryb3lbJHtkZXRlY3RDaGFuZ2VFcnJvcn1dYCk7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuY3Jhd2xDdXJyZW50V2VidmlldygpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5jcmF3bEN1cnJlbnRXZWJ2aWV3KCk7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuaW5mbygnbmF2aWdhdGluZyBiYWNrJyk7XG4gICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5wYWdlLmV2YWx1YXRlKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgd2luZG93Lm5hdGl2ZS5uYXZpZ2F0b3IubmF2aWdhdGVCYWNrKCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuaW5mbygnbmF2aWdhdGluZyBiYWNrIHN1Y2MnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMubG9nLmluZm8oYGZyYW1lWyR7ZnJhbWUubmFtZSgpfV0gbm90IGNoYW5nZWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYXdhaXQgc2xlZXAoMTAwMCk7XG4gICAgICAgICAgICBpZiAoZnJhbWUuaXNEZXRhY2hlZCgpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5sb2cuaW5mbyhgZnJhbWVbJHtmcmFtZS5uYW1lKCl9XSBpcyBkZXRhY2hlZGRkZGApO1xuICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMuY3Jhd2xDdXJyZW50V2VidmlldygpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5sb2cuaW5mbyhgd2FpdGluZyBmb3IgZnJhbWVbJHtmcmFtZS5uYW1lKCl9XSBpZGxlYCk7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLndhaXRGb3JDdXJyZW50RnJhbWVJZGxlKCk7XG4gICAgICAgICAgICB0aGlzLmxvZy5pbmZvKGBmcmFtZVske2ZyYW1lLm5hbWUoKX1dIGlzIGlkbGVgKTtcbiAgICAgICAgICAgIGNvbnN0IG5ld0VsZW1lbnRzSGFuZGxlID0gYXdhaXQgdGhpcy5nZXRDbGlja2FibGVFbGVtZW50cyhmcmFtZSwgd2Vidmlld0Jyb3dzZXJIYW5kbGUpO1xuICAgICAgICAgICAgdGhpcy5sb2cuaW5mbyhwYWdlUGF0aCwgJ2dldCBuZXcgZWxlbWVudHMnLCBlbGVtZW50c0hhbmRsZS5sZW5ndGgpO1xuICAgICAgICAgICAgZWxlbWVudHNIYW5kbGUgPSBuZXdFbGVtZW50c0hhbmRsZTtcbiAgICAgICAgICAgIGxlbiA9IGVsZW1lbnRzSGFuZGxlLmxlbmd0aDtcbiAgICAgICAgICAgIGkgPSAwO1xuICAgICAgICB9XG4gICAgfVxuICAgIGFzeW5jIGdldENsaWNrYWJsZUVsZW1lbnRzKGZyYW1lLCB3ZWJ2aWV3QnJvd3NlckhhbmRsZSkge1xuICAgICAgICB0aGlzLmxvZy5kZWJ1ZygnZmluZGluZyBjbGlja2FibGUgZWxlbWVudHMnKTtcbiAgICAgICAgY29uc3QgW2V2YWx1YXRlRXJyb3IsIGNsaWNrYWJsZUNvdW50XSA9IGF3YWl0IGF3YWl0X3RvX2pzXzEuZGVmYXVsdChmcmFtZS5ldmFsdWF0ZSgod2VidmlldywgaXNTaW5nbGVQYWdlTW9kZSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgZWxlbWVudHMgPSB3ZWJ2aWV3LmdldEVsZW1lbnRzKHsgY2xpY2thYmxlOiB0cnVlIH0pO1xuICAgICAgICAgICAgY29uc3QgbmF2aWdhdG9ycyA9IGlzU2luZ2xlUGFnZU1vZGUgPyBbXSA6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ3d4LW5hdmlnYXRvcicpO1xuICAgICAgICAgICAgY29uc3QgZWxlbWVudEtleU1hcCA9IHt9O1xuICAgICAgICAgICAgZWxlbWVudHMuZm9yRWFjaChlbGVtZW50ID0+IHtcbiAgICAgICAgICAgICAgICAvLyDov4fmu6Tlub/lkYpcbiAgICAgICAgICAgICAgICBpZiAoIWVsZW1lbnQuY2xvc2VzdCgnd3gtYWQnKSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBlbGVtZW50S2V5ID0gW2VsZW1lbnQudGFnTmFtZSwgZWxlbWVudC5jbGFzc05hbWUuc3BsaXQoL1xccysvKS5qb2luKCdfJyldLmpvaW4oJ19fJyk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChlbGVtZW50S2V5TWFwW2VsZW1lbnRLZXldICYmIGVsZW1lbnRLZXlNYXBbZWxlbWVudEtleV0gPiAyKVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICBlbGVtZW50S2V5TWFwW2VsZW1lbnRLZXldID0gZWxlbWVudEtleU1hcFtlbGVtZW50S2V5XSB8fCAwO1xuICAgICAgICAgICAgICAgICAgICBlbGVtZW50S2V5TWFwW2VsZW1lbnRLZXldKys7XG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKCdjcmF3bGVyLWNsaWNrLWVsJywgJ3RydWUnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIEFycmF5LnByb3RvdHlwZS5mb3JFYWNoLmNhbGwobmF2aWdhdG9ycywgKGVsZW1lbnQpID0+IHtcbiAgICAgICAgICAgICAgICBlbGVtZW50LnNldEF0dHJpYnV0ZSgnY3Jhd2xlci1jbGljay1lbCcsICd0cnVlJyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdbY3Jhd2xlci1jbGljay1lbF0nKS5sZW5ndGg7XG4gICAgICAgIH0sIHdlYnZpZXdCcm93c2VySGFuZGxlKSwgdGhpcy5leHRJbmZvLnNpbmdsZVBhZ2VNb2RlKTtcbiAgICAgICAgaWYgKGV2YWx1YXRlRXJyb3IpIHtcbiAgICAgICAgICAgIHRoaXMubG9nLmVycm9yKCdnZXRDbGlja2FibGVFbGVtZW50cyBlcnJvcicsIGV2YWx1YXRlRXJyb3IpO1xuICAgICAgICAgICAgcmV0dXJuIFtdO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMubG9nLmRlYnVnKCdnZXQgY2xpY2thYmxlIGVsZW1lbnRzLCBsZW5ndGgnLCBjbGlja2FibGVDb3VudCk7XG4gICAgICAgIGNvbnN0IGVsZW1lbnRzSGFuZGxlID0gKGF3YWl0IGZyYW1lLiQkKCdbY3Jhd2xlci1jbGljay1lbD1cInRydWVcIl0nKSkuc2xpY2UoMCwgMjAwKTtcbiAgICAgICAgbGV0IGVsZW1lbnRzID0gW107XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBsZW4gPSBlbGVtZW50c0hhbmRsZS5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgICAgICAgY29uc3QgZWxlbWVudEhhbmRsZSA9IGVsZW1lbnRzSGFuZGxlW2ldO1xuICAgICAgICAgICAgY29uc3QgYm91bmRpbmdCb3ggPSAoYXdhaXQgZWxlbWVudEhhbmRsZS5ib3VuZGluZ0JveCgpKSB8fCB7XG4gICAgICAgICAgICAgICAgeDogMCxcbiAgICAgICAgICAgICAgICB5OiAwLFxuICAgICAgICAgICAgICAgIHdpZHRoOiAwLFxuICAgICAgICAgICAgICAgIGhlaWdodDogMCxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBlbGVtZW50c1tpXSA9IHtcbiAgICAgICAgICAgICAgICBoYW5kbGU6IGVsZW1lbnRIYW5kbGUsXG4gICAgICAgICAgICAgICAga2V5OiBhd2FpdCB0aGlzLmdldEVsZW1lbnRLZXkoZWxlbWVudEhhbmRsZSwgZnJhbWUpLFxuICAgICAgICAgICAgICAgIGxlZnQ6IGJvdW5kaW5nQm94LngsXG4gICAgICAgICAgICAgICAgdG9wOiBib3VuZGluZ0JveC55LFxuICAgICAgICAgICAgICAgIHdpZHRoOiBib3VuZGluZ0JveC53aWR0aCxcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IGJvdW5kaW5nQm94LmhlaWdodCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgZWxlbWVudHMgPSBlbGVtZW50cy5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0ud2lkdGggKiBpdGVtLmhlaWdodCkuc2xpY2UoMCwgMTAwKTtcbiAgICAgICAgZWxlbWVudHMuc29ydCgoYSwgYikgPT4ge1xuICAgICAgICAgICAgaWYgKGEudG9wICE9IGIudG9wKVxuICAgICAgICAgICAgICAgIHJldHVybiBhLnRvcCAtIGIudG9wO1xuICAgICAgICAgICAgaWYgKGEubGVmdCAhPSBiLmxlZnQpXG4gICAgICAgICAgICAgICAgcmV0dXJuIGEubGVmdCAtIGIubGVmdDtcbiAgICAgICAgICAgIGlmIChhLndpZHRoICogYS5oZWlnaHQgIT0gYi53aWR0aCAqIGIuaGVpZ2h0KVxuICAgICAgICAgICAgICAgIHJldHVybiBiLndpZHRoICogYi5oZWlnaHQgLSBhLndpZHRoICogYS5oZWlnaHQ7XG4gICAgICAgICAgICBpZiAoYS5rZXkudGV4dEtleSA+IGIua2V5LnRleHRLZXkpXG4gICAgICAgICAgICAgICAgcmV0dXJuIC0xO1xuICAgICAgICAgICAgaWYgKGEua2V5LnRleHRLZXkgPCBiLmtleS50ZXh0S2V5KVxuICAgICAgICAgICAgICAgIHJldHVybiAxO1xuICAgICAgICAgICAgcmV0dXJuIDA7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmxvZy5kZWJ1ZygnZ2V0IGNsaWNrYWJsZSBlbGVtZW50cyBzb3J0IGZpbmlzaGVkJyk7XG4gICAgICAgIGlmIChlbGVtZW50cy5sZW5ndGggPT0gMCkge1xuICAgICAgICAgICAgcmVwb3J0SWRLZXlfMS5yZXBvcnRJZEtleShyZXBvcnRJZEtleV8xLklkS2V5LkZPVU5EX05PX0NMSUNLQUJMRV9FTEVNRU5UUyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGVsZW1lbnRzO1xuICAgIH1cbiAgICBhc3luYyBlbGVtZW50Q2xpY2thYmxlKGZyYW1lLCBlbGVtZW50SGFuZGxlcikge1xuICAgICAgICBjb25zdCBbY2hlY2tFbGVtZW50Q2xpY2tBYmxlRXJyb3IsIGlzQ2xpY2thYmxlXSA9IGF3YWl0IGF3YWl0X3RvX2pzXzEuZGVmYXVsdChmcmFtZS5ldmFsdWF0ZSgoZWwpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHsgdG9wLCBoZWlnaHQgfSA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICAgICAgY29uc3QgZGVsdGFZID0gdG9wIC0gKHdpbmRvdy5pbm5lckhlaWdodCA+PiAxKSArIChoZWlnaHQgPj4gMSk7XG4gICAgICAgICAgICB3aW5kb3cuc2Nyb2xsVG8oMCwgd2luZG93LnNjcm9sbFkgKyBkZWx0YVkpO1xuICAgICAgICAgICAgY29uc3QgbmV3UmVjdCA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICAgICAgY29uc3QgW3gsIHldID0gW25ld1JlY3QubGVmdCArIChuZXdSZWN0LndpZHRoID4+IDEpLCBuZXdSZWN0LnRvcCArIChuZXdSZWN0LmhlaWdodCA+PiAxKV07XG4gICAgICAgICAgICBjb25zdCBlbGVtZW50QXRQb2ludCA9IGRvY3VtZW50LmVsZW1lbnRGcm9tUG9pbnQoeCwgeSk7XG4gICAgICAgICAgICBjb25zdCBpc1BhcmVudCA9IGZ1bmN0aW9uIChhLCBiKSB7XG4gICAgICAgICAgICAgICAgd2hpbGUgKGEgIT0gZG9jdW1lbnQuYm9keSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoYSA9PSBiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChhICYmIGEucGFyZW50RWxlbWVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYSA9IGEucGFyZW50RWxlbWVudDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICByZXR1cm4gaXNQYXJlbnQoZWxlbWVudEF0UG9pbnQsIGVsKSB8fCBpc1BhcmVudChlbCwgZWxlbWVudEF0UG9pbnQpO1xuICAgICAgICB9LCBlbGVtZW50SGFuZGxlcikpO1xuICAgICAgICBpZiAoY2hlY2tFbGVtZW50Q2xpY2tBYmxlRXJyb3IpIHtcbiAgICAgICAgICAgIHRoaXMubG9nLmVycm9yKGBjaGVja0VsZW1lbnRDbGlja0FibGVFcnJvcmAsIGNoZWNrRWxlbWVudENsaWNrQWJsZUVycm9yKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gISFpc0NsaWNrYWJsZTtcbiAgICB9XG4gICAgYXN5bmMgaXNDdXJyZW50V2Vidmlld0NoYW5nZWQod2Vidmlld05hdGl2ZUhhbmRsZSkge1xuICAgICAgICBjb25zdCBbY2hlY2tXZWJ2aWV3Q2hhbmdlZEVycm9yLCBpc1dlYnZpZXdDaGFuZ2VdID0gYXdhaXQgYXdhaXRfdG9fanNfMS5kZWZhdWx0KHRoaXMucGFnZS5ldmFsdWF0ZSh3ZWJ2aWV3ID0+IHtcbiAgICAgICAgICAgIHJldHVybiB3ZWJ2aWV3ICE9PSB3aW5kb3cubmF0aXZlLndlYnZpZXdNYW5hZ2VyLmdldEN1cnJlbnQoKTtcbiAgICAgICAgfSwgd2Vidmlld05hdGl2ZUhhbmRsZSkpO1xuICAgICAgICBpZiAoY2hlY2tXZWJ2aWV3Q2hhbmdlZEVycm9yKSB7XG4gICAgICAgICAgICB0aGlzLmxvZy5lcnJvcihgY2hlY2tXZWJ2aWV3Q2hhbmdlZEVycm9yYCwgY2hlY2tXZWJ2aWV3Q2hhbmdlZEVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaXNXZWJ2aWV3Q2hhbmdlO1xuICAgIH1cbiAgICBhc3luYyBnZXRFbGVtZW50S2V5KGVsZW1lbnQsIGZyYW1lKSB7XG4gICAgICAgIGNvbnN0IFtnZXRFbGVtZW50S2V5RXJyb3IsIGVsZW1lbnRLZXldID0gYXdhaXQgYXdhaXRfdG9fanNfMS5kZWZhdWx0KGZyYW1lLmV2YWx1YXRlKGVsID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNsaWVudFJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgdGV4dEtleTogYCR7TWF0aC5yb3VuZChjbGllbnRSZWN0LndpZHRoKX0tJHtNYXRoLnJvdW5kKGNsaWVudFJlY3QuaGVpZ2h0KX0tJHtlbC50ZXh0Q29udGVudH1gLnJlcGxhY2UoL1xcbi9nLCAnXFxcXG4nKS5yZXBsYWNlKC9cXHMrL2csICcgJykuc3Vic3RyKDAsIDEwMCksXG4gICAgICAgICAgICAgICAgdGFnQ2xhc3NLZXk6IFtlbC50YWdOYW1lLCBlbC5jbGFzc05hbWUuc3BsaXQoL1xccysvKS5qb2luKCdfJyldLmpvaW4oJ19fJylcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0sIGVsZW1lbnQpKTtcbiAgICAgICAgaWYgKGdldEVsZW1lbnRLZXlFcnJvcikge1xuICAgICAgICAgICAgdGhpcy5sb2cuZXJyb3IoYGdldEVsZW1lbnRLZXlFcnJvcmAsIGdldEVsZW1lbnRLZXlFcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGVsZW1lbnRLZXk7XG4gICAgfVxuICAgIGFzeW5jIHNhdmVTY3JlZW5TaG90KGZpbGVuYW1lKSB7XG4gICAgICAgIGNvbnN0IHNjcmVlblNob3RQYXRoID0gcGF0aC5yZXNvbHZlKHRoaXMucmVzdWx0UGF0aCwgYC4vc2NyZWVuc2hvdC8ke2ZpbGVuYW1lfS5qcGdgKTtcbiAgICAgICAgYXdhaXQgdGhpcy5wYWdlLnNjcmVlbnNob3QoeyBwYXRoOiBzY3JlZW5TaG90UGF0aCwgdHlwZTogJ2pwZWcnLCBxdWFsaXR5OiA5MCB9KTtcbiAgICB9XG4gICAgYXN5bmMgc2F2ZUZyYW1lSHRtbChmcmFtZSwgZmlsZW5hbWUpIHtcbiAgICAgICAgY29uc3QgcGFnZUh0bWwgPSBhd2FpdCBmcmFtZS5jb250ZW50KCk7XG4gICAgICAgIGNvbnN0IGh0bWxQYXRoID0gcGF0aC5yZXNvbHZlKHRoaXMucmVzdWx0UGF0aCwgYC4vaHRtbC8ke2ZpbGVuYW1lfS5odG1sYCk7XG4gICAgICAgIGF3YWl0IGZzLndyaXRlRmlsZShodG1sUGF0aCwgcGFnZUh0bWwpO1xuICAgIH1cbiAgICBhc3luYyBhZGRSZWRCb3JkZXI0SGFuZGxlKGZyYW1lLCBoYW5kbGUsIGNvbG9yID0gJ3JlZCcpIHtcbiAgICAgICAgcmV0dXJuIGF3YWl0IGZyYW1lLmV2YWx1YXRlSGFuZGxlKChlbCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgZm9jdXNCb3JkZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgICAgICAgIGNvbnN0IHJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgICAgIGZvY3VzQm9yZGVyLnN0eWxlLnBvc2l0aW9uID0gJ2Fic29sdXRlJztcbiAgICAgICAgICAgIGZvY3VzQm9yZGVyLnN0eWxlLnpJbmRleCA9ICcxMDAwMCc7XG4gICAgICAgICAgICBmb2N1c0JvcmRlci5zdHlsZS5ib3hTaXppbmcgPSAnYm9yZGVyLWJveCc7XG4gICAgICAgICAgICBmb2N1c0JvcmRlci5zdHlsZS5sZWZ0ID0gcmVjdC5sZWZ0IC0gNSArICdweCc7XG4gICAgICAgICAgICBmb2N1c0JvcmRlci5zdHlsZS50b3AgPSByZWN0LnRvcCArIHdpbmRvdy5zY3JvbGxZIC0gNSArICdweCc7XG4gICAgICAgICAgICBmb2N1c0JvcmRlci5zdHlsZS53aWR0aCA9IHJlY3Qud2lkdGggKyAxMCArICdweCc7XG4gICAgICAgICAgICBmb2N1c0JvcmRlci5zdHlsZS5oZWlnaHQgPSByZWN0LmhlaWdodCArIDEwICsgJ3B4JztcbiAgICAgICAgICAgIGZvY3VzQm9yZGVyLnN0eWxlLmJvcmRlciA9ICc1cHggc29saWQgJyArIGNvbG9yO1xuICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChmb2N1c0JvcmRlcik7XG4gICAgICAgICAgICByZXR1cm4gZm9jdXNCb3JkZXI7XG4gICAgICAgIH0sIGhhbmRsZSk7XG4gICAgfVxuICAgIC8vIHByaXZhdGUgYXN5bmMgc2NyZWVuc2hvdEJlZm9yZUNsaWNrKGZyYW1lOiBwdXBwZXRlZXIuRnJhbWUsIGhhbmRsZTogcHVwcGV0ZWVyLkVsZW1lbnRIYW5kbGUpIHtcbiAgICAvLyAgIGNvbnN0IGZ1Y29zQm9yZGVySGFuZGxlID0gYXdhaXQgdGhpcy5hZGRSZWRCb3JkZXI0SGFuZGxlKGZyYW1lLCBoYW5kbGUpXG4gICAgLy8gICBhd2FpdCB0aGlzLnNhdmVTY3JlZW5TaG90KClcbiAgICAvLyAgIGF3YWl0IGZyYW1lLmV2YWx1YXRlKChyZWRCb3JkZXJIYW5kbGUpID0+IHtcbiAgICAvLyAgICAgcmVkQm9yZGVySGFuZGxlLnJlbW92ZSgpXG4gICAgLy8gICB9LCBmdWNvc0JvcmRlckhhbmRsZSlcbiAgICAvLyB9XG4gICAgYXN5bmMgZ2VuVGFza1Jlc3VsdChhdWRpdHNSZXN1bHQpIHtcbiAgICAgICAgY29uc3QgZGV2aWNlSW5mbyA9IGlQaG9uZVg7XG4gICAgICAgIGNvbnN0IHJlc3VsdERldmljZUluZm8gPSB7XG4gICAgICAgICAgICBvczogXCJpb3NcIixcbiAgICAgICAgICAgIHNjcmVlbldpZHRoOiBkZXZpY2VJbmZvLnZpZXdwb3J0LndpZHRoLFxuICAgICAgICAgICAgc2NyZWVuSGVpZ2h0OiBkZXZpY2VJbmZvLnZpZXdwb3J0LmhlaWdodCxcbiAgICAgICAgICAgIG1vZGVsOiBkZXZpY2VJbmZvLm5hbWUsXG4gICAgICAgICAgICBkcHI6IGRldmljZUluZm8udmlld3BvcnQuZGV2aWNlU2NhbGVGYWN0b3IsXG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IG5vbldlYnZpZXdQYWdlID0gT2JqZWN0LmtleXModGhpcy51cmxQYXRoTWFwKS5maWx0ZXIoKGtleSkgPT4gIXRoaXMudXJsUGF0aE1hcFtrZXldLmlzV2VidmlldykubGVuZ3RoO1xuICAgICAgICBjb25zdCBjcmF3bFBhZ2VUb3RhbCA9IE9iamVjdC5rZXlzKHRoaXMudXJsUGF0aE1hcCkubGVuZ3RoO1xuICAgICAgICBjb25zdCBub1Jlc3VsdCA9IGF1ZGl0c1Jlc3VsdC5zY29yZV9udW0gPT09IHVuZGVmaW5lZDtcbiAgICAgICAgY29uc3QgaGFzRG9uZVBhZ2VzID0gdGhpcy50YXNrUmVzdWx0LnBhZ2VzLmxlbmd0aCAhPT0gMDtcbiAgICAgICAgbGV0IGlzQWxsV2VidmlldyA9IGhhc0RvbmVQYWdlcztcbiAgICAgICAgdGhpcy50YXNrUmVzdWx0LnBhZ2VzLmZvckVhY2goKGl0ZW0pID0+IGlzQWxsV2VidmlldyA9IGlzQWxsV2VidmlldyA/IGl0ZW0uaXNfd2VidmlldyA9PSAxIDogaXNBbGxXZWJ2aWV3KTtcbiAgICAgICAgdGhpcy5sb2cuaW5mbyhgbm9SZXN1bHQgJHtub1Jlc3VsdH0sIGhhc0RvbmVQYWdlcyAke2hhc0RvbmVQYWdlc30sIGlzQWxsV2VidmlldyAke2lzQWxsV2Vidmlld31gKTtcbiAgICAgICAgdGhpcy50YXNrRmluaXNoZWRUaW1lID0gRGF0ZS5ub3coKTtcbiAgICAgICAgdGhpcy5sb2cuaW5mbyhgdGltZSB1c2VkICR7dGhpcy50YXNrRmluaXNoZWRUaW1lIC0gdGhpcy50YXNrU3RhcnRUaW1lfW1zYCk7XG4gICAgICAgIE9iamVjdC5hc3NpZ24odGhpcy50YXNrUmVzdWx0LCB7XG4gICAgICAgICAgICBhY3Rpb25faGlzdG9yeTogW10sXG4gICAgICAgICAgICAvLyBjb3Zlcl9wYXRoX3JhdGlvOiBPYmplY3Qua2V5cyh0aGlzLnVybFBhdGhNYXApLmxlbmd0aCAvIHRoaXMud3hDb25maWcucGFnZXMubGVuZ3RoLFxuICAgICAgICAgICAgZGV2aWNlX2luZm86IHJlc3VsdERldmljZUluZm8sXG4gICAgICAgICAgICAvLyBkcml2ZXJUaW1lQ29zdDogdGhpcy50YXNrRmluaXNoZWRUaW1lIC0gdGhpcy50YXNrU3RhcnRUaW1lLFxuICAgICAgICAgICAgLy8gaWRlU3RhcnRUaW1lOiB0aGlzLmRyaXZlclN0YXJ0VGltZSxcbiAgICAgICAgICAgIG5vcm1hbFNlYXJjaFBhZ2VDb3VudDogbm9uV2Vidmlld1BhZ2UsXG4gICAgICAgICAgICByZWNvdmVyU3VjY2Vzczogbm9uV2Vidmlld1BhZ2UsXG4gICAgICAgICAgICByZWNvdmVyVG90YWw6IGNyYXdsUGFnZVRvdGFsLFxuICAgICAgICAgICAgLy8gcmVkaXJlY3RUb1BhZ2VDb3VudDpcbiAgICAgICAgICAgIC8vIHNlc3Npb25DcmVhdGVUaW1lOlxuICAgICAgICAgICAgLy8gcmVzdWx0X3N0YXR1czogLFxuICAgICAgICAgICAgdGFiYmFyczogdGhpcy53eENvbmZpZy50YWJCYXIgJiYgdGhpcy53eENvbmZpZy50YWJCYXIubGlzdCAmJiB0aGlzLnd4Q29uZmlnLnRhYkJhci5saXN0Lmxlbmd0aCA/IHRoaXMud3hDb25maWcudGFiQmFyLmxpc3QubWFwKChpdGVtKSA9PiBpdGVtLnBhZ2VQYXRoKSA6IFtdLFxuICAgICAgICAgICAgdGltZUNvc3Q6IHRoaXMudGFza0ZpbmlzaGVkVGltZSAtIHRoaXMuZHJpdmVyU3RhcnRUaW1lLFxuICAgICAgICAgICAgdG90YWxQYWdlQ291bnQ6IHRoaXMud3hDb25maWcgJiYgdGhpcy53eENvbmZpZy5wYWdlcyA/IHRoaXMud3hDb25maWcucGFnZXMubGVuZ3RoIDogMCxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChub1Jlc3VsdCkge1xuICAgICAgICAgICAgdGhpcy50YXNrUmVzdWx0LmlkZV9leHRfaW5mbyA9IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgICAgICBhdWRpdHM6IHtcbiAgICAgICAgICAgICAgICAgICAgaXNBcHBEZWFkOiB0aGlzLmlzQXBwRGVhZCxcbiAgICAgICAgICAgICAgICAgICAgaXNBbGxXZWJ2aWV3OiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgdG90YWxDbGlja0NvdW50OiB0aGlzLmNsaWNrQ250LFxuICAgICAgICAgICAgICAgICAgICBpc1RpbWVvdXQ6IHRoaXMuaXNUaW1lb3V0LFxuICAgICAgICAgICAgICAgICAgICBqc0NvdmVyYWdlOiB0aGlzLmpzQ292ZXJhZ2UsXG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdDogW10sXG4gICAgICAgICAgICAgICAgICAgIHNjb3JlX251bTogMFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGlzQWxsV2Vidmlldykge1xuICAgICAgICAgICAgcmVwb3J0SWRLZXlfMS5yZXBvcnRJZEtleShyZXBvcnRJZEtleV8xLklkS2V5LklTX0FsbF9XRUJWSUVXKTtcbiAgICAgICAgICAgIHRoaXMudGFza1Jlc3VsdC5pZGVfZXh0X2luZm8gPSBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgICAgYXVkaXRzOiB7XG4gICAgICAgICAgICAgICAgICAgIGlzQWxsV2VidmlldzogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgdG90YWxDbGlja0NvdW50OiB0aGlzLmNsaWNrQ250LFxuICAgICAgICAgICAgICAgICAgICBpc1RpbWVvdXQ6IHRoaXMuaXNUaW1lb3V0LFxuICAgICAgICAgICAgICAgICAgICBqc0NvdmVyYWdlOiB0aGlzLmpzQ292ZXJhZ2UsXG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdDogW10sXG4gICAgICAgICAgICAgICAgICAgIHNjb3JlX251bTogMFxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGF1ZGl0c1Jlc3VsdC5zY29yZV9udW0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhpcy50YXNrUmVzdWx0LmlkZV9leHRfaW5mbyA9IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgICAgICBhdWRpdHM6IHtcbiAgICAgICAgICAgICAgICAgICAgdG90YWxDbGlja0NvdW50OiB0aGlzLmNsaWNrQ250LFxuICAgICAgICAgICAgICAgICAgICBpc1RpbWVvdXQ6IHRoaXMuaXNUaW1lb3V0LFxuICAgICAgICAgICAgICAgICAgICBqc0NvdmVyYWdlOiB0aGlzLmpzQ292ZXJhZ2UsXG4gICAgICAgICAgICAgICAgICAgIHJlc3VsdDogSlNPTi5zdHJpbmdpZnkoYXVkaXRzUmVzdWx0KSxcbiAgICAgICAgICAgICAgICAgICAgc2NvcmVfbnVtOiBhdWRpdHNSZXN1bHQuc2NvcmVfbnVtXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgYXdhaXQgZnMud3JpdGVGaWxlKHBhdGguam9pbih0aGlzLnJlc3VsdFBhdGgsIGAke3RoaXMuYXBwaWR9Lmpzb25gKSwgSlNPTi5zdHJpbmdpZnkodGhpcy50YXNrUmVzdWx0KSk7XG4gICAgICAgIHJldHVybiB0aGlzLnRhc2tSZXN1bHQ7XG4gICAgfVxufVxuZXhwb3J0cy5kZWZhdWx0ID0gQXVkaXRzQXV0bztcbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuY29uc3QgdXRpbHMgPSByZXF1aXJlKCcuLi8uLi9qcy91dGlscy5qcycpO1xuY29uc3QgdXJsXzEgPSByZXF1aXJlKFwidXJsXCIpO1xuY29uc3QgZXZlbnRzXzEgPSByZXF1aXJlKFwiZXZlbnRzXCIpO1xuY2xhc3MgTmV0d29ya0xpc3RlbmVyIGV4dGVuZHMgZXZlbnRzXzEuRXZlbnRFbWl0dGVyIHtcbiAgICBjb25zdHJ1Y3RvcihwYWdlKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMucmVxdWVzdENvdW50ID0gMDtcbiAgICAgICAgdGhpcy5oYW5kbGVyID0ge307XG4gICAgICAgIHRoaXMucmVxdWVzdElkTWFwID0gbmV3IFdlYWtNYXAoKTtcbiAgICAgICAgdGhpcy5yZXF1ZXN0RXZlbnRNYXAgPSB7XG4gICAgICAgICAgICByZXF1ZXN0OiBuZXcgV2Vha01hcCgpLFxuICAgICAgICAgICAgcmVxdWVzdGZhaWxlZDogbmV3IFdlYWtNYXAoKSxcbiAgICAgICAgICAgIHJlcXVlc3RmaW5pc2hlZDogbmV3IFdlYWtNYXAoKSxcbiAgICAgICAgICAgIHJlc3BvbnNlOiBuZXcgV2Vha01hcCgpXG4gICAgICAgIH07XG4gICAgICAgIHRoaXMucmVxdWVzdElkSW5mbyA9IHt9O1xuICAgICAgICB0aGlzLnBhZ2UgPSBwYWdlO1xuICAgICAgICB0aGlzLmluaXRIYW5kbGVyU2V0KCk7XG4gICAgICAgIHRoaXMuaW5pdE5ldHdvcmtMaXN0ZW5pbmcocGFnZSk7XG4gICAgfVxuICAgIGluaXRIYW5kbGVyU2V0KCkge1xuICAgICAgICB0aGlzLmhhbmRsZXJbJ3JlcXVlc3QnXSA9IG5ldyBTZXQoKTtcbiAgICAgICAgdGhpcy5oYW5kbGVyWydyZXF1ZXN0ZmFpbGVkJ10gPSBuZXcgU2V0KCk7XG4gICAgICAgIHRoaXMuaGFuZGxlclsncmVxdWVzdGZpbmlzaGVkJ10gPSBuZXcgU2V0KCk7XG4gICAgICAgIHRoaXMuaGFuZGxlclsncmVzcG9uc2UnXSA9IG5ldyBTZXQoKTtcbiAgICB9XG4gICAgbWFwUmVxdWVzdDJEZXRhaWwocmVxdWVzdCwgcmVzcG9uc2UpIHtcbiAgICAgICAgY29uc3QgdXJsID0gdGhpcy5nZXRSZWFsVXJsKHJlcXVlc3QudXJsKCkpO1xuICAgICAgICBjb25zdCBpc1Byb3h5ID0gdXJsICE9IHJlcXVlc3QudXJsKCk7XG4gICAgICAgIGNvbnN0IHJlcXVlc3RJZCA9IHRoaXMucmVxdWVzdElkTWFwLmdldChyZXF1ZXN0KSB8fCArK3RoaXMucmVxdWVzdENvdW50O1xuICAgICAgICBjb25zdCBjdXJyZW50VGltZSA9IERhdGUubm93KCk7XG4gICAgICAgIGNvbnN0IGZyb21DYWNoZSA9IHJlc3BvbnNlID8gcmVzcG9uc2UuZnJvbUNhY2hlKCkgOiB1bmRlZmluZWQ7XG4gICAgICAgIGNvbnN0IGZhaWx1cmUgPSByZXF1ZXN0LmZhaWx1cmUoKTtcbiAgICAgICAgY29uc3QgZXJyb3IgPSBmYWlsdXJlID8gZmFpbHVyZS5lcnJvclRleHQgOiAnJztcbiAgICAgICAgY29uc3Qgc3RhdHVzQ29kZSA9IHJlc3BvbnNlID8gcmVzcG9uc2Uuc3RhdHVzKCkudG9TdHJpbmcoKSA6IHVuZGVmaW5lZDtcbiAgICAgICAgbGV0IGhlYWRlcnMgPSBbXTtcbiAgICAgICAgbGV0IHJlcXVlc3RJbmZvID0gdGhpcy5yZXF1ZXN0SWRJbmZvW3JlcXVlc3RJZF07XG4gICAgICAgIGlmICghcmVxdWVzdEluZm8pIHtcbiAgICAgICAgICAgIHRoaXMucmVxdWVzdElkTWFwLnNldChyZXF1ZXN0LCByZXF1ZXN0SWQpO1xuICAgICAgICAgICAgcmVxdWVzdEluZm8gPSB0aGlzLnJlcXVlc3RJZEluZm9bcmVxdWVzdElkXSA9IHsgcmVxdWVzdCwgdGltZVN0YW1wOiBjdXJyZW50VGltZSB9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZXNwb25zZSkge1xuICAgICAgICAgICAgY29uc3QgaGVhZGVyT2JqZWN0ID0gcmVzcG9uc2UuaGVhZGVycygpO1xuICAgICAgICAgICAgaGVhZGVycyA9IE9iamVjdC5rZXlzKGhlYWRlck9iamVjdCkubWFwKChoZWFkZXJLZXkpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiBoZWFkZXJLZXksXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlOiBoZWFkZXJPYmplY3RbaGVhZGVyS2V5XVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVxdWVzdElkLFxuICAgICAgICAgICAgdHlwZTogcmVxdWVzdC5yZXNvdXJjZVR5cGUoKSxcbiAgICAgICAgICAgIHVybCxcbiAgICAgICAgICAgIHRpbWVTdGFtcDogY3VycmVudFRpbWUsXG4gICAgICAgICAgICByZXNwb25zZUhlYWRlcnM6IGhlYWRlcnMsXG4gICAgICAgICAgICBmcm9tQ2FjaGUsXG4gICAgICAgICAgICBzdGF0dXNDb2RlLFxuICAgICAgICAgICAgY29zdFRpbWU6IGN1cnJlbnRUaW1lIC0gcmVxdWVzdEluZm8udGltZVN0YW1wLFxuICAgICAgICAgICAgaXNQcm94eSxcbiAgICAgICAgICAgIGVycm9yXG4gICAgICAgIH07XG4gICAgfVxuICAgIGdldFJlYWxVcmwodXJsKSB7XG4gICAgICAgIGlmICh1cmwuaW5kZXhPZignd3hhY3Jhd2xlcnJlcXVlc3QvcHJveHknKSA+IC0xKSB7XG4gICAgICAgICAgICBsZXQgdG1wVXJsT2JqID0gdXJsXzEucGFyc2UodXJsLCB0cnVlKTtcbiAgICAgICAgICAgIHVybCA9IHR5cGVvZiB0bXBVcmxPYmoucXVlcnkudXJsID09ICdzdHJpbmcnID8gdG1wVXJsT2JqLnF1ZXJ5LnVybCA6IHRtcFVybE9iai5xdWVyeS51cmxbMF07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHVybDtcbiAgICB9XG4gICAgZ2V0TmV0d29ya0V2ZW50U291cmNlKHJlcXVlc3QsIGRldGFpbHMpIHtcbiAgICAgICAgdmFyIGZyYW1lID0gcmVxdWVzdC5mcmFtZSgpO1xuICAgICAgICBpZiAoIWZyYW1lKVxuICAgICAgICAgICAgcmV0dXJuICd1bmtub3cnO1xuICAgICAgICAvLyBjb25zb2xlLmxvZyhgJHtmcmFtZS5uYW1lKCl9ICR7cmVxdWVzdC51cmwoKX1gKVxuICAgICAgICAvLyDnlLHkuo5hcHBzZXJ2aWNl55qE6K+35rGC5Y+v6IO95Lya6KKrbmF0aXZl5bGC5Yqg5Luj55CG77yM5omA5Lul6K+35rGC5p2l5rqQ55qEZnJhbWXlj6/og73mmK9uYXRpdmXogIzkuI3mmK9hcHBzZXJ2aWNlXG4gICAgICAgIGlmIChmcmFtZS5uYW1lKCkgPT09ICdhcHBzZXJ2aWNlJyB8fCBkZXRhaWxzLmlzUHJveHkpIHtcbiAgICAgICAgICAgIC8vIHRoaXMubG9nLmRlYnVnKCduZXR3b3JrTGlzdGVuZXIgcmVxdWVzdCBmcm9tIHNlcnZpY2UnLCBkZXRhaWxzLnJlcXVlc3RJZClcbiAgICAgICAgICAgIHJldHVybiAnYXBwc2VydmljZSc7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoL153ZWJ2aWV3XFwtLy50ZXN0KGZyYW1lLm5hbWUoKSkpIHtcbiAgICAgICAgICAgIC8vIHRoaXMubG9nLmRlYnVnKCduZXR3b3JrTGlzdGVuZXIgcmVxdWVzdCBmcm9tIHdlYnZpZXcnLCBmcmFtZUlkLCBkZXRhaWxzLnJlcXVlc3RJZClcbiAgICAgICAgICAgIHJldHVybiAnd2Vidmlldyc7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICd1bmtub3cnO1xuICAgIH1cbiAgICBpbml0TmV0d29ya0xpc3RlbmluZyhwYWdlKSB7XG4gICAgICAgIHBhZ2Uub24oJ3JlcXVlc3QnLCBhc3luYyAocmVxdWVzdCkgPT4ge1xuICAgICAgICAgICAgbGV0IHVybCA9IHRoaXMuZ2V0UmVhbFVybChyZXF1ZXN0LnVybCgpKTtcbiAgICAgICAgICAgIGlmICghdXRpbHMuaXNSZXF1ZXN0Tm90Rm9yQXVkaXQodXJsKSkge1xuICAgICAgICAgICAgICAgIC8vIHRoaXMubG9nLmRlYnVnKCdyZXF1ZXN0IHVybDonLCAgdXJsKVxuICAgICAgICAgICAgICAgIGlmICh0aGlzLnJlcXVlc3RFdmVudE1hcC5yZXF1ZXN0LmdldChyZXF1ZXN0KSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIHRoaXMucmVxdWVzdEV2ZW50TWFwLnJlcXVlc3Quc2V0KHJlcXVlc3QsIHRydWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGZyYW1lID0gcmVxdWVzdC5mcmFtZSgpO1xuICAgICAgICAgICAgICAgIGlmIChmcmFtZSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBkZXRhaWxzID0gdGhpcy5tYXBSZXF1ZXN0MkRldGFpbChyZXF1ZXN0KTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXZlbnRJbmZvID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnROYW1lOiAnb25CZWZvcmVSZXF1ZXN0JyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IHRoaXMuZ2V0TmV0d29ya0V2ZW50U291cmNlKHJlcXVlc3QsIGRldGFpbHMpLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGV0YWlsc1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXZlbnRJbmZvLnR5cGUgIT0gJ3Vua25vdycpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZW1pdCgnT05fUkVRVUVTVF9FVkVOVCcsIGV2ZW50SW5mbyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICBwYWdlLm9uKCdyZXF1ZXN0ZmFpbGVkJywgKHJlcXVlc3QpID0+IHtcbiAgICAgICAgICAgIGxldCB1cmwgPSB0aGlzLmdldFJlYWxVcmwocmVxdWVzdC51cmwoKSk7XG4gICAgICAgICAgICBpZiAoIXV0aWxzLmlzUmVxdWVzdE5vdEZvckF1ZGl0KHVybCkpIHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXF1ZXN0SWQgPSB0aGlzLnJlcXVlc3RFdmVudE1hcC5yZXF1ZXN0LmdldChyZXF1ZXN0KTtcbiAgICAgICAgICAgICAgICBjb25zdCBmcmFtZSA9IHJlcXVlc3QuZnJhbWUoKTtcbiAgICAgICAgICAgICAgICBpZiAocmVxdWVzdElkICYmIGZyYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGRldGFpbHMgPSB0aGlzLm1hcFJlcXVlc3QyRGV0YWlsKHJlcXVlc3QpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBldmVudEluZm8gPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBldmVudE5hbWU6ICdvbkVycm9yT2NjdXJyZWQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogdGhpcy5nZXROZXR3b3JrRXZlbnRTb3VyY2UocmVxdWVzdCwgZGV0YWlscyksXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXRhaWxzXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIGlmIChldmVudEluZm8udHlwZSAhPSAndW5rbm93Jykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5lbWl0KCdPTl9SRVFVRVNUX0VWRU5UJywgZXZlbnRJbmZvKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHBhZ2Uub24oJ3JlcXVlc3RmaW5pc2hlZCcsIChyZXF1ZXN0KSA9PiB7XG4gICAgICAgICAgICBsZXQgdXJsID0gdGhpcy5nZXRSZWFsVXJsKHJlcXVlc3QudXJsKCkpO1xuICAgICAgICAgICAgaWYgKCF1dGlscy5pc1JlcXVlc3ROb3RGb3JBdWRpdCh1cmwpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVxdWVzdElkID0gdGhpcy5yZXF1ZXN0RXZlbnRNYXAucmVxdWVzdC5nZXQocmVxdWVzdCk7XG4gICAgICAgICAgICAgICAgY29uc3QgZnJhbWUgPSByZXF1ZXN0LmZyYW1lKCk7XG4gICAgICAgICAgICAgICAgaWYgKHJlcXVlc3RJZCAmJiBmcmFtZSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBkZXRhaWxzID0gdGhpcy5tYXBSZXF1ZXN0MkRldGFpbChyZXF1ZXN0LCByZXF1ZXN0LnJlc3BvbnNlKCkpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBldmVudEluZm8gPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBldmVudE5hbWU6ICdvbkNvbXBsZXRlZCcsXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiB0aGlzLmdldE5ldHdvcmtFdmVudFNvdXJjZShyZXF1ZXN0LCBkZXRhaWxzKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRldGFpbHNcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGV2ZW50SW5mby50eXBlICE9ICd1bmtub3cnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmVtaXQoJ09OX1JFUVVFU1RfRVZFTlQnLCBldmVudEluZm8pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcGFnZS5vbigncmVzcG9uc2UnLCBhc3luYyAocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHJlcXVlc3QgPSByZXNwb25zZS5yZXF1ZXN0KCk7XG4gICAgICAgICAgICBsZXQgdXJsID0gdGhpcy5nZXRSZWFsVXJsKHJlcXVlc3QudXJsKCkpO1xuICAgICAgICAgICAgaWYgKCF1dGlscy5pc1JlcXVlc3ROb3RGb3JBdWRpdCh1cmwpKSB7XG4gICAgICAgICAgICAgICAgLy8gdGhpcy5sb2cuZGVidWcoYHJlc3BvbnNlIHVybDogJHt1cmx9IGlzUmVxdWVzdE5vdEZvckF1ZGl0cyAke3V0aWxzLmlzUmVxdWVzdE5vdEZvckF1ZGl0KHVybCl9YClcbiAgICAgICAgICAgICAgICBjb25zdCByZXF1ZXN0SWQgPSB0aGlzLnJlcXVlc3RFdmVudE1hcC5yZXF1ZXN0LmdldChyZXF1ZXN0KTtcbiAgICAgICAgICAgICAgICBjb25zdCBmcmFtZSA9IHJlcXVlc3QuZnJhbWUoKTtcbiAgICAgICAgICAgICAgICBpZiAocmVxdWVzdElkICYmIGZyYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGRldGFpbHMgPSB0aGlzLm1hcFJlcXVlc3QyRGV0YWlsKHJlcXVlc3QsIHJlc3BvbnNlKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXZlbnRJbmZvID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnROYW1lOiAnb25IZWFkZXJzUmVjZWl2ZWQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogdGhpcy5nZXROZXR3b3JrRXZlbnRTb3VyY2UocmVxdWVzdCwgZGV0YWlscyksXG4gICAgICAgICAgICAgICAgICAgICAgICBkZXRhaWxzXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIGlmIChldmVudEluZm8udHlwZSAhPSAndW5rbm93Jykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZGV0YWlscy50aW1lU3RhbXAgPSBEYXRlLm5vdygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5lbWl0KCdPTl9SRVFVRVNUX0VWRU5UJywgZXZlbnRJbmZvKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50SW5mby5ldmVudE5hbWUgPSAnb25SZXNwb25zZVN0YXJ0ZWQnO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5lbWl0KCdPTl9SRVFVRVNUX0VWRU5UJywgZXZlbnRJbmZvKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxufVxuZXhwb3J0cy5kZWZhdWx0ID0gTmV0d29ya0xpc3RlbmVyO1xuIiwibW9kdWxlLmV4cG9ydHMuJCA9IGZ1bmN0aW9uIChzZWxlY3RvciwgZWwpIHtcbiAgaWYgKHR5cGVvZiBlbCA9PT0gJ3N0cmluZycpIHtcbiAgICBlbCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoZWwpXG4gIH1cblxuICByZXR1cm4gKGVsIHx8IGRvY3VtZW50KS5xdWVyeVNlbGVjdG9yKHNlbGVjdG9yKVxufVxuXG5tb2R1bGUuZXhwb3J0cy4kJCA9IGZ1bmN0aW9uIChzZWxlY3Rvcikge1xuICByZXR1cm4gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChzZWxlY3Rvcilcbn1cblxubW9kdWxlLmV4cG9ydHMuc2hvdyA9IGZ1bmN0aW9uIChlbCkge1xuICBpZiAodHlwZW9mIGVsID09PSAnc3RyaW5nJykge1xuICAgIGVsID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihlbClcbiAgfVxuXG4gIGVsLnN0eWxlLmRpc3BsYXkgPSAnJ1xufVxuXG5tb2R1bGUuZXhwb3J0cy5oaWRlID0gZnVuY3Rpb24gKGVsKSB7XG4gIGlmICh0eXBlb2YgZWwgPT09ICdzdHJpbmcnKSB7XG4gICAgZWwgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGVsKVxuICB9XG5cbiAgZWwuc3R5bGUuZGlzcGxheSA9ICdub25lJ1xufVxuXG5tb2R1bGUuZXhwb3J0cy5zcHJpbnRmID0gZnVuY3Rpb24gKHN0ciwgYXJncykge1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGFyZ3MubGVuZ3RoOyBpKyspIHtcbiAgICBzdHIgPSBzdHIucmVwbGFjZSgvJXMvLCBhcmdzW2ldKVxuICB9XG4gIHJldHVybiBzdHJcbn1cblxubW9kdWxlLmV4cG9ydHMucmVwb3J0QmVoYXZpb3IgPSBmdW5jdGlvbiAoZGF0YSkge1xuICAvLyBkYXRhOiBzY29yZV9udW0sIHNjb3JlX2xldmVsLCBmYWlsZWRfZGV0YWlsLCBpZ25vcmVkX2RldGFpbCwgdXNlX3RpbWVcbiAgdGhpcy5sb2coJ3JlcG9ydEJlaGF2aW9yJywgZGF0YSlcbiAgcGx1Z2luTWVzc2FnZXIuaW52b2tlKCdSRVBPUlQnLCBKU09OLnN0cmluZ2lmeShkYXRhKSlcbn1cblxubW9kdWxlLmV4cG9ydHMubG9nID0gZnVuY3Rpb24gKCkge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09ICdkZXZlbG9wbWVudCcpIHtcbiAgICBjb25zdCBhcmdzID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzKVxuICAgIGFyZ3MudW5zaGlmdCgnY29sb3I6ICNlYTZmNWE7JylcbiAgICBhcmdzLnVuc2hpZnQoJyVjW0F1ZGl0XScpXG4gICAgLy8gYXJnc1swXSA9ICdbQXVkaXRdICcgKyAoYXJnc1swXSB8fCAnJylcbiAgICBjb25zb2xlLmxvZyguLi5hcmdzKVxuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzLmZvcm1hdFNpemUgPSBmdW5jdGlvbiAoc2l6ZSkge1xuICBjb25zdCB1bml0cyA9IFsnQicsICdLJywgJ00nLCAnRyddXG4gIGxldCB1bml0XG4gIHdoaWxlICgodW5pdCA9IHVuaXRzLnNoaWZ0KCkpICYmIHNpemUgPiAxMDI0KSB7XG4gICAgc2l6ZSAvPSAxMDI0XG4gIH1cbiAgcmV0dXJuICh1bml0ID09PSAnQicgPyBzaXplIDogc2l6ZS50b0ZpeGVkKDIpKSArIHVuaXRcbn1cblxubW9kdWxlLmV4cG9ydHMuaGFzaCA9IGZ1bmN0aW9uICh0ZXh0KSB7XG4gIGxldCBoYXNoID0gNTM4MVxuICBsZXQgaW5kZXggPSB0ZXh0Lmxlbmd0aFxuXG4gIHdoaWxlIChpbmRleCkge1xuICAgIGhhc2ggPSAoaGFzaCAqIDMzKSBeIHRleHQuY2hhckNvZGVBdCgtLWluZGV4KVxuICB9XG5cbiAgcmV0dXJuIGhhc2ggPj4+IDBcbn1cblxuLy8gIOiuoeeul+Wtl+espuS4suWtl+espuaVsFxubW9kdWxlLmV4cG9ydHMuYnl0ZUNvdW50ID0gZnVuY3Rpb24gKHMpIHtcbiAgcmV0dXJuIGVuY29kZVVSSShzKS5zcGxpdCgvJS4ufC4vKS5sZW5ndGggLSAxXG59XG5cbi8vICDmlbDnu4Tljrvph41cbm1vZHVsZS5leHBvcnRzLnVuaXF1ZSA9IGZ1bmN0aW9uIChhcnIpIHtcbiAgLy8gcmV0dXJuIEFycmF5LmZyb20obmV3IFNldChhcnJheSkpO1xuICBjb25zdCBuZXdBcnIgPSBbXVxuICBmb3IgKGxldCBpID0gMDsgaSA8IGFyci5sZW5ndGg7IGkrKykge1xuICAgIGlmIChuZXdBcnIuaW5kZXhPZihhcnJbaV0pID09PSAtMSkge1xuICAgICAgbmV3QXJyLnB1c2goYXJyW2ldKVxuICAgIH1cbiAgfVxuICByZXR1cm4gbmV3QXJyXG59XG5cbm1vZHVsZS5leHBvcnRzLmdldFR5cGUgPSBmdW5jdGlvbiAodmFsKSB7XG4gIHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsKS5zbGljZSg4LCAtMSkudG9Mb3dlckNhc2UoKVxufVxuXG5tb2R1bGUuZXhwb3J0cy5jb21wYXJlVmVyc2lvbiA9IGZ1bmN0aW9uICh2MSwgdjIpIHtcbiAgdjEgPSB2MS5zcGxpdCgnLicpXG4gIHYyID0gdjIuc3BsaXQoJy4nKVxuICBjb25zdCBsZW4gPSBNYXRoLm1heCh2MS5sZW5ndGgsIHYyLmxlbmd0aClcblxuICB3aGlsZSAodjEubGVuZ3RoIDwgbGVuKSB7XG4gICAgdjEucHVzaCgnMCcpXG4gIH1cbiAgd2hpbGUgKHYyLmxlbmd0aCA8IGxlbikge1xuICAgIHYyLnB1c2goJzAnKVxuICB9XG5cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgIGNvbnN0IG51bTEgPSBwYXJzZUludCh2MVtpXSlcbiAgICBjb25zdCBudW0yID0gcGFyc2VJbnQodjJbaV0pXG5cbiAgICBpZiAobnVtMSA+IG51bTIpIHtcbiAgICAgIHJldHVybiAxXG4gICAgfSBlbHNlIGlmIChudW0xIDwgbnVtMikge1xuICAgICAgcmV0dXJuIC0xXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIDBcbn1cblxubW9kdWxlLmV4cG9ydHMuaXNSZXF1ZXN0Tm90Rm9yQXVkaXQgPSBmdW5jdGlvbiAodXJsKSB7XG4gIGNvbnN0IGludmFsaWREb21haW5SZWcgPSBbXG4gICAgL15kYXRhXFw6LyxcbiAgICAvLyDkupHlh73mlbDplb/ova7or6Lor7fmsYJcbiAgICAvXmh0dHBzOlxcL1xcL3NlcnZpY2V3ZWNoYXQuY29tXFwvd3hhLXFiYXNlXFwvcWJhc2VjaGVja3Jlc3VsdC8sXG4gICAgL15odHRwcz86XFwvXFwvW14vXSpcXC50Y2JcXC5xY2xvdWRcXC5sYVxcLy8sXG4gICAgLy8g5bm/5ZGK57uE5Lu255qE6LWE5rqQXG4gICAgL15odHRwcz86XFwvXFwvd3hzbnNkeXRodW1iXFwud3hzXFwucXFcXC5jb21cXC8vLFxuICAgIC9eaHR0cHM/OlxcL1xcL21tYml6XFwucXBpY1xcLmNuXFwvLyxcbiAgICAvLyAvXmh0dHBzPzpcXC9cXC93eFxcLnFsb2dvXFwuY25cXC8vLFxuICAgIC9eaHR0cHM/OlxcL1xcL1teL10qXFwucWxvZ29cXC5jblxcLy8sXG4gICAgLy8g5Zyw5Zu+57uE5Lu255qE6LWE5rqQXG4gICAgL15odHRwcz86XFwvXFwvW14vXSpcXC5xcVxcLmNvbVxcLy8sXG4gICAgL15odHRwcz86XFwvXFwvW14vXSpcXC5ndGltZ1xcLmNvbVxcLy8sXG4gICAgL15odHRwcz86XFwvXFwvW14vXSpcXC5teWFwcFxcLmNvbVxcLy8sXG4gICAgLy8g5bel5YW35YaF6YOo6K+35rGCXG4gICAgL15odHRwOlxcL1xcLzEyNy4wLjAuMTovLFxuICAgIC8vIOaJqeWxlVxuICAgIC9eY2hyb21lLWV4dGVuc2lvbjpcXC9cXC8vLFxuICAgIC8vIHJ1bnRpbWXnjq/looNcbiAgICAvXmh0dHBzPzpcXC9cXC9zZXJ2aWNld2VjaGF0XFwuY29tXFwvLyxcbiAgICAvXFwvYXVkaXRzXFwvYXNzZXJ0XFwvLyxcbiAgICAvXFwvd3hhY3Jhd2xlclxcLy8sXG5cbiAgICAvXmh0dHBzPzpcXC9cXC9bXi9dKlxcLndlaXhpbmJyaWRnZVxcLmNvbVxcLy8sXG5cbiAgICAvLyDmoYbmnrbotYTmupBcbiAgICAvLyAvXmh0dHA6XFwvXFwvMTI3LjAuMC4xOltcXGRdK1xcL2Zhdmljb24uaWNvLyxcbiAgXVxuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgaW52YWxpZERvbWFpblJlZy5sZW5ndGg7IGkrKykge1xuICAgIGlmICh1cmwubWF0Y2goaW52YWxpZERvbWFpblJlZ1tpXSkpIHtcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGZhbHNlXG59XG5cbmNvbnN0IGZpbHRlckxpYlN0YWNrID0gZnVuY3Rpb24gKHN0YWNrcykge1xuICByZXR1cm4gc3RhY2tzLmZpbHRlcigoc3RhY2spID0+IHtcbiAgICByZXR1cm4gIS9eKF9fZGV2X198X19hc2RlYnVnX198X19wYWdlZnJhbWVfX3xhcHBzZXJ2aWNlXFw/KXxhdWRpdHNcXC9hc3NlcnRcXC9pbmplY3R8V0FTZXJ2aWNlLmpzfFdBV2Vidmlldy5qc3x3eGFjcmF3bGVyXFwvcHVibGljLy50ZXN0KHN0YWNrLmZpbGUpXG4gIH0pXG59XG5cbm1vZHVsZS5leHBvcnRzLnBhcnNlU3RhY2tTdHJpbmdzID0gZnVuY3Rpb24gKHN0YWNrU3RyLCBmaWx0ZXJMaWIgPSB0cnVlKSB7XG4gIGxldCBzdGFja3MgPSBzdGFja1N0ci5zcGxpdCgnXFxuJylcbiAgbGV0IFJFR19FWFAgPSAvYXRcXHMrKFtcXFNdKylcXHMrXFwoKFxcUyspXFwpL1xuICBsZXQgcmVzdWx0ID0gc3RhY2tzLm1hcCgoc3RhY2spID0+IHtcbiAgICBsZXQgcmVzdWx0ID0gc3RhY2subWF0Y2goUkVHX0VYUClcbiAgICBpZiAocmVzdWx0ICYmIHJlc3VsdFsxXSAmJiByZXN1bHRbMl0pIHtcbiAgICAgIGxldCBmaWxlU3RyaW5nID0gcmVzdWx0WzJdLnJlcGxhY2UoL15cXHMqLywgJycpLnJlcGxhY2UoL2h0dHA6XFwvXFwvMTI3XFwuMFxcLjBcXC4xOlxcZCtcXC8oOj8oOj9hcHBzZXJ2aWNlfHd4YWNyYXdsZXJcXC9cXGQrXFwvcHJvZ3JhbVxcL1xcdyspP1xcLyk/LywgJycpXG4gICAgICBsZXQgW2ZpbGUsIGxpbmUsIGNvbHVtbl0gPSBmaWxlU3RyaW5nLnNwbGl0KCc6JylcbiAgICAgIGlmIChmaWxlU3RyaW5nLnNwbGl0KCc6JykubGVuZ3RoID09IDMpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBmdW5jOiByZXN1bHRbMV0ucmVwbGFjZSgvXkF1ZGl0XyhzZXRUaW1lb3V0fHNldEludGVydmFsKV8/LiokLywgJyQxJyksXG4gICAgICAgICAgZmlsZSxcbiAgICAgICAgICBsaW5lOiArbGluZSxcbiAgICAgICAgICBjb2x1bW46ICtjb2x1bW5cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbFxuICB9KS5maWx0ZXIoc3RhY2sgPT4gISFzdGFjaylcblxuICBpZiAoZmlsdGVyTGliKSB7XG4gICAgcmVzdWx0ID0gZmlsdGVyTGliU3RhY2socmVzdWx0KVxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdFxufVxuXG5tb2R1bGUuZXhwb3J0cy5nZXRDYWxsU3RhY2sgPSBmdW5jdGlvbiAoZmlsdGVyTGliID0gdHJ1ZSkge1xuICBsZXQgcmVzdWx0ID0gZXhwb3J0cy5wYXJzZVN0YWNrU3RyaW5ncyhuZXcgRXJyb3IoKS5zdGFjaylcblxuICBpZiAoZmlsdGVyTGliKSB7XG4gICAgcmVzdWx0ID0gZmlsdGVyTGliU3RhY2socmVzdWx0KVxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdFxufVxuXG5tb2R1bGUuZXhwb3J0cy5vbkdlbmVyYXRlRnVuY1JlYWR5ID0gZnVuY3Rpb24gKGZ1bmMpIHtcbiAgaWYgKHdpbmRvdy5fX2dlbmVyYXRlRnVuY19fKSB7XG4gICAgc2V0VGltZW91dChmdW5jKVxuICB9IGVsc2Uge1xuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2dlbmVyYXRlRnVuY1JlYWR5JywgZnVuYylcbiAgfVxufVxuXG5tb2R1bGUuZXhwb3J0cy5zdGF0dXMgPSAncnVubmluZydcblxubW9kdWxlLmV4cG9ydHMudHJpbSA9IGZ1bmN0aW9uIChzdHIpIHtcbiAgcmV0dXJuIHN0ci5yZXBsYWNlKC9eXFxzKnxcXHMqJC9nLCAnJylcbn1cblxubW9kdWxlLmV4cG9ydHMubm9kZUlEQ2xhc3NUZXh0ID0gZnVuY3Rpb24gKG5vZGUpIHtcbiAgY29uc3QgaWRTdHIgPSBub2RlLmlkID8gYCMke25vZGUuaWR9YCA6ICcnXG4gIGNvbnN0IGNsYXNzTmFtZSA9IG1vZHVsZS5leHBvcnRzLnRyaW0obm9kZS5jbGFzc05hbWUpXG4gIGNvbnN0IGNsYXNzU3RyID0gY2xhc3NOYW1lID8gJy4nICsgY2xhc3NOYW1lLnJlcGxhY2UoL1xccysvLCAnLicpIDogJydcblxuICByZXR1cm4gbm9kZS50YWdOYW1lLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXnd4LS8sICcnKSArIGlkU3RyICsgY2xhc3NTdHJcbn1cbiIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuY29uc3QgZXZlbnRzXzEgPSByZXF1aXJlKFwiZXZlbnRzXCIpO1xuY29uc3QgdXRpbHMgPSByZXF1aXJlKFwiLi4vdXRpbC91dGlsc1wiKTtcbmNvbnN0IGxvZ18xID0gcmVxdWlyZShcIi4uL2xvZ1wiKTtcbmNsYXNzIE1pbmFIZWFydGJlYXQgZXh0ZW5kcyBldmVudHNfMS5FdmVudEVtaXR0ZXIge1xuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgdGhpcy50aW1lb3V0Q250ID0gMDtcbiAgICAgICAgdGhpcy5wYWdlID0gb3B0aW9ucy5wYWdlO1xuICAgICAgICB0aGlzLnN0YXJ0SGVhcnRiZWF0KCk7XG4gICAgICAgIHRoaXMudGltZW91dENudCA9IDA7XG4gICAgfVxuICAgIHN0YXJ0SGVhcnRiZWF0KCkge1xuICAgICAgICB1dGlscy50aW1lb3V0RXZhbHVhdGVQYWdlKHRoaXMucGFnZSwgMTAwMDAsICgpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBjb25zb2xlLmxvZygnYXVkaXRzIGNyYXdsZXIgaGVhcnQgYmVhdCcpO1xuICAgICAgICB9KS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIGxvZ18xLmRlZmF1bHQuZGVidWcoJ2hlYXJ0IGJlYXQgb2snKTtcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gdGhpcy5zdGFydEhlYXJ0YmVhdCgpLCAxMDAwMCk7XG4gICAgICAgIH0pLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICAgIGxvZ18xLmRlZmF1bHQuZGVidWcoJ2hlYXJ0IGJlYXQgZXJyb3InKTtcbiAgICAgICAgICAgIHRoaXMudGltZW91dENudCsrO1xuICAgICAgICAgICAgaWYgKHRoaXMudGltZW91dENudCA+PSAzKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5lbWl0KCdOT19IRUFSVF9CRUFUJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHRoaXMuc3RhcnRIZWFydGJlYXQoKSwgMTAwMDApO1xuICAgICAgICB9KTtcbiAgICB9XG59XG5leHBvcnRzLmRlZmF1bHQgPSBNaW5hSGVhcnRiZWF0O1xuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiamltcFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJsb2c0anNcIik7IiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5jb25zdCBldmVudHNfMSA9IHJlcXVpcmUoXCJldmVudHNcIik7XG5jb25zdCBxcyA9IHJlcXVpcmUoXCJxc1wiKTtcbmNvbnN0IGxvZ18xID0gcmVxdWlyZShcIi4uLy4uL2xvZ1wiKTtcbmNvbnN0IHV0aWxzXzEgPSByZXF1aXJlKFwiLi4vLi4vdXRpbC91dGlsc1wiKTtcbmNvbnN0IHJlcG9ydElkS2V5XzEgPSByZXF1aXJlKFwiLi4vLi4vdXRpbC9yZXBvcnRJZEtleVwiKTtcbmNsYXNzIEhpamFjayBleHRlbmRzIGV2ZW50c18xLkV2ZW50RW1pdHRlciB7XG4gICAgZnJhbWVFdmFsdWF0ZShmcmFtZSwgZnVuYywgLi4uYXJncykge1xuICAgICAgICBpZiAoIWZyYW1lLmlzRGV0YWNoZWQoKSkge1xuICAgICAgICAgICAgcmV0dXJuIGZyYW1lLmV2YWx1YXRlKGZ1bmMsIC4uLmFyZ3MpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgLy8gcmVwb3J0SWRLZXkoSWRLZXkuRlJBTUVfREVUQUNIRUQpO1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBmcmFtZSBkZXRhY2hlZCEgbmFtZToke2ZyYW1lLm5hbWV9YCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY29uc3RydWN0b3IocGFnZSkge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnBhZ2UgPSBwYWdlO1xuICAgICAgICB0aGlzLmluaXRFdmVudCgpO1xuICAgIH1cbiAgICBpbml0RXZlbnQoKSB7XG4gICAgICAgIHRoaXMucGFnZS5vbignZGlhbG9nJywgYXN5bmMgKGRpYWxvZykgPT4ge1xuICAgICAgICAgICAgcmVwb3J0SWRLZXlfMS5yZXBvcnRJZEtleShyZXBvcnRJZEtleV8xLklkS2V5LkRJQUxPR19FVkVOVCk7XG4gICAgICAgICAgICBsb2dfMS5kZWZhdWx0LmluZm8oJ2RpYWxvZyBldmVudCBpbnZva2VkLCBkaXNtaXNzIGRpYWxvZycpO1xuICAgICAgICAgICAgYXdhaXQgZGlhbG9nLmRpc21pc3MoKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMucGFnZS5vbignY29uc29sZScsIChtc2cpID0+IHtcbiAgICAgICAgICAgIGlmIChtc2cudHlwZSgpID09PSAnaW5mbycpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBzb3VyY2UgPSBtc2cudGV4dCgpO1xuICAgICAgICAgICAgICAgIGlmIChzb3VyY2UuaW5kZXhPZignOi8vJykgPT09IC0xKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgY29uc3QgbWF0Y2ggPSBzb3VyY2Uuc3BsaXQoJzovLycpO1xuICAgICAgICAgICAgICAgIGNvbnN0IHR5cGUgPSBtYXRjaFswXTtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSAncmVkaXJlY3RUbyc6XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgJ25hdmlnYXRlVG8nOlxuICAgICAgICAgICAgICAgICAgICBjYXNlICdzd2l0Y2hUYWInOlxuICAgICAgICAgICAgICAgICAgICBjYXNlICdyZUxhdW5jaCc6XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgJ25hdmlnYXRlQmFjayc6XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB1cmwgPSBtYXRjaFsxXSB8fCAnJztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZW1pdCgnVVJMX0NIQU5HRScsIHsgdXJsLCB0eXBlIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgJ3B1Ymxpc2hQYWdlRXZlbnQnOlxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgW25hbWUsIHF1ZXJ5XSA9IG1hdGNoWzFdLnNwbGl0KCc/Jyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJhbXMgPSBxcy5wYXJzZShxdWVyeSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXJhbXMubmFtZSA9IG5hbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmVtaXQoJ1BBR0VfRVZFTlQnLCBwYXJhbXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gTG9nZ2VyLmxvZ0luZm8oYFBBR0VfRVZFTlQ6JHtuYW1lfSx3ZWJ2aWV3SWQ6JHtwYXJhbXMud2Vidmlld0lkfWApO1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgaGlqYWNrRGVmYXVsdCh7IGxvbmdpdHVkZSwgbGF0aXR1ZGUgfSkge1xuICAgICAgICByZXR1cm4gdGhpcy5wYWdlLmV2YWx1YXRlKChpc0RlYnVnLCBsb25naXR1ZGUsIGxhdGl0dWRlKSA9PiB7XG4gICAgICAgICAgICBpZiAoaXNEZWJ1Zykge1xuICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdSVU5USU1FX0VOVicsICdkZXZlbG9wbWVudCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkobmF2aWdhdG9yLCAnbGFuZ3VhZ2UnLCB7XG4gICAgICAgICAgICAgICAgICAgIGdldCgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAnemgtQ04nO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSkgeyB9XG4gICAgICAgICAgICB3aW5kb3cubmF0aXZlLnNkay5nZXRMb2NhdGlvbiA9IGFzeW5jIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4geyBlcnJNc2c6ICdnZXRMb2NhdGlvbjpvaycsIGxvbmdpdHVkZTogbG9uZ2l0dWRlLCBsYXRpdHVkZTogbGF0aXR1ZGUgfTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB3aW5kb3cuc2hhcmVEYXRhID0gbnVsbDtcbiAgICAgICAgICAgIHdpbmRvdy5uYXRpdmUuc2RrLnNoYXJlQXBwTWVzc2FnZURpcmVjdGx5XG4gICAgICAgICAgICAgICAgPSB3aW5kb3cubmF0aXZlLnNkay5zaGFyZUFwcE1lc3NhZ2UgPSBhc3luYyBmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cuc2hhcmVEYXRhID0gZGF0YS5hcmdzO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB3aW5kb3cubmF0aXZlLnNldE9wdGlvbignYXV0b1Blcm1pc3Npb24nLCB0cnVlKTtcbiAgICAgICAgICAgIHdpbmRvdy5uYXRpdmUuc2V0T3B0aW9uKCdhdXRvQXV0aG9yaXphdGlvbicsIHRydWUpO1xuICAgICAgICAgICAgLy8gaGFjayDkuIDkupvlvLnnqpfmk43kvZxcbiAgICAgICAgICAgIHdpbmRvdy5uYXRpdmUuc2RrLmNob29zZVZpZGVvXG4gICAgICAgICAgICAgICAgPSB3aW5kb3cubmF0aXZlLnNkay5vcGVuTG9jYXRpb25cbiAgICAgICAgICAgICAgICAgICAgPSB3aW5kb3cubmF0aXZlLnNkay5vcGVuQWRkcmVzc1xuICAgICAgICAgICAgICAgICAgICAgICAgPSB3aW5kb3cubmF0aXZlLnNkay5vcGVuV2VSdW5TZXR0aW5nXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPSB3aW5kb3cubmF0aXZlLnNkay5vcGVuU2V0dGluZ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA9IHdpbmRvdy5uYXRpdmUuc2RrLmNob29zZUltYWdlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA9IHdpbmRvdy5uYXRpdmUuc2RrLmNob29zZUludm9pY2VUaXRsZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID0gd2luZG93Lm5hdGl2ZS5zZGsuc2hvd01vZGFsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID0gd2luZG93Lm5hdGl2ZS5zZGsuZW50ZXJDb250YWNrXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA9IHdpbmRvdy5uYXRpdmUuc2RrLnByZXZpZXdJbWFnZSA9IGZ1bmN0aW9uIChkYXRhID0ge30pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnJNc2c6IGAke2RhdGEuYXBpfTpva2AsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB3aW5kb3cuYWxlcnQgPSB3aW5kb3cuY29uc29sZS5sb2c7IC8vIOWFqOWxgOabv+aNouaOiWFsZXJ0LOemgeaOieWQjOatpeaJp+ihjFxuICAgICAgICB9LCAhIXByb2Nlc3MuZW52LkRFQlVHLCBsb25naXR1ZGUsIGxhdGl0dWRlKTtcbiAgICB9XG4gICAgaGlqYWNrUGFnZUV2ZW50KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5wYWdlLmV2YWx1YXRlKCgpID0+IHtcbiAgICAgICAgICAgIC8vIHdlYnZpZXdQdWJsaXNoUGFnZUV2ZW50XG4gICAgICAgICAgICBpZiAoIXdpbmRvdy5fX2hhbmRsZVdlYnZpZXdQdWJsaXNoKSB7XG4gICAgICAgICAgICAgICAgd2luZG93Ll9faGFuZGxlV2Vidmlld1B1Ymxpc2ggPSB3aW5kb3cubmF0aXZlLmhhbmRsZVdlYnZpZXdQdWJsaXNoO1xuICAgICAgICAgICAgICAgIHdpbmRvdy5uYXRpdmUuaGFuZGxlV2Vidmlld1B1Ymxpc2ggPSBmdW5jdGlvbiAobXNnKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5hbWUgPSBtc2cuZGF0YS5ldmVudE5hbWU7XG4gICAgICAgICAgICAgICAgICAgIGlmIChuYW1lID09PSAnUEFHRV9FVkVOVCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHBhZ2VFdmVudE5hbWUgPSBtc2cuZGF0YS5kYXRhLmRhdGEuZXZlbnROYW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgd2Vidmlld0lkID0gbXNnLndlYnZpZXdJZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuaW5mbyhgcHVibGlzaFBhZ2VFdmVudDovLyR7cGFnZUV2ZW50TmFtZX0/d2Vidmlld0lkPSR7d2Vidmlld0lkfWApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5fX2hhbmRsZVdlYnZpZXdQdWJsaXNoLmFwcGx5KHdpbmRvdy5uYXRpdmUsIFttc2ddKTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIHdpbmRvdy5fX2hhbmRsZUFwcFNlcnZpY2VQdWJsaXNoID0gd2luZG93Lm5hdGl2ZS5oYW5kbGVBcHBTZXJ2aWNlUHVibGlzaDtcbiAgICAgICAgICAgICAgICB3aW5kb3cubmF0aXZlLmhhbmRsZUFwcFNlcnZpY2VQdWJsaXNoID0gZnVuY3Rpb24gKG1zZykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuYW1lID0gbXNnLmRhdGEuZXZlbnROYW1lO1xuICAgICAgICAgICAgICAgICAgICBpZiAobmFtZSA9PT0gJ29uQXBwUm91dGUnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJhbXMgPSBtc2cuZGF0YS5kYXRhLmRhdGE7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBjb25zdCB7b3BlblR5cGUsIHdlYnZpZXdJZCwgcGF0aCwgcXVlcnl9ID0gbXNnIS5kYXRhIS5kYXRhIS5kYXRhO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcXVlcnkgPSBPYmplY3Qua2V5cyhwYXJhbXMpLm1hcCgoa2V5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGAke2tleX09JHtlbmNvZGVVUklDb21wb25lbnQocGFyYW1zW2tleV0pfWA7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KS5qb2luKCcmJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmluZm8oYHB1Ymxpc2hQYWdlRXZlbnQ6Ly9vbkFwcFJvdXRlPyR7cXVlcnl9YCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgd2luZG93Ll9faGFuZGxlQXBwU2VydmljZVB1Ymxpc2guYXBwbHkod2luZG93Lm5hdGl2ZSwgW21zZ10pO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBoaWphY2tOYXZpZ2F0aW9uKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5wYWdlLmV2YWx1YXRlKCgpID0+IHtcbiAgICAgICAgICAgIHdpbmRvdy5uYXRpdmUubmF2aWdhdG9yLnJlZGlyZWN0VG8gPSBmdW5jdGlvbiAodXJsKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5pbmZvKGByZWRpcmVjdFRvOi8vJHt1cmx9YCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHdpbmRvdy5uYXRpdmUubmF2aWdhdG9yLm5hdmlnYXRlVG8gPSBmdW5jdGlvbiAodXJsKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5pbmZvKGBuYXZpZ2F0ZVRvOi8vJHt1cmx9YCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHdpbmRvdy5uYXRpdmUubmF2aWdhdG9yLnN3aXRjaFRhYiA9IGZ1bmN0aW9uICh1cmwpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmluZm8oYHN3aXRjaFRhYjovLyR7dXJsfWApO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB3aW5kb3cubmF0aXZlLm5hdmlnYXRvci5yZUxhdW5jaCA9IGZ1bmN0aW9uICh1cmwpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmluZm8oYHJlTGF1bmNoOi8vJHt1cmx9YCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHdpbmRvdy5uYXRpdmUubmF2aWdhdG9yLm5hdmlnYXRlQmFjayA9IGZ1bmN0aW9uICh1cmwpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmluZm8oYG5hdmlnYXRlQmFjazovLyR7dXJsfWApO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICAvLyDlj7PkuIrop5LnmoTlm57liLDpppbpobXkuZ/pnIDopoHliqvmjIHvvIzkuLvliqjlj5HnjrDov5vvvIzmn5Dkupvmg4XlhrXkvJrop6blj5FcbiAgICAgICAgICAgIHdpbmRvdy5uYXRpdmUubmF2aWdhdG9yLmxhdW5jaCA9IGZ1bmN0aW9uICh1cmwpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmluZm8oYGxhdW5jaDovLyR7dXJsfWApO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB3aW5kb3cubmF0aXZlLndlYnZpZXdNYW5hZ2VyLnJlbW92ZUFsbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9O1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgd2FpdEZvcihldmVudCwga2V5LCB0aW1lb3V0ID0gMTAwMCkge1xuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgY2IgPSAoYXJncykgPT4ge1xuICAgICAgICAgICAgICAgIHJlc29sdmUoYXJnc1trZXldKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB0aGlzLm9uY2UoZXZlbnQsIGNiKTtcbiAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgIHJlamVjdCgndGltZW91dCcpO1xuICAgICAgICAgICAgICAgIHRoaXMucmVtb3ZlTGlzdGVuZXIoZXZlbnQsIGNiKTtcbiAgICAgICAgICAgIH0sIHRpbWVvdXQpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgd2FpdEZvclVybCh0aW1lb3V0ID0gMTAwMCkge1xuICAgICAgICByZXR1cm4gdGhpcy53YWl0Rm9yKCdVUkxfQ0hBTkdFJywgJ3VybCcsIHRpbWVvdXQpO1xuICAgIH1cbiAgICB3YWl0Rm9yUGFnZUV2ZW50KGV2ZW50TmFtZSwgb3B0ID0geyB0aW1lb3V0OiAxMDAwIH0pIHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNiID0gKHsgd2Vidmlld0lkLCBuYW1lIH0pID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoZXZlbnROYW1lID09PSBuYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChvcHQud2Vidmlld0lkID09PSB1bmRlZmluZWQgfHwgb3B0LndlYnZpZXdJZCA9PT0gd2Vidmlld0lkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKCdvaycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW1vdmVMaXN0ZW5lcignUEFHRV9FVkVOVCcsIGNiKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB0aGlzLm9uKCdQQUdFX0VWRU5UJywgY2IpO1xuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgcmVqZWN0KCd0aW1lb3V0Jyk7XG4gICAgICAgICAgICAgICAgdGhpcy5yZW1vdmVMaXN0ZW5lcignUEFHRV9FVkVOVCcsIGNiKTtcbiAgICAgICAgICAgIH0sIG9wdC50aW1lb3V0KTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIOeCueWHu+WJjeWFiOWKq+aMgeS4gOS6m3dlYnZpZXfkvqfnmoTlvLnnqpfmk43kvZxcbiAgICAgKiBAcGFyYW0ge0ZyYW1lfSBmcmFtZVxuICAgICAqL1xuICAgIGhpamFja1dlYml2ZXdBbGVydChmcmFtZSkge1xuICAgICAgICByZXR1cm4gdXRpbHNfMS5mcmFtZUV2YWx1YXRlKGZyYW1lLCAoLi4uYXJncykgPT4ge1xuICAgICAgICAgICAgd2luZG93LmFsZXJ0ID0gd2luZG93LmNvbnNvbGUubG9nO1xuICAgICAgICB9KTtcbiAgICB9XG59XG5leHBvcnRzLmRlZmF1bHQgPSBIaWphY2s7XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmNvbnN0IGV2ZW50c18xID0gcmVxdWlyZShcImV2ZW50c1wiKTtcbmNvbnN0IGxvZ18xID0gcmVxdWlyZShcIi4uLy4uL2xvZ1wiKTtcbmNvbnN0IGRvbVV0aWxzXzEgPSByZXF1aXJlKFwiLi4vLi4vdXRpbC9kb21VdGlsc1wiKTtcbmNvbnN0IEZyYW1lRGF0YV8xID0gcmVxdWlyZShcIi4vRnJhbWVEYXRhXCIpO1xuY29uc3QgcmVwb3J0SWRLZXlfMSA9IHJlcXVpcmUoXCIuLi8uLi91dGlsL3JlcG9ydElkS2V5XCIpO1xuY2xhc3MgUGFnZUJhc2UgZXh0ZW5kcyBldmVudHNfMS5FdmVudEVtaXR0ZXIge1xuICAgIGNvbnN0cnVjdG9yKHBhZ2UsIG9wdCA9IHt9KSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMubG9nID0gbG9nXzEuZGVmYXVsdDtcbiAgICAgICAgdGhpcy5wYWdlID0gcGFnZTtcbiAgICAgICAgdGhpcy5pc01wY3Jhd2xlciA9IG9wdC5pc01wY3Jhd2xlciB8fCBmYWxzZTtcbiAgICAgICAgdGhpcy5mcmFtZU1hcCA9IG5ldyBNYXAoKTtcbiAgICAgICAgY29uc3QgbWFpbkZyYW1lID0gcGFnZS5tYWluRnJhbWUoKTtcbiAgICAgICAgdGhpcy5tYWluRnJhbWVEYXRhID0gbmV3IEZyYW1lRGF0YV8xLmRlZmF1bHQobWFpbkZyYW1lLCB7IGlzTWFpbkZyYW1lOiB0cnVlLCBpc01wY3Jhd2xlcjogdGhpcy5pc01wY3Jhd2xlciB9KTtcbiAgICAgICAgdGhpcy5mcmFtZU1hcC5zZXQobWFpbkZyYW1lLCB0aGlzLm1haW5GcmFtZURhdGEpO1xuICAgICAgICB0aGlzLmRpc2FibGVJbWcgPSBvcHQuZGlzYWJsZUltZyB8fCBmYWxzZTtcbiAgICAgICAgdGhpcy5kaXNhYmxlTWVkaWEgPSBvcHQuZGlzYWJsZU1lZGlhIHx8IGZhbHNlO1xuICAgICAgICB0aGlzLmluaXRUcyA9IERhdGUubm93KCk7XG4gICAgfVxuICAgIGluaXRQYWdlRXZlbnQoKSB7XG4gICAgICAgIGNvbnN0IHBhZ2UgPSB0aGlzLnBhZ2U7XG4gICAgICAgIHBhZ2Uub24oJ2ZyYW1lYXR0YWNoZWQnLCAoZnJhbWUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGZyYW1lRGF0YSA9IG5ldyBGcmFtZURhdGFfMS5kZWZhdWx0KGZyYW1lLCB7XG4gICAgICAgICAgICAgICAgZGlzYWJsZUltZzogdGhpcy5kaXNhYmxlSW1nLFxuICAgICAgICAgICAgICAgIGRpc2FibGVNZWRpYTogdGhpcy5kaXNhYmxlTWVkaWEsXG4gICAgICAgICAgICAgICAgaXNNcGNyYXdsZXI6IHRoaXMuaXNNcGNyYXdsZXJcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5mcmFtZU1hcC5zZXQoZnJhbWUsIGZyYW1lRGF0YSk7XG4gICAgICAgIH0pO1xuICAgICAgICBwYWdlLm9uKCdmcmFtZWRldGFjaGVkJywgKGZyYW1lKSA9PiB7XG4gICAgICAgICAgICBsb2dfMS5kZWZhdWx0LmRlYnVnKCdmcmFtZSBkZXRhY2g6ICcsIGZyYW1lLm5hbWUoKSk7XG4gICAgICAgICAgICBjb25zdCBmcmFtZURhdGEgPSB0aGlzLmZyYW1lTWFwLmdldChmcmFtZSk7XG4gICAgICAgICAgICBpZiAoZnJhbWVEYXRhKSB7XG4gICAgICAgICAgICAgICAgZnJhbWVEYXRhLmVtaXQoJ2RldGFjaCcsIGZyYW1lLm5hbWUoKSk7XG4gICAgICAgICAgICAgICAgdGhpcy5mcmFtZU1hcC5kZWxldGUoZnJhbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcGFnZS5vbigncmVxdWVzdCcsIGFzeW5jIChyZXF1ZXN0KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBmcmFtZSA9IHJlcXVlc3QuZnJhbWUoKTtcbiAgICAgICAgICAgIGlmICghZnJhbWUpXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgY29uc3QgZnJhbWVEYXRhID0gdGhpcy5mcmFtZU1hcC5nZXQoZnJhbWUpO1xuICAgICAgICAgICAgaWYgKCFmcmFtZURhdGEpXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgZnJhbWVEYXRhLm9uUmVxdWVzdFN0YXJ0KHJlcXVlc3QpO1xuICAgICAgICB9KTtcbiAgICAgICAgcGFnZS5vbigncmVxdWVzdGZhaWxlZCcsIGFzeW5jIChyZXF1ZXN0KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBzb3VyY2VUeXBlID0gcmVxdWVzdC5yZXNvdXJjZVR5cGUoKTtcbiAgICAgICAgICAgIGlmIChzb3VyY2VUeXBlICE9PSAnaW1hZ2UnICYmIHNvdXJjZVR5cGUgIT09ICdtZWRpYScpIHtcbiAgICAgICAgICAgICAgICAvLyBkZWJ1ZyhgZmFpbGVkIHJlcXVlc3QgJHtyZXF1ZXN0LnJlc291cmNlVHlwZSgpfTogJHtyZXF1ZXN0LnVybCgpfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgZnJhbWUgPSBhd2FpdCByZXF1ZXN0LmZyYW1lKCk7XG4gICAgICAgICAgICBpZiAoIWZyYW1lKVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIGNvbnN0IGZyYW1lRGF0YSA9IHRoaXMuZnJhbWVNYXAuZ2V0KGZyYW1lKTtcbiAgICAgICAgICAgIGlmICghZnJhbWVEYXRhKVxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIGZyYW1lRGF0YS5vblJlcXVlc3RFbmQocmVxdWVzdCwgJ2ZhaWxlZCcpO1xuICAgICAgICB9KTtcbiAgICAgICAgcGFnZS5vbigncmVxdWVzdGZpbmlzaGVkJywgYXN5bmMgKHJlcXVlc3QpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGZyYW1lID0gYXdhaXQgcmVxdWVzdC5mcmFtZSgpO1xuICAgICAgICAgICAgaWYgKCFmcmFtZSlcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICBjb25zdCBmcmFtZURhdGEgPSB0aGlzLmZyYW1lTWFwLmdldChmcmFtZSk7XG4gICAgICAgICAgICBpZiAoIWZyYW1lRGF0YSlcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IHJlcXVlc3QucmVzcG9uc2UoKTtcbiAgICAgICAgICAgIGlmIChyZXNwb25zZSAmJiAhL14oMnwzKVxcZFxcZCQvLnRlc3QocmVzcG9uc2Uuc3RhdHVzKCkudG9TdHJpbmcoKSkpIHtcbiAgICAgICAgICAgICAgICBsb2dfMS5kZWZhdWx0LmVycm9yKGBmYWlsZWQgcmVxdWVzdCEgc3RhdHVzID0gJHtyZXNwb25zZS5zdGF0dXMoKX0uYCk7XG4gICAgICAgICAgICAgICAgZnJhbWVEYXRhLm9uUmVxdWVzdEVuZChyZXF1ZXN0LCAnZmFpbGVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBmcmFtZURhdGEub25SZXF1ZXN0RW5kKHJlcXVlc3QsICdmaW5pc2hlZCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcGFnZS5vbigncGFnZWVycm9yJywgKGVycm9yKSA9PiB7XG4gICAgICAgICAgICBsb2dfMS5kZWZhdWx0LmVycm9yKGBwYWdlZXJyb3Igb2NjdXIhICR7ZXJyb3IubWVzc2FnZX0gJHtlcnJvci5zdGFja31gKTtcbiAgICAgICAgICAgIHJlcG9ydElkS2V5XzEucmVwb3J0SWRLZXkocmVwb3J0SWRLZXlfMS5JZEtleS5QQUdFX0VYQ0VQVElPTik7XG4gICAgICAgIH0pO1xuICAgICAgICBwYWdlLm9uKCdlcnJvcicsIChlcnIpID0+IHtcbiAgICAgICAgICAgIGxvZ18xLmRlZmF1bHQuZXJyb3IoYHBhZ2UgZXJyb3Igb2NjdXI6YCwgZXJyKTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgbG9nXzEuZGVmYXVsdC5kZWJ1ZygncGFnZSBlcnJvciBvY2N1ciBhbmQgZ29pbmcgdG8gY3Jhc2g6JywgcGFnZS51cmwoKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXBvcnRJZEtleV8xLnJlcG9ydElkS2V5KHJlcG9ydElkS2V5XzEuSWRLZXkuUEFHRV9DUkFTSCk7XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ3BhZ2VFcnJvcicsIGVycik7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBhc3luYyB3YWl0Rm9yQ3VycmVudEZyYW1lSWRsZSh0aW1lb3V0Q250ID0gMCkge1xuICAgICAgICBjb25zdCB7IGZyYW1lLCBpZCB9ID0gYXdhaXQgZG9tVXRpbHNfMS5nZXRDdXJyZW50RnJhbWUodGhpcy5wYWdlKTtcbiAgICAgICAgY29uc3QgZnJhbWVEYXRhID0gdGhpcy5nZXRGcmFtZURhdGEoZnJhbWUpO1xuICAgICAgICBpZiAoIWZyYW1lIHx8ICFmcmFtZURhdGEpIHtcbiAgICAgICAgICAgIC8vIHJlYWxseSBub3QgbGlrZWx5XG4gICAgICAgICAgICByZXBvcnRJZEtleV8xLnJlcG9ydElkS2V5KHJlcG9ydElkS2V5XzEuSWRLZXkuUEFHRV9OT19GUkFNRSk7XG4gICAgICAgICAgICB0aGlzLmxvZy5kZWJ1Zyhgbm8gZnJhbWUgb3IgZnJhbWVEYXRhICEhIWApO1xuICAgICAgICAgICAgcmV0dXJuIHsgZnJhbWU6IHVuZGVmaW5lZCwgaGFzV2VidmlldzogZmFsc2UsIGZyYW1lRGF0YSwgdGltZW91dDogMCwgaWQgfTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmxvZy5kZWJ1ZyhgZ2V0IGN1cnJlbnQgZnJhbWVbJHtmcmFtZS5uYW1lKCl9XSBkb25lYCk7XG4gICAgICAgIGNvbnN0IGlzV2VidmlldyA9IGF3YWl0IGRvbVV0aWxzXzEuaGFzV2VidmlldyhmcmFtZSk7XG4gICAgICAgIHRoaXMubG9nLmRlYnVnKGBjaGVjayBoYXMgd2VidmlldyBbJHtpc1dlYnZpZXd9XSBkb25lYCk7XG4gICAgICAgIGlmIChpc1dlYnZpZXcpIHtcbiAgICAgICAgICAgIC8vIOWMheWQq3dlYnZpZXfvvIznm7TmjqXku7vliqHlpLHotKUsIOmhtemdouaYr+WQpuWMheWQq3dlYnZpZXfvvIzlnKggcGFnZSBkb20gcmVhZHnlkI7lsLHlj6/ku6Xnn6XpgZNcbiAgICAgICAgICAgIGxvZ18xLmRlZmF1bHQuZGVidWcoJ3Rhc2sgZmFpbCBiZWNhdXNlIHBhZ2UgaGFzIHdlYnZpZXcnKTtcbiAgICAgICAgICAgIHJlcG9ydElkS2V5XzEucmVwb3J0SWRLZXkocmVwb3J0SWRLZXlfMS5JZEtleS5QQUdFX0lTX1dFQlZJRVcpO1xuICAgICAgICAgICAgcmV0dXJuIHsgaGFzV2VidmlldzogdHJ1ZSwgZnJhbWUsIGZyYW1lRGF0YSwgdGltZW91dDogMCwgaWQgfTtcbiAgICAgICAgfVxuICAgICAgICAvLyBpZiBmYWlsIGJlY2F1c2Ugb2YgZnJhbWUgZGV0YWNoLCB0cnkgdG8gcmV0dXJuIG5ldyBmcmFtZVxuICAgICAgICAvLyDpnIDopoFtYWluRnJhbWXvvIh3YWl0Q29kZTEp5ZKM5b2T5YmNZnJhbWUod2FpdENvZGUyKeeahOe9kee7nOWQjOaXtuepuumXslxuICAgICAgICBjb25zdCBbd2FpdENvZGUxLCB3YWl0Q29kZTJdID0gYXdhaXQgUHJvbWlzZS5hbGwoW3RoaXMubWFpbkZyYW1lRGF0YS53YWl0Rm9yTmV0d29ya0lkbGUoKSwgZnJhbWVEYXRhLndhaXRGb3JOZXR3b3JrSWRsZSgpXSk7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRJZCA9IGF3YWl0IGRvbVV0aWxzXzEuZ2V0Q3VycmVudElkKHRoaXMucGFnZSk7XG4gICAgICAgIGlmICh3YWl0Q29kZTIgPT09IC0yIHx8IGZyYW1lLmlzRGV0YWNoZWQoKSB8fCBpZCAhPT0gY3VycmVudElkKSB7XG4gICAgICAgICAgICAvLyB3YWl0Q29kZTIgPSAwIOS9huWFtuWunmZyYW1l5bey57uPZGV0YWNo55qE77yM5Y+R55Sf5Zyo6aG16Z2i5YWIbmV0d29ya2lkbGXlho3ooqtkZXRhY2jnmoRjYXNlLCDmiYDku6Xov5nph4zopoHlhbzlrrnkuIDkuItcbiAgICAgICAgICAgIC8vIOWcqOetieW9k+WJjWZyYW1l572R57uc5pe277yM6aG16Z2i6Lez6L2s77yM5b2T5YmNZnJhbWXlt7Lnu4/lj5jvvIzpnIDopoHph43mlrDojrflj5ZcbiAgICAgICAgICAgIC8vIOi/mOacieS4gOenjWNhc2XmmK/vvIzlu7bml7bkuIDkvJrlho3mnInot7PovazvvIzov5nnp43mg4XlhrXmmoLml7bml6Dlip7ms5XlpITnkIZcbiAgICAgICAgICAgIGxvZ18xLmRlZmF1bHQuZGVidWcoYHdhaXQgZm9yIGN1cnJlbnQgZnJhbWVbJHtmcmFtZS5uYW1lKCl9XSBpZGxlIGZhaWw6IGFscmVhZHkgZGV0YWNoLCB0cnkgYWdhaW5gKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLndhaXRGb3JDdXJyZW50RnJhbWVJZGxlKHRpbWVvdXRDbnQpOyAvLyDnrYnlvoXml7ZmcmFtZSBkZXRhY2jkuobvvIzpnIDopoHph43mlrDmi7/lvZPliY1mcmFtZTtcbiAgICAgICAgICAgIC8vIHJldHVybiB7aGFzV2VidmlldzogZmFsc2UsIGZyYW1lOiB1bmRlZmluZWQsIGZyYW1lRGF0YSwgdGltZW91dDogMCwgaWR9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAod2FpdENvZGUxID09PSAtMSB8fCB3YWl0Q29kZTIgPT09IC0xKSB7XG4gICAgICAgICAgICBsb2dfMS5kZWZhdWx0LmRlYnVnKGBmcmFtZVske2ZyYW1lLm5hbWUoKX1dIGlkbGUgdGltZW91dCwgY29kZTogYCwgd2FpdENvZGUxLCB3YWl0Q29kZTIpO1xuICAgICAgICAgICAgdGltZW91dENudCsrO1xuICAgICAgICB9XG4gICAgICAgIGxvZ18xLmRlZmF1bHQuZGVidWcoYGN1cnJlbnQgZnJhbWVbJHtmcmFtZS5uYW1lKCl9XSBuZXR3b3JrIGlkbGUgZG9uZWApO1xuICAgICAgICByZXR1cm4geyBoYXNXZWJ2aWV3OiBmYWxzZSwgZnJhbWUsIGZyYW1lRGF0YSwgdGltZW91dDogdGltZW91dENudCwgaWQgfTtcbiAgICB9XG4gICAgLy8gcHJvdGVjdGVkIGFzeW5jIHdhaXRGb3JGcmFtZUlkbGUoZnJhbWU6IHB1cHBldGVlci5GcmFtZSwgdGltZW91dDogbnVtYmVyKSB7XG4gICAgLy8gICAgIGNvbnN0IGZyYW1lRGF0YSA9IHRoaXMuZ2V0RnJhbWVEYXRhKGZyYW1lKTtcbiAgICAvLyAgICAgaWYgKCFmcmFtZURhdGEpIHJldHVybiBQcm9taXNlLnJlc29sdmUoLTIpO1xuICAgIC8vICAgICBjb25zdCBbd2FpdENvZGUxLCB3YWl0Q29kZTJdID0gYXdhaXQgUHJvbWlzZS5hbGwoW3RoaXMubWFpbkZyYW1lRGF0YS53YWl0Rm9yTmV0d29ya0lkbGUodGltZW91dCksIGZyYW1lRGF0YS53YWl0Rm9yTmV0d29ya0lkbGUodGltZW91dCldKTtcbiAgICAvLyAgICAgZGVidWcoJ3dhaXQgZm9yIGZyYW1lIGlkbGUnLCB3YWl0Q29kZTEsIHdhaXRDb2RlMik7XG4gICAgLy8gICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUod2FpdENvZGUyKTtcbiAgICAvLyB9XG4gICAgZ2V0RnJhbWVEYXRhKGZyYW1lKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmZyYW1lTWFwLmdldChmcmFtZSk7XG4gICAgfVxuICAgIGFzeW5jIHdhaXRGb3JGcmFtZUNoYW5nZSh3ZWJ2aWV3SWQsIHsgdGltZW91dCB9KSB7XG4gICAgICAgIHJldHVybiB0aGlzLnBhZ2Uud2FpdEZvcigoaWQpID0+IHdpbmRvdy5uYXRpdmUud2Vidmlld01hbmFnZXIuZ2V0Q3VycmVudCgpLmlkICE9PSBpZCwgeyB0aW1lb3V0IH0sIHdlYnZpZXdJZCk7XG4gICAgfVxuICAgIGlzUGFnZVJlZGlyZWN0ZWQodXJsKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnBhZ2UuZXZhbHVhdGUoKHVybCkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIHVybC5pbmRleE9mKGxvY2F0aW9uLnBhdGhuYW1lKSA9PT0gLTE7XG4gICAgICAgIH0sIHVybCk7XG4gICAgfVxuICAgIGdldFRpbWUoKSB7XG4gICAgICAgIHJldHVybiBEYXRlLm5vdygpIC0gdGhpcy5pbml0VHM7XG4gICAgfVxufVxuZXhwb3J0cy5kZWZhdWx0ID0gUGFnZUJhc2U7XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmNvbnN0IGF3YWl0X3RvX2pzXzEgPSByZXF1aXJlKFwiYXdhaXQtdG8tanNcIik7XG4vLyBpbXBvcnQge0lkS2V5fSBmcm9tIFwiLi4vY29uZmlnXCI7XG5jb25zdCBsb2dfMSA9IHJlcXVpcmUoXCIuLi9sb2dcIik7XG5jb25zdCB1dGlsc18xID0gcmVxdWlyZShcIi4vdXRpbHNcIik7XG5hc3luYyBmdW5jdGlvbiBnZXRDdXJyZW50RnJhbWUocGFnZSkge1xuICAgIGNvbnN0IGlkID0gYXdhaXQgZ2V0Q3VycmVudElkKHBhZ2UpO1xuICAgIC8vIGRlYnVnKCdnZXQgQ3VycmVudCBGcmFtZSBJZDonLCBpZCk7XG4gICAgY29uc3QgZnJhbWUgPSBhd2FpdCBnZXRDdXJyZW50RnJhbWVCeVdlYnZpZXdJZChwYWdlLCBpZCk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZnJhbWUsXG4gICAgICAgIGlkXG4gICAgfTtcbn1cbmV4cG9ydHMuZ2V0Q3VycmVudEZyYW1lID0gZ2V0Q3VycmVudEZyYW1lO1xuZnVuY3Rpb24gZ2V0Q3VycmVudElkKHBhZ2UpIHtcbiAgICByZXR1cm4gcGFnZS5ldmFsdWF0ZSgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGN1cnJlbnQgPSB3aW5kb3cubmF0aXZlLndlYnZpZXdNYW5hZ2VyLmdldEN1cnJlbnQoKTtcbiAgICAgICAgcmV0dXJuIGN1cnJlbnQuaWQ7XG4gICAgfSk7XG59XG5leHBvcnRzLmdldEN1cnJlbnRJZCA9IGdldEN1cnJlbnRJZDtcbmFzeW5jIGZ1bmN0aW9uIGdldEN1cnJlbnRGcmFtZURhdGEocGFnZSwgZnJhbWVNYXApIHtcbiAgICBjb25zdCB7IGZyYW1lIH0gPSBhd2FpdCBnZXRDdXJyZW50RnJhbWUocGFnZSk7XG4gICAgaWYgKCFmcmFtZSlcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICByZXR1cm4gZnJhbWVNYXAuZ2V0KGZyYW1lKTtcbn1cbmV4cG9ydHMuZ2V0Q3VycmVudEZyYW1lRGF0YSA9IGdldEN1cnJlbnRGcmFtZURhdGE7XG5hc3luYyBmdW5jdGlvbiBnZXRDdXJyZW50RnJhbWVCeVdlYnZpZXdJZChwYWdlLCB3ZWJ2aWV3SWQpIHtcbiAgICBjb25zdCBmcmFtZUxpc3QgPSBhd2FpdCBwYWdlLmZyYW1lcygpO1xuICAgIGNvbnN0IHBlbmRpbmdGcmFtZSA9IFtdO1xuICAgIGZvciAoY29uc3QgZnJhbWUgb2YgZnJhbWVMaXN0KSB7XG4gICAgICAgIGlmIChmcmFtZS5uYW1lKCkgPT09ICcnKSB7XG4gICAgICAgICAgICBwZW5kaW5nRnJhbWUucHVzaChmcmFtZSk7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZnJhbWUubmFtZSgpID09PSBgd2Vidmlldy0ke3dlYnZpZXdJZH1gKSB7XG4gICAgICAgICAgICAvLyBMb2dnZXIuaW5mbyhgZm91bmQgd2Vidmlldy0ke3dlYnZpZXdJZH0hISFgKTtcbiAgICAgICAgICAgIHJldHVybiBmcmFtZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyBpbiB0aGUgcGVuZGluZyBmcmFtZSB3YWl0IGZvciBpdCBhbmQgcmV0dXJuXG4gICAgLy8gZGVidWcoJ2dldCBjdXJyZW50IGZyYW1lIGJ5IGlkIGluIHBlbmRpbmcgbGlzdCcpO1xuICAgIGZvciAoY29uc3QgZnJhbWUgb2YgcGVuZGluZ0ZyYW1lKSB7XG4gICAgICAgIGNvbnN0IFt3YWl0VGltZW91dF0gPSBhd2FpdCBhd2FpdF90b19qc18xLmRlZmF1bHQoZnJhbWUud2FpdEZvck5hdmlnYXRpb24oeyB0aW1lb3V0OiAxMDAwIH0pKTtcbiAgICAgICAgaWYgKGZyYW1lLm5hbWUoKSA9PT0gYHdlYnZpZXctJHt3ZWJ2aWV3SWR9YCkge1xuICAgICAgICAgICAgcmV0dXJuIGZyYW1lO1xuICAgICAgICB9XG4gICAgfVxufVxuZXhwb3J0cy5nZXRDdXJyZW50RnJhbWVCeVdlYnZpZXdJZCA9IGdldEN1cnJlbnRGcmFtZUJ5V2Vidmlld0lkO1xuYXN5bmMgZnVuY3Rpb24gZ2V0QXBwU2VydmljZUZyYW1lKHBhZ2UpIHtcbiAgICBjb25zdCBmcmFtZUxpc3QgPSBhd2FpdCBwYWdlLmZyYW1lcygpO1xuICAgIGZvciAoY29uc3QgZnJhbWUgb2YgZnJhbWVMaXN0KSB7XG4gICAgICAgIGlmIChmcmFtZS5uYW1lKCkgPT09ICdhcHBzZXJ2aWNlJykge1xuICAgICAgICAgICAgcmV0dXJuIGZyYW1lO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xufVxuZXhwb3J0cy5nZXRBcHBTZXJ2aWNlRnJhbWUgPSBnZXRBcHBTZXJ2aWNlRnJhbWU7XG5mdW5jdGlvbiBzY3JvbGxUb1RvcChmcmFtZSkge1xuICAgIHJldHVybiB1dGlsc18xLmZyYW1lRXZhbHVhdGUoZnJhbWUsICgpID0+IHtcbiAgICAgICAgLy8gQHRvZG8g5Yik5a6a5b2T5YmN6aG16Z2i5piv5ZCm5pyJc2Nyb2xsLXZpZXcsIOaciXNjcm9sbC12aWV35pe277yM6ZyA6KaB5Yir55qE5pa55byP5rua5YqoXG4gICAgICAgIHdpbmRvdy5zY3JvbGxUbygwLCAwKTtcbiAgICB9KTtcbn1cbmV4cG9ydHMuc2Nyb2xsVG9Ub3AgPSBzY3JvbGxUb1RvcDtcbmZ1bmN0aW9uIHNjcm9sbFRvQm90dG9tKGZyYW1lKSB7XG4gICAgcmV0dXJuIHV0aWxzXzEuZnJhbWVFdmFsdWF0ZShmcmFtZSwgKCkgPT4ge1xuICAgICAgICAvLyBAdG9kbyDliKTlrprlvZPliY3pobXpnaLmmK/lkKbmnIlzY3JvbGwtdmlldywg5pyJc2Nyb2xsLXZpZXfml7bvvIzpnIDopoHliKvnmoTmlrnlvI/mu5rliqhcbiAgICAgICAgY29uc3QgaGVpZ2h0ID0gZG9jdW1lbnQuYm9keS5zY3JvbGxIZWlnaHQ7XG4gICAgICAgIGNvbnN0IHdpbmRvd0hlaWdodCA9IHdpbmRvdy5pbm5lckhlaWdodDtcbiAgICAgICAgd2luZG93LnNjcm9sbFRvKDAsIGhlaWdodCAtIHdpbmRvd0hlaWdodCk7XG4gICAgICAgIC8vIHdpbmRvdy53eC5wdWJsaXNoUGFnZUV2ZW50KCdvblJlYWNoQm90dG9tJywge30pO1xuICAgIH0pO1xufVxuZXhwb3J0cy5zY3JvbGxUb0JvdHRvbSA9IHNjcm9sbFRvQm90dG9tO1xuZnVuY3Rpb24gc2Nyb2xsRG93bihmcmFtZSkge1xuICAgIHJldHVybiB1dGlsc18xLmZyYW1lRXZhbHVhdGUoZnJhbWUsICgpID0+IHtcbiAgICAgICAgY29uc3Qgc2Nyb2xsVG9wID0gd2luZG93LnNjcm9sbFk7XG4gICAgICAgIGNvbnN0IHdpbmRvd0hlaWdodCA9IHdpbmRvdy5pbm5lckhlaWdodDtcbiAgICAgICAgd2luZG93LnNjcm9sbFRvKDAsIHNjcm9sbFRvcCArIHdpbmRvd0hlaWdodCAtIDY0KTtcbiAgICAgICAgcmV0dXJuIHdpbmRvdy5pbm5lckhlaWdodDtcbiAgICB9KTtcbn1cbmV4cG9ydHMuc2Nyb2xsRG93biA9IHNjcm9sbERvd247XG5mdW5jdGlvbiBlbGVtSW5XaW5kb3coZnJhbWUpIHtcbn1cbmV4cG9ydHMuZWxlbUluV2luZG93ID0gZWxlbUluV2luZG93O1xuZnVuY3Rpb24gZHVtcFNjb3BlRGF0YVRvRE9NTm9kZShmcmFtZSkge1xuICAgIHJldHVybiB1dGlsc18xLmZyYW1lRXZhbHVhdGUoZnJhbWUsICgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHdpbmRvdy5fX3ZpcnR1YWxET01fXy5zcHJlYWRTY29wZURhdGFUb0RPTU5vZGUoKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYHNjb3BlIGRhdGEgZXJyb3IgJHtlLm1lc3NhZ2V9ICR7ZS5zdGFja31gKTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuZXhwb3J0cy5kdW1wU2NvcGVEYXRhVG9ET01Ob2RlID0gZHVtcFNjb3BlRGF0YVRvRE9NTm9kZTtcbmZ1bmN0aW9uIGdldEZyYW1lSHRtbChmcmFtZSkge1xuICAgIHJldHVybiB1dGlsc18xLmZyYW1lRXZhbHVhdGUoZnJhbWUsICgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHdpbmRvdy5fX3ZpcnR1YWxET01fXy5zcHJlYWRTY29wZURhdGFUb0RPTU5vZGUoKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYHNjb3BlIGRhdGEgZXJyb3IgJHtlLm1lc3NhZ2V9ICR7ZS5zdGFja31gKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzdHlsZVNoZWV0cyA9IGRvY3VtZW50LnN0eWxlU2hlZXRzO1xuICAgICAgICBsZXQgY3NzID0gJyc7XG4gICAgICAgIGNvbnN0IGVsZW1lbnRzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnKicpO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbGVuID0gZWxlbWVudHMubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGVsID0gZWxlbWVudHNbaV07XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbGVuID0gc3R5bGVTaGVldHMubGVuZ3RoOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjc3NSdWxlcyA9IHN0eWxlU2hlZXRzW2ldLmNzc1J1bGVzO1xuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBsZW4gPSBjc3NSdWxlcy5sZW5ndGg7IGkgPCBsZW47IGkrKykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBydWxlID0gY3NzUnVsZXNbaV07XG4gICAgICAgICAgICAgICAgICAgIGlmIChydWxlLmFkZGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoZWwud2Via2l0TWF0Y2hlc1NlbGVjdG9yKHJ1bGUuc2VsZWN0b3JUZXh0KSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcnVsZS5hZGRlZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBjc3MgKz0gcnVsZS5jc3NUZXh0O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgPGh0bWw+PG1ldGEgY2hhcnNldD1cIlVURi04XCI+PG1ldGEgbmFtZT1cInZpZXdwb3J0XCIgY29udGVudD1cIndpZHRoPWRldmljZS13aWR0aCxcbiAgICAgICAgICAgICAgICB1c2VyLXNjYWxhYmxlPW5vLCBpbml0aWFsLXNjYWxlPTEuMCwgbWF4aW11bS1zY2FsZT0xLjAsIG1pbmltdW0tc2NhbGU9MS4wXCI+PHN0eWxlPiR7Y3NzfTwvc3R5bGU+XG4gICAgICAgICAgICAgICAgJHtkb2N1bWVudC5ib2R5Lm91dGVySFRNTH1gO1xuICAgIH0pO1xufVxuZXhwb3J0cy5nZXRGcmFtZUh0bWwgPSBnZXRGcmFtZUh0bWw7XG5hc3luYyBmdW5jdGlvbiBnZXRFbGVtQ3J3KGVsZW0sIGZyYW1lKSB7XG4gICAgY29uc3QgW2VyciwgY3J3XSA9IGF3YWl0IGF3YWl0X3RvX2pzXzEuZGVmYXVsdCh1dGlsc18xLmZyYW1lRXZhbHVhdGUoZnJhbWUsIChlbGVtKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlY3QgPSBlbGVtLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICBjb25zdCBjb21TdHlsZSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsZW0pO1xuICAgICAgICByZXR1cm4gYCR7cmVjdC5sZWZ0fSwke3JlY3QudG9wfSwke3JlY3QucmlnaHR9LCR7cmVjdC5ib3R0b219LCR7Y29tU3R5bGUuZm9udFNpemV9LCR7Y29tU3R5bGUuYm9yZGVyV2lkdGh9LCR7Y29tU3R5bGUuYmFja2dyb3VuZENvbG9yfSwke2NvbVN0eWxlLmJvcmRlckNvbG9yfSwke2NvbVN0eWxlLmNvbG9yfSwke2NvbVN0eWxlLnBhZGRpbmd9LCR7Y29tU3R5bGUubWFyZ2lufWA7XG4gICAgfSwgZWxlbSkpO1xuICAgIGlmIChlcnIpIHtcbiAgICAgICAgbG9nXzEuZGVmYXVsdC5lcnJvcignZmFpbCBnZXQgZWxlbSBjcncnLCBlcnIpO1xuICAgICAgICByZXR1cm4gJyc7XG4gICAgfVxuICAgIHJldHVybiBjcnc7XG59XG5leHBvcnRzLmdldEVsZW1DcncgPSBnZXRFbGVtQ3J3O1xuYXN5bmMgZnVuY3Rpb24gaW5zZXJ0Q3J3SW5mbyhmcmFtZSkge1xuICAgIGNvbnN0IG1zZyA9IGF3YWl0IHV0aWxzXzEuZnJhbWVFdmFsdWF0ZShmcmFtZSwgKCkgPT4ge1xuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIGZ1bmN0aW9uIHRyYXZlcnNlRWxlbWVudChlbCkge1xuICAgICAgICAgICAgY29uc3QgY2hpbGRFbENudCA9IGVsLmNoaWxkRWxlbWVudENvdW50O1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZEVsQ250OyArK2kpIHtcbiAgICAgICAgICAgICAgICBjb25zdCByZWN0ID0gZWwuY2hpbGRyZW5baV0uZ2V0Q2xpZW50UmVjdHMoKTtcbiAgICAgICAgICAgICAgICBjb25zdCBjb21TdHlsZSA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsLmNoaWxkcmVuW2ldKTtcbiAgICAgICAgICAgICAgICBsZXQgY3J3QXR0ciA9ICcnO1xuICAgICAgICAgICAgICAgIGlmIChyZWN0Lmxlbmd0aCkge1xuICAgICAgICAgICAgICAgICAgICBjcndBdHRyID0gYCR7cmVjdFswXS5sZWZ0fSwke3JlY3RbMF0udG9wfSwke3JlY3RbMF0ucmlnaHR9LGBcbiAgICAgICAgICAgICAgICAgICAgICAgICsgYCR7cmVjdFswXS5ib3R0b219LCR7Y29tU3R5bGUuZm9udFNpemV9LCR7Y29tU3R5bGUuYm9yZGVyV2lkdGh9LGBcbiAgICAgICAgICAgICAgICAgICAgICAgICsgYCR7Y29tU3R5bGUuYmFja2dyb3VuZENvbG9yfSwke2NvbVN0eWxlLmJvcmRlckNvbG9yfSwke2NvbVN0eWxlLmNvbG9yfSxgXG4gICAgICAgICAgICAgICAgICAgICAgICArIGAke2NvbVN0eWxlLnBhZGRpbmd9LCR7Y29tU3R5bGUubWFyZ2lufWA7XG4gICAgICAgICAgICAgICAgICAgIGVsLmNoaWxkcmVuW2ldLnNldEF0dHJpYnV0ZSgnd3gtY3J3JywgY3J3QXR0cik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRyYXZlcnNlRWxlbWVudChlbC5jaGlsZHJlbltpXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHdpbmRvdy5zY3JvbGxUbygwLCAwKTtcbiAgICAgICAgICAgIHRyYXZlcnNlRWxlbWVudChkb2N1bWVudC5ib2R5KTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYHRyYXZlcnNlRWxlbWVudCBlcnJvciAke2UubWVzc2FnZX0gJHtlLnN0YWNrfWApO1xuICAgICAgICAgICAgcmV0dXJuIGUubWVzc2FnZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gJ29rJztcbiAgICB9KTtcbiAgICBpZiAobXNnICE9PSAnb2snKSB7XG4gICAgICAgIGxvZ18xLmRlZmF1bHQuZXJyb3IoYGluc2VydENyd0luZm8gZXJyb3IhICR7bXNnfWApO1xuICAgICAgICAvLyByZXBvcnRJZEtleShJZEtleS5JTlNFUlRfQ1JXX0VSUik7XG4gICAgfVxuICAgIHJldHVybiBtc2c7XG59XG5leHBvcnRzLmluc2VydENyd0luZm8gPSBpbnNlcnRDcndJbmZvO1xuYXN5bmMgZnVuY3Rpb24gZ2V0QW5kSW5zZXJ0U2hhcmVEYXRhKHBhZ2UsIGZyYW1lKSB7XG4gICAgbGV0IHNoYXJlRGF0YTtcbiAgICB0cnkge1xuICAgICAgICBhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IHtcbiAgICAgICAgICAgIC8vIOinpuWPkeWIhuS6q1xuICAgICAgICAgICAgY29uc3Qgd2VidmlldyA9IHdpbmRvdy5uYXRpdmUud2Vidmlld01hbmFnZXIuZ2V0Q3VycmVudCgpO1xuICAgICAgICAgICAgd2luZG93Lm5hdGl2ZS5hcHBTZXJ2aWNlTWVzc2VuZ2VyLnNlbmQoe1xuICAgICAgICAgICAgICAgIGNvbW1hbmQ6ICdBUFBTRVJWSUNFX09OX0VWRU5UJyxcbiAgICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgICAgIGV2ZW50TmFtZTogJ29uU2hhcmVBcHBNZXNzYWdlJyxcbiAgICAgICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogd2Vidmlldy51cmwsXG4gICAgICAgICAgICAgICAgICAgICAgICBtb2RlOiAnY29tbW9uJyxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHdlYnZpZXdJZDogd2Vidmlldy5pZCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgICAgYXdhaXQgdXRpbHNfMS5zbGVlcCgyMDApO1xuICAgICAgICBzaGFyZURhdGEgPSBhd2FpdCBwYWdlLmV2YWx1YXRlKCgpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKHdpbmRvdy5zaGFyZURhdGEpO1xuICAgICAgICAgICAgcmV0dXJuIHdpbmRvdy5zaGFyZURhdGE7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICBsb2dfMS5kZWZhdWx0LmVycm9yKGAhISEhISBnZXRTaGFyZURhdGEgZXZhbHVhdGUgZmFpbGVkICR7ZS5tZXNzYWdlfSAke2Uuc3RhY2t9YCk7XG4gICAgfVxuICAgIGxvZ18xLmRlZmF1bHQuaW5mbyhgc2hhcmVkYXRhIGlzICR7SlNPTi5zdHJpbmdpZnkoc2hhcmVEYXRhKX1gKTtcbiAgICBpZiAoc2hhcmVEYXRhICYmIChzaGFyZURhdGEuaGFzT3duUHJvcGVydHkoXCJ0aXRsZVwiKSB8fCBzaGFyZURhdGEuaGFzT3duUHJvcGVydHkoXCJpbWFnZVVybFwiKSkpIHtcbiAgICAgICAgY29uc3QgcmVhbFNoYXJlRGF0YSA9IHtcbiAgICAgICAgICAgIFwidGl0bGVcIjogc2hhcmVEYXRhLnRpdGxlID8gc2hhcmVEYXRhLnRpdGxlIDogXCJcIixcbiAgICAgICAgICAgIFwiaW1hZ2VVcmxcIjogXCJcIlxuICAgICAgICB9O1xuICAgICAgICBpZiAoc2hhcmVEYXRhLmltYWdlVXJsICYmIGF3YWl0IHV0aWxzXzEuY2hlY2tJbWFnZVZhbGlkKHNoYXJlRGF0YS5pbWFnZVVybCkgPT09IDApIHtcbiAgICAgICAgICAgIHJlYWxTaGFyZURhdGEuaW1hZ2VVcmwgPSBzaGFyZURhdGEuaW1hZ2VVcmw7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBsb2dfMS5kZWZhdWx0LmVycm9yKGBpbWFnZToke3NoYXJlRGF0YS5pbWFnZVVybH0gaXMgaW52YWxpZCFgKTtcbiAgICAgICAgfVxuICAgICAgICBhd2FpdCB1dGlsc18xLmZyYW1lRXZhbHVhdGUoZnJhbWUsIChzRGF0YSkgPT4ge1xuICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5zZXRBdHRyaWJ1dGUoJ3d4LXNoYXJlLWRhdGEnLCBKU09OLnN0cmluZ2lmeShzRGF0YSkpO1xuICAgICAgICB9LCByZWFsU2hhcmVEYXRhKTtcbiAgICB9XG59XG5leHBvcnRzLmdldEFuZEluc2VydFNoYXJlRGF0YSA9IGdldEFuZEluc2VydFNoYXJlRGF0YTtcbmZ1bmN0aW9uIGdldEZyYW1lSW5mbyhmcmFtZSkge1xuICAgIHJldHVybiB1dGlsc18xLmZyYW1lRXZhbHVhdGUoZnJhbWUsICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHBhZ2VIZWlnaHQ6IGRvY3VtZW50LmJvZHkub2Zmc2V0SGVpZ2h0LFxuICAgICAgICAgICAgd2luZG93SGVpZ2h0OiB3aW5kb3cuaW5uZXJIZWlnaHQsXG4gICAgICAgIH07XG4gICAgfSk7XG59XG5leHBvcnRzLmdldEZyYW1lSW5mbyA9IGdldEZyYW1lSW5mbztcbmFzeW5jIGZ1bmN0aW9uIGdldFVzZXJJbmZvKGZyYW1lLCBwYWdlKSB7XG4gICAgY29uc3QgZnJhbWVMaXN0ID0gYXdhaXQgcGFnZS5mcmFtZXMoKTtcbiAgICBmb3IgKGNvbnN0IGZyYW1lIG9mIGZyYW1lTGlzdCkge1xuICAgICAgICBpZiAoZnJhbWUubmFtZSgpID09PSAnYXBwc2VydmljZScpIHtcbiAgICAgICAgICAgIGNvbnN0IFtlcnIsIHVzZXJJbmZvXSA9IGF3YWl0IGF3YWl0X3RvX2pzXzEuZGVmYXVsdCh1dGlsc18xLmZyYW1lRXZhbHVhdGUoZnJhbWUsICgpID0+IHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgICAgICAgICAgICAgIHd4LmdldFVzZXJJbmZvKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1Y2Nlc3MocmVzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXMudXNlckluZm8pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGZhaWwoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KCcnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICBsb2dfMS5kZWZhdWx0LmluZm8oYHVzZXJpbmZvIGlzICR7SlNPTi5zdHJpbmdpZnkodXNlckluZm8pfWApO1xuICAgICAgICAgICAgaWYgKHVzZXJJbmZvKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHVzZXJJbmZvO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gcmVwb3J0SWRLZXkoSWRLZXkuR0VUX1VTRVJJTkZPX0VNUFRZKTtcbiAgICAgICAgICAgICAgICByZXR1cm4ge307XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuO1xufVxuZXhwb3J0cy5nZXRVc2VySW5mbyA9IGdldFVzZXJJbmZvO1xuZnVuY3Rpb24gZ2V0V2Vidmlld0luZm8ocGFnZSkge1xuICAgIHJldHVybiBwYWdlLmV2YWx1YXRlKCgpID0+IHtcbiAgICAgICAgY29uc3QgY3VycmVudFdlYnZpZXcgPSB3aW5kb3cubmF0aXZlLndlYnZpZXdNYW5hZ2VyLmdldEN1cnJlbnQoKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHVybDogY3VycmVudFdlYnZpZXcudXJsLFxuICAgICAgICAgICAgaWQ6IGN1cnJlbnRXZWJ2aWV3LmlkLFxuICAgICAgICAgICAgcGF0aDogY3VycmVudFdlYnZpZXcucGF0aCxcbiAgICAgICAgICAgIHBhZ2VUaXRsZTogY3VycmVudFdlYnZpZXcucGFnZUNvbmZpZy53aW5kb3cubmF2aWdhdGlvbkJhclRpdGxlVGV4dCxcbiAgICAgICAgICAgIHN0YWNrOiB3aW5kb3cubmF0aXZlLndlYnZpZXdNYW5hZ2VyLmdldFBhZ2VTdGFjaygpLm1hcCgod2VidmlldykgPT4gd2Vidmlldy5wYXRoKSxcbiAgICAgICAgfTtcbiAgICB9KTtcbn1cbmV4cG9ydHMuZ2V0V2Vidmlld0luZm8gPSBnZXRXZWJ2aWV3SW5mbztcbmZ1bmN0aW9uIGhhc1dlYnZpZXcoZnJhbWUpIHtcbiAgICByZXR1cm4gdXRpbHNfMS5mcmFtZUV2YWx1YXRlKGZyYW1lLCAoKSA9PiB7XG4gICAgICAgIHJldHVybiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCd3eC13ZWItdmlldycpICE9PSBudWxsO1xuICAgIH0pO1xufVxuZXhwb3J0cy5oYXNXZWJ2aWV3ID0gaGFzV2VidmlldztcbmZ1bmN0aW9uIGluc2VydFRhc2tJbmZvKHRhc2tJbmZvLCBmcmFtZSkge1xuICAgIGNvbnN0IGQgPSBuZXcgRGF0ZSgpO1xuICAgIHRhc2tJbmZvLnRpbWUgPSBkLnRvTG9jYWxlU3RyaW5nKCk7XG4gICAgcmV0dXJuIHV0aWxzXzEuZnJhbWVFdmFsdWF0ZShmcmFtZSwgKHNEYXRhKSA9PiB7XG4gICAgICAgIGRvY3VtZW50LmJvZHkuc2V0QXR0cmlidXRlKCd3eC1jcmF3bGVyLXRhc2tpbmZvJywgSlNPTi5zdHJpbmdpZnkoc0RhdGEpKTtcbiAgICB9LCB0YXNrSW5mbyk7XG59XG5leHBvcnRzLmluc2VydFRhc2tJbmZvID0gaW5zZXJ0VGFza0luZm87XG4iLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmNvbnN0IGV2ZW50c18xID0gcmVxdWlyZShcImV2ZW50c1wiKTtcbmNvbnN0IGxvZ18xID0gcmVxdWlyZShcIi4uLy4uL2xvZ1wiKTtcbmNvbnN0IHJlcG9ydElkS2V5XzEgPSByZXF1aXJlKFwiLi4vLi4vdXRpbC9yZXBvcnRJZEtleVwiKTtcbmNvbnN0IEJsYWNrTGlzdCA9IHtcbiAgICBcImh0dHBzOi8vbG9nLm1lbmd0dWlhcHAuY29tL3JlcG9ydC92MVwiOiB0cnVlLFxuICAgIFwiaHR0cHM6Ly9sb2cuYWxkd3guY29tL2QuaHRtbFwiOiB0cnVlLFxuICAgIFwibG9nLmFsZHd4LmNvbVwiOiB0cnVlXG59O1xubGV0IHJlcG9ydE5ld1Byb3h5SXAgPSBmYWxzZTtcbmNsYXNzIEZyYW1lRGF0YSBleHRlbmRzIGV2ZW50c18xLkV2ZW50RW1pdHRlciB7XG4gICAgY29uc3RydWN0b3IoZnJhbWUsIG9wdCA9IHt9KSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMuZXh0cmEgPSB7fTtcbiAgICAgICAgdGhpcy5yZXF1ZXN0TWFwID0gbmV3IE1hcCgpO1xuICAgICAgICB0aGlzLmZyYW1lID0gZnJhbWU7XG4gICAgICAgIHRoaXMucmVxdWVzdE51bSA9IDA7XG4gICAgICAgIHRoaXMuaXNOZXR3b3JrSWRsZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLm5ldHdvcmtJZGxlVGltZXIgPSBudWxsO1xuICAgICAgICB0aGlzLmRpc2FibGVJbWcgPSBvcHQuZGlzYWJsZUltZyB8fCBmYWxzZTtcbiAgICAgICAgdGhpcy5kaXNhYmxlTWVkaWEgPSBvcHQuZGlzYWJsZU1lZGlhIHx8IGZhbHNlO1xuICAgICAgICB0aGlzLmlzTXBjcmF3bGVyID0gb3B0LmlzTXBjcmF3bGVyIHx8IGZhbHNlO1xuICAgICAgICB0aGlzLnRpbWVQZXJSZXF1ZXN0ID0gMDtcbiAgICAgICAgdGhpcy5pc01haW5GcmFtZSA9IG9wdC5pc01haW5GcmFtZSB8fCBmYWxzZTtcbiAgICAgICAgdGhpcy5zZXRNYXhMaXN0ZW5lcnMoMTAwKTtcbiAgICB9XG4gICAgaXNEZXRhY2goKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmZyYW1lLmlzRGV0YWNoZWQoKTtcbiAgICB9XG4gICAgc2V0VGFza0V4dHJhKGV4dHJhKSB7XG4gICAgICAgIHRoaXMuZXh0cmEgPSBleHRyYTtcbiAgICB9XG4gICAgZ2V0UGVyZm9ybWFuY2UoaXNSZXNldCA9IGZhbHNlKSB7XG4gICAgICAgIGNvbnN0IHRpbWUgPSB0aGlzLnRpbWVQZXJSZXF1ZXN0O1xuICAgICAgICBpZiAoaXNSZXNldCkge1xuICAgICAgICAgICAgdGhpcy50aW1lUGVyUmVxdWVzdCA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGF2ZXJhZ2VUaW1lOiBNYXRoLnJvdW5kKHRpbWUpLFxuICAgICAgICAgICAgdGltZW91dDogdGhpcy5yZXF1ZXN0TnVtLFxuICAgICAgICB9O1xuICAgIH1cbiAgICByZXNldFBlcmZvcm1hbmNlKCkge1xuICAgICAgICB0aGlzLnRpbWVQZXJSZXF1ZXN0ID0gMDtcbiAgICB9XG4gICAgYXN5bmMgb25SZXF1ZXN0U3RhcnQocmVxdWVzdCkge1xuICAgICAgICB0aGlzLnJlcXVlc3RNYXAuc2V0KHJlcXVlc3QuX3JlcXVlc3RJZCwgRGF0ZS5ub3coKSk7XG4gICAgICAgIHRoaXMucmVxdWVzdE51bSsrO1xuICAgICAgICAvLyBMb2dnZXIuZGVidWcoYGZyYW1lWyR7dGhpcy5mcmFtZS5uYW1lKCl9XSByZXF1ZXN0TnVtKysgJHt0aGlzLnJlcXVlc3ROdW19YClcbiAgICAgICAgdGhpcy5pc05ldHdvcmtJZGxlID0gZmFsc2U7XG4gICAgICAgIGlmICh0aGlzLm5ldHdvcmtJZGxlVGltZXIpIHtcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLm5ldHdvcmtJZGxlVGltZXIpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGFzeW5jIG9uUmVxdWVzdEVuZChyZXF1ZXN0LCBlbmRUeXBlKSB7XG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgY29uc3QgY29zdFRpbWUgPSBEYXRlLm5vdygpIC0gdGhpcy5yZXF1ZXN0TWFwLmdldChyZXF1ZXN0Ll9yZXF1ZXN0SWQpO1xuICAgICAgICBjb25zdCByVXJsID0gcmVxdWVzdC51cmwoKTtcbiAgICAgICAgaWYgKHJVcmwuc2VhcmNoKCcvd3hhY3Jhd2xlci8nKSAhPT0gLTEpIHtcbiAgICAgICAgICAgIC8vIGNvZGVzdnJcbiAgICAgICAgICAgIGlmIChlbmRUeXBlID09PSAnZmFpbGVkJyAmJiByZXF1ZXN0LnJlc291cmNlVHlwZSgpICE9PSAnaW1hZ2UnKSB7XG4gICAgICAgICAgICAgICAgbG9nXzEuZGVmYXVsdC5lcnJvcihgZW5kICR7ZW5kVHlwZX0gcmVzVHlwZSAke3JlcXVlc3QucmVzb3VyY2VUeXBlKCl9IHJlcXVlc3Q6JyR7cmVxdWVzdC51cmwoKX0nIGVycm9yOiAke3JlcXVlc3QuX2ZhaWx1cmVUZXh0fSBjb3N0IHRpbWUgOiAke2Nvc3RUaW1lfWApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZW5kVHlwZSA9PT0gJ2ZhaWxlZCcgPyByZXBvcnRJZEtleV8xLnJlcG9ydElkS2V5KHJlcG9ydElkS2V5XzEuSWRLZXkuQ09ERVNWUl9SRVFVRVNUX0ZBSUxFRCkgOiByZXBvcnRJZEtleV8xLnJlcG9ydElkS2V5KHJlcG9ydElkS2V5XzEuSWRLZXkuQ09ERVNWUl9SRVFVRVNUX1NVQ0MpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHJVcmwuc2VhcmNoKCd3eGFjcmF3bGVycmVxdWVzdC9wcm94eScpICE9PSAtMSkge1xuICAgICAgICAgICAgLy8gcmVxdWVzdHByb3h55Luj55CGXG4gICAgICAgICAgICBpZiAoclVybC5zZWFyY2goJ3NlcnZpY2V3ZWNoYXQnKSAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgICBpZiAoZW5kVHlwZSA9PT0gJ2ZhaWxlZCcpIHtcbiAgICAgICAgICAgICAgICAgICAgbG9nXzEuZGVmYXVsdC5lcnJvcihgZW5kICR7ZW5kVHlwZX0gcmVxdWVzdDonJHtyZXF1ZXN0LnVybCgpfScgXG4gICAgICAgICAgICAgICAgICAgIGVycm9yOiAke3JlcXVlc3QuX2ZhaWx1cmVUZXh0fSBjb3N0IHRpbWUgOiAke2Nvc3RUaW1lfWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbmRUeXBlID09PSAnZmFpbGVkJyA/IHJlcG9ydElkS2V5XzEucmVwb3J0SWRLZXkocmVwb3J0SWRLZXlfMS5JZEtleS5SRVFVRVNUX1NXX0ZBSUxFRCkgOiByZXBvcnRJZEtleV8xLnJlcG9ydElkS2V5KHJlcG9ydElkS2V5XzEuSWRLZXkuUkVRVUVTVF9TV19TVUNDKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVuZFR5cGUgPT09ICdmYWlsZWQnID8gcmVwb3J0SWRLZXlfMS5yZXBvcnRJZEtleShyZXBvcnRJZEtleV8xLklkS2V5LlJFUVVFU1RfRkFJTEVEKSA6IHJlcG9ydElkS2V5XzEucmVwb3J0SWRLZXkocmVwb3J0SWRLZXlfMS5JZEtleS5SRVFVRVNUX1NVQ0MpO1xuICAgICAgICAgICAgaWYgKGVuZFR5cGUgPT09ICdmYWlsZWQnKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSByZXF1ZXN0LnJlc3BvbnNlKCk7XG4gICAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGhlYWRlcnMgPSByZXNwb25zZSA/IHJlc3BvbnNlLmhlYWRlcnMoKSA6IHt9O1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBuZXdQcm94eUlwID0gaGVhZGVyc1sneC1yZXF1ZXN0cHJveHktaXAnXTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgb2xkUHJveHlJcCA9IGhlYWRlcnNbJ3gtb2xkLXJlcXVlc3Rwcm94eS1pcCddO1xuICAgICAgICAgICAgICAgICAgICBsb2dfMS5kZWZhdWx0LmVycm9yKGBmYWlsZWQgcmVxdWVzdCEhISBOZXdQcm94eToke25ld1Byb3h5SXB9LiBPbGRQcm94eToke29sZFByb3h5SXB9LiB1cmw6JHtyVXJsfS4gcmV0Y29kZToke3Jlc3BvbnNlLnN0YXR1cygpfWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgbG9nXzEuZGVmYXVsdC5lcnJvcihgZmFpbGVkIHJlcXVlc3QhISEgJHtyVXJsfS5gKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBlbmRUeXBlID09PSAnZmFpbGVkJyA/IHJlcG9ydElkS2V5XzEucmVwb3J0SWRLZXkocmVwb3J0SWRLZXlfMS5JZEtleS5TUVVJRF9SRVFVRVNUX0ZBSUxFRCkgOiByZXBvcnRJZEtleV8xLnJlcG9ydElkS2V5KHJlcG9ydElkS2V5XzEuSWRLZXkuU1FVSURfUkVRVUVTVF9TVUNDKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnJlcXVlc3ROdW0tLTtcbiAgICAgICAgLy8gTG9nZ2VyLmRlYnVnKGBmcmFtZVske3RoaXMuZnJhbWUubmFtZSgpfV0gcmVxdWVzdE51bS0tICR7dGhpcy5yZXF1ZXN0TnVtfWApXG4gICAgICAgIGlmICh0aGlzLnJlcXVlc3ROdW0gPD0gMCkge1xuICAgICAgICAgICAgaWYgKHRoaXMubmV0d29ya0lkbGVUaW1lcikge1xuICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aGlzLm5ldHdvcmtJZGxlVGltZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5uZXR3b3JrSWRsZVRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5pc05ldHdvcmtJZGxlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAvLyBkZWJ1ZygnbmV0d29yayBpZGxlJywgdGhpcy5mcmFtZS5uYW1lKCkpO1xuICAgICAgICAgICAgICAgIHRoaXMuZW1pdCgnbmV0d29ya0lkbGUnKTtcbiAgICAgICAgICAgIH0sIDUwMCk7XG4gICAgICAgICAgICAvLyA1MDBtcyDmsqHmnInmlrDor7fmsYLlsLHorqTkuLrmmK9uZXR3b3JrSWRsZVxuICAgICAgICB9XG4gICAgICAgIC8vIOabtOaWsGZyYW1l55qE5bmz5Z2H6ICX5pe2XG4gICAgICAgIGlmICh0aGlzLnRpbWVQZXJSZXF1ZXN0ID09PSAwKSB7XG4gICAgICAgICAgICB0aGlzLnRpbWVQZXJSZXF1ZXN0ID0gY29zdFRpbWU7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnRpbWVQZXJSZXF1ZXN0ID0gKHRoaXMudGltZVBlclJlcXVlc3QgKyBjb3N0VGltZSkgLyAyO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLmlzTWFpbkZyYW1lKSB7XG4gICAgICAgICAgICAvLyB3eC5yZXF1ZXN0XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IHJlcXVlc3QucmVzcG9uc2UoKTtcbiAgICAgICAgICAgIGNvbnN0IGhlYWRlcnMgPSByZXNwb25zZSA/IHJlc3BvbnNlLmhlYWRlcnMoKSA6IHt9O1xuICAgICAgICAgICAgY29uc3QgbmV3UHJveHlJcCA9IGhlYWRlcnNbJ3gtcmVxdWVzdHByb3h5LWlwJ107XG4gICAgICAgICAgICBjb25zdCBvbGRQcm94eUlwID0gaGVhZGVyc1sneC1vbGQtcmVxdWVzdHByb3h5LWlwJ107XG4gICAgICAgICAgICBpZiAobmV3UHJveHlJcCAmJiAhcmVwb3J0TmV3UHJveHlJcCkge1xuICAgICAgICAgICAgICAgIC8vIGRlYnVnKGBOZXcgUHJveHkgSXBgLCBuZXdQcm94eUlwKTtcbiAgICAgICAgICAgICAgICByZXBvcnROZXdQcm94eUlwID0gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKG9sZFByb3h5SXAgJiYgIXJlcG9ydE5ld1Byb3h5SXApIHtcbiAgICAgICAgICAgICAgICAvLyBkZWJ1ZyhgT2xkIFByb3h5IElwYCwgb2xkUHJveHlJcCk7XG4gICAgICAgICAgICAgICAgcmVwb3J0TmV3UHJveHlJcCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgLyoqXG4gICAgICogMDog5q2j5bi4XG4gICAgICogLTE6IOi2heaXtlxuICAgICAqIC0yOiBmcmFtZSBkZXRhY2hlZFxuICAgICAqIEBwYXJhbSB7bnVtYmVyfSB0aW1lb3V0XG4gICAgICogQHJldHVybnMge2FueX1cbiAgICAgKi9cbiAgICB3YWl0Rm9yTmV0d29ya0lkbGUodGltZW91dCA9IDUwMDApIHtcbiAgICAgICAgaWYgKHRoaXMuaXNEZXRhY2goKSlcbiAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoLTIpO1xuICAgICAgICBpZiAodGhpcy5pc05ldHdvcmtJZGxlKVxuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgwKTtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHRpbWVvdXRIYW5kbGUgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICBsb2dfMS5kZWZhdWx0LmVycm9yKGB3YWl0Rm9yTmV0d29ya0lkbGUgdGltZW91dDoke3RpbWVvdXR9YCk7XG4gICAgICAgICAgICAgICAgcmVwb3J0SWRLZXlfMS5yZXBvcnRJZEtleShyZXBvcnRJZEtleV8xLklkS2V5Lk5FVFdPUktfSURMRV9USU1FT1VUKTtcbiAgICAgICAgICAgICAgICByZXNvbHZlKC0xKTtcbiAgICAgICAgICAgIH0sIHRpbWVvdXQpO1xuICAgICAgICAgICAgdGhpcy5vbmNlKCduZXR3b3JrSWRsZScsICgpID0+IHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKDApO1xuICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SGFuZGxlKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5vbmNlKCdkZXRhY2gnLCAoZnJhbWVOYW1lKSA9PiB7XG4gICAgICAgICAgICAgICAgbG9nXzEuZGVmYXVsdC5pbmZvKGB3YWl0Rm9yTmV0d29ya0lkbGUgZmFpbDogZnJhbWVbJHtmcmFtZU5hbWV9XSBkZXRhY2hgKTtcbiAgICAgICAgICAgICAgICByZXNvbHZlKC0yKTtcbiAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQodGltZW91dEhhbmRsZSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxufVxuZXhwb3J0cy5kZWZhdWx0ID0gRnJhbWVEYXRhO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==